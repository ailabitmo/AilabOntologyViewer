package ru.spb.kpit.kivan;

import java.io.*;

/**
 * User: Kivan(Kivan)
 * Date: 01.01.2008
 * Time: 23:49:42
 */
public class temp {

    public static void diplomEkonom() {
        int s = 0;
        for (int t = 1; t <= 5; t++) {
            s += 354750 / Math.pow(1 + 0.1, t);
        }
        s -= 200000;
        System.out.println(s);
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        /*File f1 = new File("Orgraph_input");
        File f2 = new File("Norgraph_input");
        File f3 = new File("Orgraph_output");
        File f4 = new File("Norgraph_output");

        Properties p = new Properties();
        p.load(new FileReader("sys.properties"));

        Dot.setDotBinFolderPath((String)p.get("pathToGraph"));

        if (f1.listFiles()!=null)
            for (File file : f1.listFiles()) {
                final String nm = file.getName().substring(0, file.getName().indexOf("."));
                if (f3.listFiles(new FilenameFilter() {
                    public boolean accept(File dir, String name) {
                        return name.startsWith(nm);
                    }
                }).length == 0) {
                    Scanner sc = new Scanner(file);
                    StringBuilder sb = new StringBuilder();
                    while (sc.hasNextLine()) {
                        sb.append(sc.nextLine());
                    }
                    GrappaPanel gp = Dot.getGrappaVisualization(sb.toString(), GraphType.smallOrientedGraph);
                    JFrame fr = new JFrame();
                    fr.setSize(new Dimension(800, 600));
                    fr.setContentPane(gp);
                    fr.setVisible(true);
                    Thread.sleep(1000 * 5);
                    UiUtils.saveComponentAsPNG(fr, f3.getAbsolutePath() + "\\" + nm);
                    Thread.sleep(1000 * 5);
                    fr.setVisible(false);
                }
            }

        if (f2.listFiles()!=null)
            for (File file : f2.listFiles()) {
                final String nm = file.getName().substring(0, file.getName().indexOf("."));
                if (f4.listFiles(new FilenameFilter() {
                    public boolean accept(File dir, String name) {
                        return name.startsWith(nm);
                    }
                }).length == 0) {
                    Scanner sc = new Scanner(file);
                    StringBuilder sb = new StringBuilder();
                    while (sc.hasNextLine()) {
                        sb.append(sc.nextLine());
                    }
                    GrappaPanel gp = Dot.getGrappaVisualization(sb.toString(), GraphType.smallNotOrientedGraph);
                    JFrame fr = new JFrame();
                    fr.setSize(new Dimension(800, 600));
                    fr.setContentPane(gp);
                    fr.setVisible(true);
                    Thread.sleep(1000 * 5);
                    UiUtils.saveComponentAsPNG(fr, f4.getAbsolutePath() + "\\" + nm);
                    Thread.sleep(1000 * 5);
                    fr.setVisible(false);
                }
            }*/

    }
/*
    public static void main(String[] args) {
        File f = new File("D:\\TEMP\\NumberPlates1000\\VIDEO\\Etalon_speed\\CSVTests\\week 0909");
        File f2 = new File("D:\\TEMP\\NumberPlates1000\\VIDEO\\Etalon_speed\\merged_4.csv");
        FileFolderUtils.mergeAllFilesInPath(f.getAbsolutePath(),f2);
    }*/
}
