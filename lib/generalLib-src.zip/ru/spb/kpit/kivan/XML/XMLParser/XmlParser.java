package ru.spb.kpit.kivan.XML.XMLParser;

import org.w3c.dom.Document;
import ru.spb.kpit.kivan.XML.XMLGenerator.Node;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathConstants;
import java.io.*;
import java.util.Scanner;

/**
 * User: Kivan(Kivan)
 * Date: 19.08.2007
 * Time: 13:37:30
 */
public class XmlParser {
    public final static String version = "xmlparser(0.1.4)";
    Document doc;
    XPath pather;
    public String root;

    public String getRoot() {
        return root;
    }

    public void setRoot(String root) {
        this.root = root;
    }

    public XmlParser(String XML) {
        this(XML, "");
    }

    public XmlParser(File XMLSrc) {
        this(XMLSrc, "");
    }

    public XmlParser(File XMLSrc, String root) {
        try {
            Scanner sc = new Scanner(XMLSrc);
            StringBuilder sb = new StringBuilder();
            while (sc.hasNextLine()) {
                sb.append(sc.nextLine()).append("\r\n");
            }
            createParser(sb.toString(), root);
        } catch (FileNotFoundException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public XmlParser(String XML, String root) {
        createParser(XML, root);
    }

    private void createParser(String XML, String root) {
        this.root = root;
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            ByteArrayInputStream bis = new ByteArrayInputStream(XML.getBytes());
            doc = db.parse(bis);
            XPathFactory xpf = XPathFactory.newInstance();
            pather = xpf.newXPath();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getStr(String path) {
        try {
            if(!"".equals(root) && root!=null) path = root+"/"+path;
            return pather.evaluate(path, doc);
        } catch (XPathExpressionException e) {
            e.printStackTrace();
        }
        return "";
    }

    public int getNodeCount(String path) {
        try {
            if(!"".equals(root) && root!=null) path = root+"/"+path;
            return ((Number) pather.evaluate(new StringBuilder().append("count(").append(path).append(")").toString(), doc, XPathConstants.NUMBER)).intValue();
        } catch (XPathExpressionException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public String getAttr(String path, String attrName) {
        if(!"".equals(root) && root!=null) path = root+"/"+path;
        try {
            return pather.evaluate(new StringBuilder().append(path).append("/@").append(attrName).toString(), doc);
        } catch (XPathExpressionException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return "";
    }

    public Document getDoc() {
        return doc;
    }

    public XPath getPather() {
        return pather;
    }

    public static void main(String[] args) {
        String sb = new StringBuilder().append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n").append("<formulaGraph>\n").append("<index type=\"index\">\n").append("<IdentifierStructure databaseID=\"Monthly\" type=\"index\"/>\n").append("<element>\n").append("<inputs>\n").append("<input id=\"elem0\"/>\n").append("").append("</inputs>\n").append("</element>\n").append("</index>\n").append("<elem0 type=\" + \">\n").append("<element>\n").append("<inputs>\n").append("<input id=\"elem1\"/>\n").append("<input id=\"elem4\"/>\n").append("</inputs>\n").append("</element>\n").append("</elem0>\n").append("<elem1 type=\" * \">\n").append("<element>\n").append("<inputs>\n").append("<input id=\"elem2\"/>\n").append("<input id=\"elem3\"/>\n").append("<input id=\"elem4\"/>\n").append("</inputs>\n").append("</element>\n").append("</elem1>\n").append("<elem2 type=\"data\">\n").append("<IdentifierStructure databaseID=\"Daily\" type=\"data\"/>\n").append("</elem2>\n").append("<elem3 type=\"data\">\n").append("<IdentifierStructure databaseID=\"Days\" type=\"data\"/>\n").append("</elem3>\n").append("<elem4 type=\" / \">\n").append("<element>\n").append("<inputs>\n").append("<input id=\"elem5\"/>\n").append("<input id=\"elem8\"/>\n").append("</inputs>\n").append("</element>\n").append("</elem4>\n").append("<elem5 type=\" - \">\n").append("<element>\n").append("<inputs>\n").append("<input id=\"elem6\"/>\n").append("<input id=\"elem7\"/>\n").append("</inputs>\n").append("</element>\n").append("</elem5>\n").append("<elem6 type=\"data\">\n").append("<IdentifierStructure databaseID=\"NoWay\" type=\"data\"/>\n").append("</elem6>\n").append("<elem7 type=\"data\">\n").append("<IdentifierStructure databaseID=\"WorkN\" type=\"data\"/>\n").append("</elem7>\n").append("<elem8 type=\"data\">\n").append("<IdentifierStructure databaseID=\"Mcoef\" type=\"data\"/>\n").append("</elem8>\n").append("</formulaGraph>").toString();
        XmlParser parser = new XmlParser(sb, "/formulaGraph");

        SaxXmlToNodeConv converter = new SaxXmlToNodeConv();
        Node root = converter.convertXml(sb);

        System.out.println(parser.getNodeCount(parser.root + "/elem0/element/inputs"));
    }
}
