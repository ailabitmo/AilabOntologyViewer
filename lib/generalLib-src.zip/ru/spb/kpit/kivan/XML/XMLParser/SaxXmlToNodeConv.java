package ru.spb.kpit.kivan.XML.XMLParser;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import ru.spb.kpit.kivan.XML.XMLGenerator.Node;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.StringReader;
import java.util.Stack;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 13.03.13
 * Time: 12:59
 * To change this template use File | Settings | File Templates.
 */
public class SaxXmlToNodeConv {

    static AtomicReference<String> encoding = new AtomicReference<String>("");
    public static void setEncoding(String enc){
        encoding.set(enc);
    }

    SAXParser parser;


    public SaxXmlToNodeConv() {
        try {
            SAXParserFactory spf = SAXParserFactory.newInstance();
            parser = spf.newSAXParser();
            if(!"".equals(encoding.get())) parser.setProperty("encoding",encoding.get());
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public Node convertXml(String xml) {
        return convertXml(new InputSource(new StringReader(xml)));
    }

    public synchronized Node convertXml(InputSource src) {
        Node root = new Node();
        try {
            parser.parse(src, new Handler(root));
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return root;
    }

    public static Node convert(String xmlText) {
        SaxXmlToNodeConv converter = new SaxXmlToNodeConv();
        return converter.convertXml(xmlText);
    }
    public static Node convert(InputSource utfxmlSrc) {
        SaxXmlToNodeConv converter = new SaxXmlToNodeConv();
        return converter.convertXml(utfxmlSrc);
    }
}

class Handler extends DefaultHandler {

    Node root;
    Stack<Node> nodeStack = new Stack<Node>();
    String bufferValue = null;
    boolean nodeOpened = false;

    Handler(Node root) {
        this.root = root;
    }


    public void startDocument() throws SAXException {
        super.startDocument();
    }


    public void endDocument() throws SAXException {
        super.endDocument();    //To change body of overridden methods use File | Settings | File Templates.
    }


    public void startElement(String uri, String localName, String qName, Attributes attributes)
            throws SAXException {
        String name = getRealName(localName, qName);
        Node curNode = null;
        if (root.isEmpty()) {
            root.setName(name);
            curNode = root;
        } else {
            curNode = new Node(name);
            nodeStack.peek().addChild(curNode);
        }
        addAttributes(curNode, attributes);
        nodeStack.push(curNode);
        nodeOpened = true;
        bufferValue = null;
    }


    public void endElement(String uri, String localName, String qName) throws SAXException {
        nodeOpened = false;
        if (bufferValue != null) nodeStack.pop().setValue(bufferValue);
        else nodeStack.pop();
        bufferValue = null;
    }


    public void characters(char[] ch, int start, int length) throws SAXException {
        //���� � ��� ������� �� ������ - �� ������ ���������, ��� ��� - ����������
        if (nodeOpened) {
            String value = new String(ch, start, length);
            if(bufferValue==null) bufferValue = value;
            else bufferValue += value;
        }
    }

    private void addAttributes(Node n, Attributes a) {
        for (int i = 0; i < a.getLength(); i++) {
            String name = getRealName(a.getLocalName(i), a.getQName(i));
            String value = a.getValue(i);
            n.addAttribute(new Node.Attribute(name, value));
        }
    }

    private String getRealName(String localName, String qName) {
        if (!"".equals(localName)) return localName;
        else if (!"".equals(qName)) return qName;
        return null;
    }
}
