package ru.spb.kpit.kivan.XML.XMLSerializer.ComplexTypes;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 13.03.13
 * Time: 23:42
 * To change this template use File | Settings | File Templates.
 */
public class FromXMLProps<T> {
    public T value;
    public String fieldName;
    public boolean isProperty;

    public FromXMLProps(T value, String fieldName, boolean property) {
        this.value = value;
        this.fieldName = fieldName;
        isProperty = property;
    }
}
