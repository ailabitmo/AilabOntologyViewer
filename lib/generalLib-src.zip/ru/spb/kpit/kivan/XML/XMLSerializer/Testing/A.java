package ru.spb.kpit.kivan.XML.XMLSerializer.Testing;

import ru.spb.kpit.kivan.XML.XMLSerializer.Interfaces.IXmlObject;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 13.03.13
 * Time: 18:25
 * To change this template use File | Settings | File Templates.
 */
public class A implements IXmlObject {

    public List<String> strList = new ArrayList<String>();

    public A() {
    }

    A(boolean test) {
        strList.add("123");
        strList.add("345");
    }


    public List<String> getIgnoredFieldsAndProperties() {
        return null;
    }
}
