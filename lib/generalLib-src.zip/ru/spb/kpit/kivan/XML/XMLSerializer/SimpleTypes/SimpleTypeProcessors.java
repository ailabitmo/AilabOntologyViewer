package ru.spb.kpit.kivan.XML.XMLSerializer.SimpleTypes;

import java.text.DateFormat;
import java.util.Date;

class DoubleTypeProcessor extends SimpleTypeProcessor<Double> {


    public String getToXmlValue(Double value) {
        return "" + value;
    }


    public Double getFromXmlValue(String value) {
        Double toRet = null;
        try {
            toRet = Double.parseDouble(value);
        } catch (NumberFormatException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return toRet;
    }


    public boolean checkType(Object value) {
        if (value instanceof Double) return true;
        return false;
    }
}
class FloatTypeProcessor extends SimpleTypeProcessor<Float> {


    public String getToXmlValue(Float value) {
        return "" + value;
    }


    public Float getFromXmlValue(String value) {
        Float toRet = null;
        try {
            toRet = Float.parseFloat(value);
        } catch (NumberFormatException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return toRet;
    }


    public boolean checkType(Object value) {
        if (value instanceof Float) return true;
        return false;
    }
}
class IntTypeProcessor extends SimpleTypeProcessor<Integer> {


    public String getToXmlValue(Integer value) {
        return "" + value;
    }


    public Integer getFromXmlValue(String value) {
        Integer toRet = null;
        try {
            toRet = Integer.parseInt(value);
        } catch (NumberFormatException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return toRet;
    }


    public boolean checkType(Object value) {
        if (value instanceof Integer) return true;
        return false;
    }
}
class LongTypeProcessor extends SimpleTypeProcessor<Long> {


    public String getToXmlValue(Long value) {
        return "" + value;
    }


    public Long getFromXmlValue(String value) {
        Long toRet = null;
        try {
            toRet = Long.parseLong(value);
        } catch (NumberFormatException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return toRet;
    }


    public boolean checkType(Object value) {
        if (value instanceof Long) return true;
        return false;
    }
}
class BoolTypeProcessor extends SimpleTypeProcessor<Boolean> {


    public String getToXmlValue(Boolean value) {
        return "" + value;
    }


    public Boolean getFromXmlValue(String value) {
        Boolean toRet = null;
        try {
            toRet = Boolean.parseBoolean(value);
        } catch (NumberFormatException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return toRet;
    }


    public boolean checkType(Object value) {
        if (value instanceof Boolean) return true;
        return false;
    }
}
class DateTypeProcessor extends SimpleTypeProcessor<Date> {


    public String getToXmlValue(Date value) {
        return DateFormat.getInstance().format(value);
    }


    public Date getFromXmlValue(String value) {
        Date toRet = null;
        try {
            toRet = DateFormat.getInstance().parse(value);
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return toRet;
    }


    public boolean checkType(Object value) {
        if (value instanceof Date) return true;
        return false;
    }
}
class StringTypeProcessor extends SimpleTypeProcessor<String> {

    public String getToXmlValue(String value) {
        return value;
    }


    public String getFromXmlValue(String value) {
        return value;
    }


    public boolean checkType(Object value) {
        return value instanceof String;
    }
}
