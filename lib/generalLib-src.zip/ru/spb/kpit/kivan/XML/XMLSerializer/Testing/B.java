package ru.spb.kpit.kivan.XML.XMLSerializer.Testing;

import ru.spb.kpit.kivan.General.Time.Ms;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 14.03.13
 * Time: 1:00
 * To change this template use File | Settings | File Templates.
 */
public class B {
    A a1;
    A a2;

    public Date t1;
    List lts = new ArrayList();

    List<Map<A, List>> superList = new ArrayList<Map<A, List>>();

    public A getA1() {
        return a1;
    }

    public void setA1(A a1) {
        this.a1 = a1;
    }

    public A getA2() {
        return a2;
    }

    public void setA2(A a2) {
        this.a2 = a2;
    }

    public List getLts() {
        return lts;
    }

    public void setLts(List lts) {
        this.lts = lts;
    }

    public List<Map<A, List>> getSuperList() {
        return superList;
    }

    public void setSuperList(List<Map<A, List>> superList) {
        this.superList = superList;
    }

    public B() {
    }

    public B(boolean test) {
        a1 = new A(true);
        a2 = new A();
        t1 = new Date();
        lts.add(new Ms(100, 3, 5, 3, 6, 6));
        lts.add(5);
        lts.add("WEEEEE!!!");
        lts.add(new Ms(2, 3, 3, 3, 1, 1));
        lts.add(new ArrayList() {{
            add("Shit happens");
        }});

        superList.add(
                new HashMap<A, List>() {
                    {
                        put(new A(), lts);
                        put(new A(true), lts);
                    }

                }
        );
        superList.add(
                new HashMap<A, List>() {
                    {
                        put(new A(), null);
                        put(new A(), null);
                    }

                }
        );

    }
}
