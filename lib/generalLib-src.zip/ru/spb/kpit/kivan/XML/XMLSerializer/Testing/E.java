package ru.spb.kpit.kivan.XML.XMLSerializer.Testing;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 14.03.13
 * Time: 19:04
 * To change this template use File | Settings | File Templates.
 */
public class E {
    private Date date;
    public Object[] aArray = new Object[4];

    public Date getDate() {
        return new Date(0,0,0);
    }

    public void setDate(Date date) {
        this.date = new Date(0,0,0);
    }

    {
        aArray[0] = new A(true);
        aArray[1] = new A(true);
        aArray[2] = aArray[1];
        aArray[3] = new ArrayList();

        C  c = new C();
        C  c1 = new C();

        date = new Date();

        D d = new D();
        c1.d =d;
                c.d=d;
        d.c = c;
        ((ArrayList)aArray[3]).add(d);
        ((ArrayList)aArray[3]).add(c);
        ((ArrayList)aArray[3]).add(c1);
        ((ArrayList)aArray[3]).add(c1);
    }
}
