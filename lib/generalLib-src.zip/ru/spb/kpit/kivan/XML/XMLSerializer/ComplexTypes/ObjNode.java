package ru.spb.kpit.kivan.XML.XMLSerializer.ComplexTypes;

import ru.spb.kpit.kivan.XML.XMLGenerator.Node;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 14.03.13
 * Time: 15:03
 * To change this template use File | Settings | File Templates.
 */
public class ObjNode extends Node {
    Object correspondingObj = null;

    public Object getCorrespondingObj() {
        return correspondingObj;
    }

    public void setCorrespondingObj(Object correspondingObj) {
        this.correspondingObj = correspondingObj;
    }


    public Object getIdentity() {
        return System.identityHashCode(correspondingObj);
    }


    public void replaceDataFromOtherNode(Node otherNode) {
        super.replaceDataFromOtherNode(otherNode);
        if(otherNode instanceof ObjNode){
            correspondingObj = ((ObjNode) otherNode).getCorrespondingObj();
        }
    }
}
