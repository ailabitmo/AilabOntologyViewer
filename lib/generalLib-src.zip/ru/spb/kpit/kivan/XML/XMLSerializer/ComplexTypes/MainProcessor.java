package ru.spb.kpit.kivan.XML.XMLSerializer.ComplexTypes;

import ru.spb.kpit.kivan.Randomizer.Pair;
import ru.spb.kpit.kivan.XML.XMLConstants;
import ru.spb.kpit.kivan.XML.XMLGenerator.Node;
import ru.spb.kpit.kivan.XML.XMLSerializer.OCreator.ObjenesisStd;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 14.03.13
 * Time: 12:09
 * To change this template use File | Settings | File Templates.
 */
public class MainProcessor {
    List<ComplexTypeProcessor> typeProcessors = new ArrayList<ComplexTypeProcessor>();

    {
        typeProcessors.add(new XmlArrayProcessor(this));
        typeProcessors.add(new SimpleTypeProcessor(this));
        typeProcessors.add(new XmlMapProcessor(this));
        typeProcessors.add(new XmlCollectionProcessor(this));
        typeProcessors.add(new XmlObjectProcessor(this));
    }

    protected HashMap<Integer, Pair<Node, List<Node>>> nodeCache = new HashMap<Integer, Pair<Node, List<Node>>>();
    protected HashMap<Integer, Object> objectIdCache = new HashMap<Integer, Object>();
    protected HashMap<String, Object> objectsWithRef = new HashMap<String, Object>();


    private boolean goodContains(Map map, Object val) {
        for (Object key : map.keySet()) {
            if (key == val) return true;
        }
        return false;
    }

    public Node getNodeFromObject(Object fieldVal, String fieldName) {
        if (fieldVal == null) {
            fieldName = (fieldName != null) ? fieldName : "NULL";
            Node n = new Node(fieldName);
            n.addAttribute(new Node.Attribute("isNull", "1"));
            return n;
        } else if (nodeCache.containsKey(System.identityHashCode(fieldVal))) {
            Pair<Node, List<Node>> cached = nodeCache.get(System.identityHashCode(fieldVal));
            ObjNode toRet = new ObjNode();
            toRet.setCorrespondingObj(fieldVal);
            cached.b.add(toRet);
            if (fieldName != null) toRet.setName(fieldName);
            else toRet.setName(fieldVal.getClass().getSimpleName());
            return toRet;
        } else {
            ComplexTypeProcessor typeProcessor = typeProcessors.get(0);
            for (ComplexTypeProcessor tp : typeProcessors) {
                if (tp.checkTypeToXml(fieldVal)) {
                    typeProcessor = tp;
                    break;
                }
            }
            if (typeProcessor instanceof SimpleTypeProcessor) {
                Node n = getToXmlValue(fieldVal, fieldName);
                return n;
            } else {
                ObjNode nk = new ObjNode();
                int id = System.identityHashCode(fieldVal);
                nodeCache.put(id, new Pair<Node, List<Node>>(nk, new ArrayList<Node>()));
                objectIdCache.put(id, fieldVal);
                Node n = getToXmlValue(fieldVal, fieldName);
                nk.replaceDataFromOtherNode(n);
                nk.setCorrespondingObj(fieldVal);

                /*for (Node nd : nk.getChildren()) {
                    if (nd instanceof ObjNode) {
                        if (nodeCache.containsKey(System.identityHashCode(((ObjNode) nd).correspondingObj))) {
                            List<Node> nodesToFix = nodeCache.get(System.identityHashCode(((ObjNode) nd).correspondingObj)).b;
                            for (Node node : nodesToFix) {
                                String name = node.getName();
                                node.replaceDataFromOtherNode(nk);
                                node.setName(name);
                            }
                            nodeCache.get(System.identityHashCode(((ObjNode) nd).correspondingObj)).b = new ArrayList<Node>();
                        }
                    }
                }*/

                List<Node> nodesToFix = nodeCache.get(System.identityHashCode(fieldVal)).b;
                for (Node node : nodesToFix) {
                    String name = node.getName();
                    node.replaceDataFromOtherNode(nk);
                    node.setName(name);
                }
                nodeCache.get(System.identityHashCode(fieldVal)).b = new ArrayList<Node>();

                return nk;
            }
        }
    }

    protected Node getToXmlValue(Object val, String tagName) {
        for (ComplexTypeProcessor typeProcessor : typeProcessors) {
            if (typeProcessor.checkTypeToXml(val)) return typeProcessor.getToXmlValue(val, tagName);
        }
        return null;
    }

    public FromXMLProps getObjectFromNode(Node val) {
        Object obj = null;
        String fldName = val.getName();
        boolean isProperty = false;
        if (val.getAttributes().containsKey(XMLConstants.IS_PROPERTY)) {
            isProperty = "1".equals(val.getAttributes().get(XMLConstants.IS_PROPERTY));
        }
        if (!val.isNull()) {
            if (val.getAttributes().containsKey("ref")) {
                String id = val.getAttributes().get("ref");
                obj = objectsWithRef.get(id);
            } else {
                obj = null;
                try {
                    String className = val.getAttributes().get(XMLConstants.TYPE_ATR_NAME);

                    boolean simpleType = !val.getAttributes().containsKey(XMLConstants.TYPE_ATR_NAME1);

                    if (simpleType) {
                        FromXMLProps props = getFromXmlValue(val, obj);
                        if (props != null) return props;
                    }
                    Class claZ = Class.forName(className);
                    if(className.contains("AbstractList")){
                        obj = new ArrayList();
                    }
                    else if (className.startsWith("[")) {
                        int length = Integer.parseInt(val.getAttributes().get("lg"));
                        obj = Array.newInstance(claZ.getComponentType(), length);
                    } else {
                        try {
                            Constructor constructor = claZ.getConstructor();
                            obj = constructor.newInstance();

                        } catch (Exception e) {
                            ObjenesisStd ostd = new ObjenesisStd();
                            obj = ostd.newInstance(claZ);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (val.getAttributes().containsKey("pref")) {
                    String id = val.getAttributes().get("pref");
                    objectsWithRef.put(id, obj);
                }
                FromXMLProps props = getFromXmlValue(val, obj);
                if (props != null) return props;
            }
        }
        return new FromXMLProps(obj, fldName, isProperty);
    }

    private FromXMLProps getFromXmlValue(Node value, Object targetObject) {
        try {
            for (ComplexTypeProcessor typeProcessor : typeProcessors)
                if (typeProcessor.checkTypeFromXml(value)) return typeProcessor.getFromXmlValue(value, targetObject);
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }
}
