package ru.spb.kpit.kivan.XML.XMLSerializer.Testing;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 14.03.13
 * Time: 11:35
 * To change this template use File | Settings | File Templates.
 */
public class D {
    public int a=5;
    public C c;

    public D() {
    }


    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        D d = (D) o;

        if (a != d.a) return false;

        return true;
    }


    public int hashCode() {
        int result = a;
        return result;
    }
}
