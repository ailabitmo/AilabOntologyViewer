package ru.spb.kpit.kivan.XML.XMLSerializer.Testing;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 14.03.13
 * Time: 11:34
 * To change this template use File | Settings | File Templates.
 */
public class C {
    public String k = "sfg";
    public D d;

    public C() {
    }


    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        C c = (C) o;

        if (k != null ? !k.equals(c.k) : c.k != null) return false;

        return true;
    }


    public int hashCode() {
        int result = k != null ? k.hashCode() : 0;
        return result;
    }
}
