package ru.spb.kpit.kivan.XML.XMLSerializer.ComplexTypes;

import ru.spb.kpit.kivan.XML.XMLConstants;
import ru.spb.kpit.kivan.XML.XMLGenerator.Node;
import ru.spb.kpit.kivan.XML.XMLSerializer.Interfaces.IXmlObject;
import ru.spb.kpit.kivan.XML.XMLSerializer.SimpleTypes.SimpleType;

import java.lang.reflect.*;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 13.03.13
 * Time: 12:10
 * To change this template use File | Settings | File Templates.
 */

class XmlArrayProcessor extends ComplexTypeProcessor {

    protected XmlArrayProcessor(MainProcessor mainP) {
        super(mainP);
    }


    public Node getToXmlValue(Object value, String tagName) {
        if (tagName == null) {
            tagName = "ARR_" + value.getClass().getSimpleName().replace("[]", "");
        }
        Node root = new Node(tagName);
        root.addAttribute(new Node.Attribute(XMLConstants.TYPE_ATR_NAME, value.getClass().getName()));
        root.addAttribute(new Node.Attribute(XMLConstants.TYPE_ATR_NAME1, ComplexType.XmlArr.name()));
        int arrayLength = Array.getLength(value);
        root.addAttribute(new Node.Attribute("lg", arrayLength + ""));

        for (int i = 0; i < arrayLength; i++) {
            Object nodeVal = null;
            try {
                nodeVal = Array.get(value, i);
            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
            Node child = mainP.getNodeFromObject(nodeVal, null);
            if (child != null) root.addChild(child);
        }
        return root;
    }


    public FromXMLProps getFromXmlValue(Node value, Object array) {
        try {
            int i = 0;
            for (Node node : value.getChildren()) {
                FromXMLProps childReal = mainP.getObjectFromNode(node);
                Array.set(array, i++, childReal.value);
            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }


    public boolean checkTypeToXml(Object value) {
        if (value.getClass().getName().startsWith("[")) return true;
        return false;
    }


    public boolean checkTypeFromXml(Node value) {
        return value.getAttributes().containsKey(XMLConstants.TYPE_ATR_NAME1)
                && ComplexType.XmlArr.name().equals(value.getAttributes().get(XMLConstants.TYPE_ATR_NAME1));
    }
}

class XmlCollectionProcessor extends ComplexTypeProcessor<Collection> {
    protected XmlCollectionProcessor(MainProcessor mainP) {
        super(mainP);
    }


    public Node getToXmlValue(Collection value, String tagName) {
        if (tagName == null) tagName = value.getClass().getSimpleName();
        Node root = new Node(tagName);
        Class parentType = ComplexType.getGoodTYpe(value.getClass());
        //���� �������� �� �������� ����������
        if (!(Collection.class.isAssignableFrom(parentType)))
            root.addAttribute(new Node.Attribute(XMLConstants.TYPE_ATR_NAME, ArrayList.class.getName()));
        else root.addAttribute(new Node.Attribute(XMLConstants.TYPE_ATR_NAME, parentType.getName()));

        root.addAttribute(new Node.Attribute(XMLConstants.TYPE_ATR_NAME1, ComplexType.XmlCol.name()));
        for (Object obj : value) {
            Node child = mainP.getNodeFromObject(obj, null);
            if (child != null) root.addChild(child);
        }
        return root;
    }


    public FromXMLProps getFromXmlValue(Node value, Object targetObject) {
        try {
            Collection col = (Collection) targetObject;
            for (Node node : value.getChildren()) {
                FromXMLProps childReal = mainP.getObjectFromNode(node);
                col.add(childReal.value);
            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }


    public boolean checkTypeToXml(Object value) {
        return value instanceof Collection;
    }


    public boolean checkTypeFromXml(Node value) {
        return value.getAttributes().containsKey(XMLConstants.TYPE_ATR_NAME1)
                && ComplexType.XmlCol.name().equals(value.getAttributes().get(XMLConstants.TYPE_ATR_NAME1));
    }
}

class XmlMapProcessor extends ComplexTypeProcessor<Map> {
    protected XmlMapProcessor(MainProcessor mainP) {
        super(mainP);
    }


    public Node getToXmlValue(Map value, String tagName) {
        if (tagName == null) tagName = value.getClass().getSimpleName();
        Node root = new Node(tagName);

        Class parentType = ComplexType.getGoodTYpe(value.getClass());
        //���� �������� �� �������� ����������
        if (!(Collection.class.isAssignableFrom(parentType)))
            root.addAttribute(new Node.Attribute(XMLConstants.TYPE_ATR_NAME, HashMap.class.getName()));
        else root.addAttribute(new Node.Attribute(XMLConstants.TYPE_ATR_NAME, parentType.getName()));

        root.addAttribute(new Node.Attribute(XMLConstants.TYPE_ATR_NAME1, ComplexType.XmlMap.name()));
        for (Object key : value.keySet()) {
            //Node entryNode = new Node(XMLConstants.ENTRY_TAG);
            Node keyNode = mainP.getNodeFromObject(key, "KEY");
            Node valNode = mainP.getNodeFromObject(value.get(key), "VAL");
            if (keyNode != null && valNode != null) {
                root.addChild(keyNode).addChild(valNode);
            }
        }

        return root;
    }


    public FromXMLProps getFromXmlValue(Node mapNode, Object targetObject) {
        try {
            Map map = (Map) targetObject;
            List<Node> childList = mapNode.getChildren();
            for (int i = 0; i < childList.size(); i = i + 2) {
                Node key = childList.get(i);
                Node val = childList.get(i + 1);
                FromXMLProps keyReal = mainP.getObjectFromNode(key);
                FromXMLProps valReal = mainP.getObjectFromNode(val);
                map.put(keyReal.value, valReal.value);
            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }


    public boolean checkTypeToXml(Object value) {
        return value instanceof Map;
    }


    public boolean checkTypeFromXml(Node value) {
        return value.getAttributes().containsKey(XMLConstants.TYPE_ATR_NAME1)
                && ComplexType.XmlMap.name().equals(value.getAttributes().get(XMLConstants.TYPE_ATR_NAME1));
    }
}

class XmlObjectProcessor extends ComplexTypeProcessor<Object> {

    HashMap<Object, Node> cachedNodes = new HashMap<Object, Node>();

    protected XmlObjectProcessor(MainProcessor mainP) {
        super(mainP);
    }


    public Node getToXmlValue(Object objectToSerialize, String tagName) {
        List<String> ignored = new ArrayList<String>();
        if (objectToSerialize instanceof IXmlObject)
            ignored = ((IXmlObject) objectToSerialize).getIgnoredFieldsAndProperties();
        if (ignored == null) ignored = new ArrayList<String>();
        Node root = null;
        try {
            Set<String> usedFields = new HashSet<String>();

            if (tagName == null) tagName = objectToSerialize.getClass().getSimpleName();
            Class cls = objectToSerialize.getClass();
            root = new Node(tagName, new Node.Attributes(new Node.Attribute(XMLConstants.TYPE_ATR_NAME, ComplexType.getGoodTYpe(objectToSerialize.getClass()).getName()),
                    new Node.Attribute(XMLConstants.TYPE_ATR_NAME1, ComplexType.XmlObj.name())));

            List<Field> allFields = new ArrayList<Field>();
            ComplexType.getAllFieldsOfClass(cls, allFields);

            boolean allowedSetAccessible = true;
            for (Field fld : allFields) {
                if (allowedSetAccessible) {
                    try {
                        fld.setAccessible(true);
                    } catch (SecurityException e) {
                        allowedSetAccessible = false;
                    }
                }
                String fieldName = fld.getName();
                if (!ignored.contains(fieldName) && !Modifier.isStatic(fld.getModifiers()))
                    try {
                        Object fieldValue = fld.get(objectToSerialize);
                        usedFields.add(fieldName.toLowerCase());
                        Node fieldNode = mainP.getNodeFromObject(fieldValue, fieldName);
                        if (fieldNode != null)
                            root.addChild(fieldNode);
                    } catch (IllegalAccessException e) {
                    }
            }
            if (!allowedSetAccessible) {
                List<Method> methods = new ArrayList<Method>();
                ComplexType.getAllMethodsOfClass(cls, methods);
                for (Method possibleGetter : methods) {
                    //���� ���� ������
                    if (possibleGetter.getName().startsWith("get") && possibleGetter.getName().length() > 3 && possibleGetter.getParameterTypes().length == 0) {

                        String propName = possibleGetter.getName().substring(3);
                        propName = (propName.charAt(0) + "").toLowerCase() + propName.substring(1);

                        if (!ignored.contains(propName) && !usedFields.contains(propName.toLowerCase()))
                            //������� ���� ������.
                            for (Method possibleSetter : methods) {
                                if (possibleSetter.getName().equalsIgnoreCase("set" + propName)
                                        && possibleSetter.getParameterTypes().length == 1
                                        && possibleSetter.getParameterTypes()[0].getName().
                                        equals(possibleGetter.getReturnType().getName())) {
                                    //����� � ������ � ������. ���, �����������
                                    Object fieldValue = possibleGetter.invoke(objectToSerialize);
                                    Node fieldNode = mainP.getNodeFromObject(fieldValue, propName);
                                    if (fieldNode != null) {
                                        fieldNode.addAttribute(new Node.Attribute(XMLConstants.IS_PROPERTY, "1"));
                                        root.addChild(fieldNode);
                                    }
                                    break;
                                }
                            }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return root;
    }


    public FromXMLProps getFromXmlValue(Node value, Object targetObject) {

        String className = value.getAttributes().get(XMLConstants.TYPE_ATR_NAME);
        try {
            Class claZ = Class.forName(className);
            Object obj = targetObject;
            for (Node node : value.getChildren()) {
                FromXMLProps fieldValReal = mainP.getObjectFromNode(node);
                boolean setAccessible = true;
                if (!fieldValReal.isProperty) {
                    List<Field> allFields = new ArrayList<Field>();
                    ComplexType.getAllFieldsOfClass(claZ, allFields);
                    Field f = null;
                    for (Field field : allFields) {
                        if (field.getName().equals(fieldValReal.fieldName)) {
                            f = field;
                            break;
                        }
                    }

                    try {
                        f.setAccessible(true);
                        f.set(obj, fieldValReal.value);
                    } catch (SecurityException e) {
                        setAccessible = false;
                    } catch (Exception e) {
                    }
                }
                if (fieldValReal.isProperty || !setAccessible) {
                    String propName = fieldValReal.fieldName;
                    Method setter = null;
                    List<Method> methods = new ArrayList<Method>();
                    ComplexType.getAllMethodsOfClass(claZ, methods);
                    for (Method method : methods) {
                        if (method.getName().equalsIgnoreCase("set" + propName)) {
                            setter = method;
                            break;
                        }
                    }
                    setter.invoke(obj, fieldValReal.value);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }


    public boolean checkTypeToXml(Object value) {
        return value instanceof Object;
    }


    public boolean checkTypeFromXml(Node value) {
        return value.getAttributes().containsKey(XMLConstants.TYPE_ATR_NAME1)
                && ComplexType.XmlObj.name().equals(value.getAttributes().get(XMLConstants.TYPE_ATR_NAME1));

    }
}

class SimpleTypeProcessor extends ComplexTypeProcessor {
    protected SimpleTypeProcessor(MainProcessor mainP) {
        super(mainP);
    }


    public Node getToXmlValue(Object value, String tagName) {
        SimpleType.TypeAndVal tav = SimpleType.getToXmlValue(value);
        if (tagName == null) tagName = tav.typeName;
        return new Node(tagName, tav.xmlVal, new Node.Attributes(new Node.Attribute(XMLConstants.TYPE_ATR_NAME, tav.typeName)));
    }


    public FromXMLProps getFromXmlValue(Node value, Object targetObject) {
        String name = value.getName();
        String type = value.getAttributes().get(XMLConstants.TYPE_ATR_NAME);
        Object val = SimpleType.getFromXmlValue(type, value.getValue());
        boolean isProperty = false;
        if (value.getAttributes().containsKey(XMLConstants.IS_PROPERTY)) {
            isProperty = "1".equals(value.getAttributes().get(XMLConstants.IS_PROPERTY));
        }
        FromXMLProps props = new FromXMLProps(val, name, isProperty);
        return props;
    }


    public boolean checkTypeToXml(Object value) {
        return SimpleType.getToXmlValue(value) != null;
    }


    public boolean checkTypeFromXml(Node value) {
        if (value != null) {
            if (!value.getAttributes().containsKey(XMLConstants.TYPE_ATR_NAME1)) return true;
        }
        return false;
    }
}
