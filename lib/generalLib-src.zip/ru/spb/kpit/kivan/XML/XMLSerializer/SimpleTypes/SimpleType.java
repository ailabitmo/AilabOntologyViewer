package ru.spb.kpit.kivan.XML.XMLSerializer.SimpleTypes;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 13.03.13
 * Time: 10:46
 * To change this template use File | Settings | File Templates.
 */
public enum SimpleType {
    Double(new DoubleTypeProcessor()), Long(new LongTypeProcessor()), Float(new FloatTypeProcessor()), Int(new IntTypeProcessor()),
    String(new StringTypeProcessor()), Date(new DateTypeProcessor()), Bool(new BoolTypeProcessor());

    SimpleTypeProcessor typeProcessor;
    SimpleType(SimpleTypeProcessor typeProcessor) {
        this.typeProcessor = typeProcessor;
    }

    public static TypeAndVal getToXmlValue(Object val){
        for (SimpleType type : SimpleType.values()) {
            if(type.typeProcessor.checkType(val)) return new TypeAndVal(type.name(),type.typeProcessor.getToXmlValue(val));
        }
        return null;
    }

    public static class TypeAndVal{
        public String typeName;
        public String xmlVal;

        TypeAndVal(String typeName, String xmlVal) {
            this.typeName = typeName;
            this.xmlVal = xmlVal;
        }
    }

    public static Object getFromXmlValue(String typename, String value){
        Object toRet=null;
        try {
            SimpleType st = SimpleType.valueOf(typename);
            toRet = st.typeProcessor.getFromXmlValue(value);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return toRet;
    }
}

