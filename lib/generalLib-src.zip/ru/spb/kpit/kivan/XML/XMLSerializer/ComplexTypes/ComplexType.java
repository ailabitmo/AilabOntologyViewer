package ru.spb.kpit.kivan.XML.XMLSerializer.ComplexTypes;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 13.03.13
 * Time: 10:45
 * To change this template use File | Settings | File Templates.
 */
public enum ComplexType {
    XmlArr,XmlCol,XmlMap,
    SmplTyp,XmlObj;

    public static Class getGoodTYpe(Class objClass){
        if(objClass.getName().contains("$")) return getGoodTYpe(objClass.getSuperclass());
        else return objClass;
    }

    public static void getAllFieldsOfClass(Class c, List<Field> alreadyFields){
        Field[] curClassList =  c.getDeclaredFields();
        alreadyFields.addAll(Arrays.asList(curClassList));
        if(c.getSuperclass()!=null){
            getAllFieldsOfClass(c.getSuperclass(), alreadyFields);
        }
    }

    public static void getAllMethodsOfClass(Class c, List<Method> alreadyMethods){
        Method[] curClassList =  c.getMethods();
        alreadyMethods.addAll(Arrays.asList(curClassList));
        if(c.getSuperclass()!=null){
            getAllMethodsOfClass(c.getSuperclass(), alreadyMethods);
        }
    }
}
