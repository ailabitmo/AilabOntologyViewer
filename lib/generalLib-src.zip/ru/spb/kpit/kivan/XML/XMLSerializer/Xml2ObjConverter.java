package ru.spb.kpit.kivan.XML.XMLSerializer;

import org.xml.sax.InputSource;
import ru.spb.kpit.kivan.General.FileSystem.FileFolderUtils;
import ru.spb.kpit.kivan.XML.XMLGenerator.Node;
import ru.spb.kpit.kivan.XML.XMLParser.SaxXmlToNodeConv;
import ru.spb.kpit.kivan.XML.XMLSerializer.ComplexTypes.MainProcessor;
import ru.spb.kpit.kivan.XML.XMLSerializer.Testing.E;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Writer;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 13.03.13
 * Time: 10:21
 * To change this template use File | Settings | File Templates.
 */
public class Xml2ObjConverter {
    public static void saveObject(Object obj, String rootTag, File toFile){
        try {
            Node node = convertObject(obj, rootTag);
            String strXml = node.getXML();
            FileFolderUtils.writeToFile(toFile.getAbsolutePath(),strXml, false);
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }
    public static Node convertObject(Object obj, String rootTag){
        try {
            MainProcessor mp = new MainProcessor();
            return mp.getNodeFromObject(obj, rootTag);
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }
    public static Object convertObject(Node obj){
        try {
            MainProcessor mp = new MainProcessor();
            return mp.getObjectFromNode(obj).value;
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }
    public static Object restoreObject(String xml){
        try {
            Node root = SaxXmlToNodeConv.convert(xml);
            MainProcessor mp = new MainProcessor();
            return mp.getObjectFromNode(root).value;
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }
    public static Object restoreObject(File f){
        try {
            Node root = SaxXmlToNodeConv.convert(new InputSource(new FileInputStream(f)));
            MainProcessor mp = new MainProcessor();
            return mp.getObjectFromNode(root).value;
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }

    public static void main(String[] args) throws Exception {
        /*C c = new C();
        D d = new D();
        c.d = d;
        d.c = c;
        makeExperiment(c);*/
        //makeExperiment(new B(true));
        /*makeExperiment(new A(true));*/

        /*Node xml = Xml2ObjConverter.saveObject(new TimeStructure(), null);*/
        /*makeExperiment(new JTable());*/

        makeExperiment(new E());
    }

    private static void makeExperiment(Object toExperiment){
        Node xml = Xml2ObjConverter.convertObject(toExperiment, null);
        try {
            Writer fw = FileFolderUtils.getUtf8FileWriter("D:\\TEMP\\TESTS\\"+toExperiment.getClass().getSimpleName()+".xml");
            fw.append(xml.getXML());
            fw.close();

            String xmlText = FileFolderUtils.getFileContents("D:\\TEMP\\TESTS\\"+toExperiment.getClass().getSimpleName()+".xml");
            Node root = SaxXmlToNodeConv.convert(xmlText);

            Object  cvt2 = Xml2ObjConverter.convertObject(root);
            cvt2.equals(toExperiment);
            int k = 0;
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

    }

}


