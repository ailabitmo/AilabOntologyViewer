package ru.spb.kpit.kivan.XML.XMLGenerator;

import ru.spb.kpit.kivan.General.Strings.XmlStringCleaner;
import ru.spb.kpit.kivan.General.UniqueIdGenerator;
import ru.spb.kpit.kivan.Randomizer.Pair;
import ru.spb.kpit.kivan.General.DataStructures.Arr;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.dom.DOMSource;
import java.util.*;
import java.io.StringWriter;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import ru.spb.kpit.kivan.XML.XMLParser.SaxXmlToNodeConv;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 31.05.2011
 * Time: 11:14:10
 * To change this template use File | Settings | File Templates.
 * <p/>
 * NODE of XML document
 */
public class Node {
    String name = null;
    String value;
    Map<String, String> attributes = new HashMap<String, String>(0);
    List<Node> children = new ArrayList<Node>(0);

    //addReplacement('&',"");
    //addReplacement('#',"");
        /*addReplacement('<',"");
        addReplacement('>',"");*/
    //addReplacement('\'',"");
    //addReplacement('"',"");
    //addReplacement('/',"");

    static XmlStringCleaner xmlStringCleanerNodes = new XmlStringCleaner('<','>');
    static XmlStringCleaner xmlStringCleanerAttrs = new XmlStringCleaner('"','\'');
    static XmlStringCleaner xmlStringCleanerAll = new XmlStringCleaner('"','\'','&','<','>','/','\\','#');

    public static Node createNodeFromXml(String xml) {
        return SaxXmlToNodeConv.convert(xml);
    }

    public Node() {
    }

    public Node(String name) {
        this.name = remBadCharsAll(name);
    }

    public Node(String name, String value) {
        this(name);
        this.value = remBadCharsNodes(value);
    }

    public Node(String name, Attributes attrs) {
        this(name);
        this.attributes = new HashMap<String, String>();
        for (Attribute nameValue : attrs.arr) {
            getAttributes().put(nameValue.a, nameValue.b);
        }
    }

    public Node(String name, String value, Attributes attrs) {
        this(name, attrs);
        this.value = remBadCharsNodes(value);
    }

    public Node(String name, Nodes childrenito) {
        this(name);
        children = new ArrayList<Node>(Arrays.asList(childrenito.arr));
    }

    public Node(String name, Attributes attrs, Nodes children) {
        this(name, attrs);
        this.children = new ArrayList<Node>(Arrays.asList(children.arr));
    }

    public void replaceDataFromOtherNode(Node otherNode) {
        if (otherNode != null) {
            setName(otherNode.getName());
            setValue(otherNode.getValue());
            setChildren(otherNode.getChildren());
            setAttributes(otherNode.getAttributes());
        }
    }

    public void setName(String name) {
        this.name = remBadCharsAll(name);
    }

    public void setValue(String value) {
        this.value = remBadCharsNodes(value);
    }

    public void setAttributes(Map<String, String> attributes) {
        this.attributes = attributes;
    }

    public void setChildren(List<Node> children) {
        this.children = children;
    }

    public Node addChildren(Nodes children) {
        this.getChildren().addAll(new ArrayList<Node>(Arrays.asList(children.arr)));
        return this;
    }

    public Node addChild(Node child) {
        if (child != null) getChildren().add(child);
        return this;
    }

    public Node addAttribute(Attribute attribute) {
        getAttributes().put(attribute.a, attribute.b);
        return this;
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

    public Map<String, String> getAttributes() {
        return attributes;
    }

    public List<Node> getChildren() {
        return children;
    }

    public boolean isEmpty() {
        return getName() == null;
    }

    public boolean isNull() {
        if (getAttributes().containsKey("isNull")) return true;
        return false;
    }

    public Object getIdentity() {
        return this;
    }


    public String toString() {
        return getName() + "->" + getValue();
    }

    public static class Attributes extends Arr<Attribute> {
        public Attributes(Attribute... arr) {
            super(arr);
        }
    }

    public static class Nodes extends Arr<Node> {
        public Nodes(Node... arr) {
            super(arr);
        }
    }

    public static class Attribute extends Pair<String, String> {
        public Attribute(String name, String val) {
            super(remBadCharsAll(name), remBadCharsAttrs(val));
        }
    }
    public static class Attr extends Attribute {
        public Attr(String name, String val) {
            super(name, val);
        }
    }

    public String getXML() {
        try {
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

            Document doc = documentBuilder.newDocument();
            addNode(doc, null, new HashMap<Object, Pair<Element, Long>>(), true);
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "3");
            StringWriter sw = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(sw));
            return sw.toString();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (TransformerException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }

    //����� �������� ��� ��� ��������� �� ����������� ����������
    //���������� ����������, �� �� ���������������� � ���������
    public String getXML(boolean showAttributes) {
        try {
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

            Document doc = documentBuilder.newDocument();
            addNode(doc, null, new HashMap<Object, Pair<Element, Long>>(), showAttributes);

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "3");
            StringWriter sw = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(sw));
            return sw.toString();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (TransformerException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }

    protected void addNode(Document doc, Element parent, HashMap<Object, Pair<Element, Long>> cache, boolean showAttributes) {
        Element curElem;
        Object identity = this.getIdentity();
        if (identity != null && cache.containsKey(identity)) {
            curElem = cache.get(identity).a;
            curElem.setAttribute("pref", cache.get(identity).b + "");
            curElem = doc.createElement(getName());
            if (showAttributes)
                for (Map.Entry<String, String> nameValue : getAttributes().entrySet()) {
                    curElem.setAttribute(nameValue.getKey(), nameValue.getValue());
                }
            curElem.setAttribute("ref", cache.get(identity).b + "");
        } else {
            curElem = doc.createElement(getName());
            cache.put(identity, new Pair<Element, Long>(curElem, UniqueIdGenerator.nextId()));

            if (getValue() != null) {
                curElem.setTextContent(getValue());
            }

            if (showAttributes)
                for (Map.Entry<String, String> nameValue : getAttributes().entrySet()) {
                    curElem.setAttribute(nameValue.getKey(), nameValue.getValue());
                }

            for (Node child : getChildren()) {
                child.addNode(doc, curElem, cache, showAttributes);
            }
        }
        if (parent != null) parent.appendChild(curElem);
        else doc.appendChild(curElem);
    }

    public static String remBadCharsAll(String check) {
        if (check != null)
            return xmlStringCleanerAll.replace(check);
        return "";
    }
    public static String remBadCharsNodes(String check) {
        if (check != null)
            return xmlStringCleanerNodes.replace(check);
        return "";
    }
    public static String remBadCharsAttrs(String check) {
        if (check != null)
            return xmlStringCleanerAttrs.replace(check);
        return "";
    }
}
