package ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects;

import java.util.HashMap;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 10:03
 */
public class MinedObject extends HashMap<String, Object> {
}
