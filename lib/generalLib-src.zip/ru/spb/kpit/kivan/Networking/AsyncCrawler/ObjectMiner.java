package ru.spb.kpit.kivan.Networking.AsyncCrawler;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 01.09.13
 * Time: 12:00
 * To change this template use File | Settings | File Templates.
 */
public interface ObjectMiner<A> {
    public A createObjectFromHTML(String html,String url);
}
