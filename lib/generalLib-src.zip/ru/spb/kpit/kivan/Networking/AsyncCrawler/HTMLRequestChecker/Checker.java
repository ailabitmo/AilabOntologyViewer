package ru.spb.kpit.kivan.Networking.AsyncCrawler.HTMLRequestChecker;

import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.SimpleHTMLRequest;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 31.08.13
 * Time: 2:15
 * To change this template use File | Settings | File Templates.
 */
public interface Checker {
    public boolean checkRequest(SimpleHTMLRequest request);
}
