package ru.spb.kpit.kivan.Networking.AsyncCrawler.Calbacker;

import ru.spb.kpit.kivan.General.OperationInfo.HtmlOperationInfo;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 31.08.13
 * Time: 21:15
 * To change this template use File | Settings | File Templates.
 */
public interface HTMLCallbacker extends UniCallBacker<String, HtmlOperationInfo> {}
