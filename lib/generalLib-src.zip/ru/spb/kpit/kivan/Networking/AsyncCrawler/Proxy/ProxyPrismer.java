package ru.spb.kpit.kivan.Networking.AsyncCrawler.Proxy;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 15:47
 */
public abstract class ProxyPrismer {
    public abstract String getInfo();
    public abstract String getRequestStringForProxy(String directLink);

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ProxyPrismer that = (ProxyPrismer) o;

        if (getInfo() != null ? !getInfo().equals(that.getInfo()) : that.getInfo() != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        return getInfo() != null ? getInfo().hashCode() : 0;
    }
}
