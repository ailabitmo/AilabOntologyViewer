package ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 10:46
 * Most likely will be used to clear html
 */
public interface StringProcessor {
    public String process(String input);
}
