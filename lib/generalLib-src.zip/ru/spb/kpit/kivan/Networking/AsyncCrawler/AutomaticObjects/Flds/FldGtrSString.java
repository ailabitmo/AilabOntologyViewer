package ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.Flds;

import ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.StringProcessor;
import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors.InfoPiece;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 10:52
 */
public class FldGtrSString extends FldGtrSingle<String> {
    public FldGtrSString(InfoPiece ip) {
        super(ip);
    }

    public FldGtrSString(InfoPiece ip, StringProcessor sp) {
        super(ip, sp);
    }

    @Override
    public String getValFromStr(String text) {
        return text;
    }
}
