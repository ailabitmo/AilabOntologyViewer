package ru.spb.kpit.kivan.Networking.AsyncCrawler;

import ru.spb.kpit.kivan.General.Waiter.Waiter;
import ru.spb.kpit.kivan.Logger_2_0.Logger;
import ru.spb.kpit.kivan.Networking.AsyncCrawler.Calbacker.HTMLCallbacker;
import ru.spb.kpit.kivan.Networking.AsyncCrawler.HTMLRequestChecker.RequestQue;
import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.SimpleHTMLRequest;
import ru.spb.kpit.kivan.Randomizer.Pair;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 31.08.13
 * Time: 0:52
 * To change this template use File | Settings | File Templates.
 */
public class AsyncSiteRequestExecutor {
    long requestNum = 0;
    String nameOfRequester = "";
    RequestQue queue = new RequestQue();
    Waiter nextTimeModel;
    AtomicBoolean finished = new AtomicBoolean(false);
    Thread processingThread = new Thread(new Runnable() {
        public void run() {
            while (!finished.get()) {
                try {
                    Long endTime = 0l;
                    Long startTime = System.currentTimeMillis();
                    SimpleHTMLRequest request;
                    HTMLCallbacker callbacker;
                    Pair<SimpleHTMLRequest, HTMLCallbacker> randomned = queue.getValue();
                    if (randomned != null) {
                        request = randomned.a;
                        callbacker = randomned.b;
                        String result = request.executeRequest();
                        request.getInfo().setRequestNumber((int) (requestNum++));
                        callbacker.callBack(result, request.getInfo());
                        endTime = System.currentTimeMillis() - startTime;
                    }
                    long sleepTime = nextTimeModel.getNextWaitTime(endTime);
                    Logger.l2o.info("Requester:"+ nameOfRequester+" sleep:"+(double)sleepTime/1000+"sec");
                    Thread.sleep(sleepTime);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    });

    public AsyncSiteRequestExecutor(String nameOfRequester, Waiter nextTimeModel) {
        this.nameOfRequester = nameOfRequester;
        this.nextTimeModel = nextTimeModel;
    }

    public boolean addTask(SimpleHTMLRequest simpleHTMLRequest, HTMLCallbacker callBack, boolean orderedAndPriority) {
        if (!processingThread.isAlive() && !finished.get()) {
            //processingThread.setDaemon(true);
            processingThread.start();
        }
        return queue.addValue(simpleHTMLRequest, callBack, orderedAndPriority);
    }

    public String getNameOfRequester() {
        return nameOfRequester;
    }

    public void setNameOfRequester(String nameOfRequester) {
        this.nameOfRequester = nameOfRequester;
    }

    public void finish() {
        finished.set(true);
        processingThread.interrupt();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AsyncSiteRequestExecutor that = (AsyncSiteRequestExecutor) o;

        if (nameOfRequester != null ? !nameOfRequester.equals(that.nameOfRequester) : that.nameOfRequester != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        return nameOfRequester != null ? nameOfRequester.hashCode() : 0;
    }
}
