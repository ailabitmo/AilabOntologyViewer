package ru.spb.kpit.kivan.Networking.AsyncCrawler;

import ru.spb.kpit.kivan.Logger_2_0.Logger;
import ru.spb.kpit.kivan.Networking.AsyncCrawler.Calbacker.HTMLCallbacker;
import ru.spb.kpit.kivan.Networking.AsyncCrawler.Calbacker.UniCallBacker;
import ru.spb.kpit.kivan.General.OperationInfo.GoodBadOperationInfo;
import ru.spb.kpit.kivan.General.OperationInfo.HtmlOperationInfo;
import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.SimpleHTMLRequest;
import ru.spb.kpit.kivan.Networking.MaskUserProperies;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 31.08.13
 * Time: 0:01
 * To change this template use File | Settings | File Templates.
 */
public class AsyncRequest<A> {

    String name = "";
    SiteRequesterPool poolOfRequesters;
    ObjectMiner<A> miner;
    MaskUserProperies maskUser = null;
    AsyncSiteCrawler asc = null;

    public AsyncRequest(SiteRequesterPool poolOfRequesters, ObjectMiner<A> miner) {
        this.poolOfRequesters = poolOfRequesters;
        this.miner = miner;
    }

    public AsyncRequest(AsyncSiteCrawler asc, SiteRequesterPool poolOfRequesters, ObjectMiner<A> miner) {
        this.poolOfRequesters = poolOfRequesters;
        this.miner = miner;
        this.asc = asc;
    }

    public AsyncRequest(String requestName, AsyncSiteCrawler asc, SiteRequesterPool poolOfRequesters, ObjectMiner<A> miner) {
        this.poolOfRequesters = poolOfRequesters;
        this.miner = miner;
        this.asc = asc;
        name = requestName;
    }

    public AsyncRequest(SiteRequesterPool poolOfRequesters, ObjectMiner<A> miner, MaskUserProperies maskUser) {
        this.poolOfRequesters = poolOfRequesters;
        this.miner = miner;
        this.maskUser = maskUser;
    }

    public AsyncRequest(AsyncSiteCrawler asc,SiteRequesterPool poolOfRequesters, ObjectMiner<A> miner, MaskUserProperies maskUser) {
        this.poolOfRequesters = poolOfRequesters;
        this.asc = asc;
        this.miner = miner;
        this.maskUser = maskUser;
    }
    public AsyncRequest(String requestName,AsyncSiteCrawler asc,SiteRequesterPool poolOfRequesters, ObjectMiner<A> miner, MaskUserProperies maskUser) {
        this.poolOfRequesters = poolOfRequesters;
        this.asc = asc;
        this.miner = miner;
        this.maskUser = maskUser;
        name = requestName;
    }

    public void process(SimpleHTMLRequest request, final UniCallBacker<A, GoodBadOperationInfo> callbacker, boolean orderedAndPriority)  {
        request.setMaskUser(maskUser);
        SiteRequesterWithCheckExecutor requester = poolOfRequesters.getExecutor(request);
        if (requester == null) {
            System.out.println("Requester was not found for URL:" + request.getUrl());
            return;
        }
        requester.addTask(request, new HTMLCallbacker() {
            public void callBack(String htmlPageWithObject, HtmlOperationInfo techInfo) {
                A toRet = null;
                GoodBadOperationInfo op = new GoodBadOperationInfo();
                try {
                    Logger.l2o.info("-------------HtmlOperationInfo----------------");
                    Logger.l2o.info(techInfo.operationReport());
                    toRet = miner.createObjectFromHTML(htmlPageWithObject, techInfo.getUrl());
                    op = new GoodBadOperationInfo();
                    op.setOperationSuccessfull(true);
                } catch (Exception e){
                    e.printStackTrace();
                    op.setOperationSuccessfull(false);
                }finally {
                    if(asc!=null) asc.removeVisitingLink(name, techInfo.getUrl());
                    try {
                        callbacker.callBack(toRet, op);
                    } catch (Exception e) {
                        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                    }
                }
            }
        },orderedAndPriority);

        if(asc!=null) asc.addVisitingLink(request.getUrl());
    }
}
