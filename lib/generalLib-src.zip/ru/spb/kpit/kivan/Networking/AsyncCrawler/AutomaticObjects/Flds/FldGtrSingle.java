package ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.Flds;

import ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.StringProcessor;
import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors.InfoPiece;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 10:06
 */
public abstract class FldGtrSingle<A> implements FldGtr<A>,ValGetter<A> {
    InfoPiece ip;
    StringProcessor sp = null;

    public FldGtrSingle(InfoPiece ip) {
        this.ip = ip;
    }

    public FldGtrSingle(InfoPiece ip, StringProcessor sp) {
        this.ip = ip;
        this.sp = sp;
    }

    public A createObjectFromHTML(String html) {
        String value = ip.getValue(html);
        if(value==null) return null;
        if(sp!=null) return getValFromStr(sp.process(value));
        return getValFromStr(value);
    }
}
