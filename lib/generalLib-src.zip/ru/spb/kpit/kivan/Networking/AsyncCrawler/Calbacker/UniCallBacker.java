package ru.spb.kpit.kivan.Networking.AsyncCrawler.Calbacker;

import ru.spb.kpit.kivan.General.OperationInfo.OperationInfo;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 30.08.13
 * Time: 23:50
 * To change this template use File | Settings | File Templates.
 */
public interface UniCallBacker<A, B extends OperationInfo> {
    public void callBack(A returnedObject, B techInfo);
}
