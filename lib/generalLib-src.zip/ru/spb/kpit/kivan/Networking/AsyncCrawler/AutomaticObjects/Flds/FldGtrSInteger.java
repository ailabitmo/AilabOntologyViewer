package ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.Flds;

import ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.StringProcessor;
import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors.InfoPiece;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 10:45
 */
public class FldGtrSInteger extends FldGtrSingle<Integer> {
    public FldGtrSInteger(InfoPiece ip) {
        super(ip);
    }

    public FldGtrSInteger(InfoPiece ip, StringProcessor sp) {
        super(ip, sp);
    }

    @Override
    public Integer getValFromStr(String text) {
        return Integer.parseInt(text);
    }
}
