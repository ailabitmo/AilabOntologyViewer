package ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 10:35
 */
public interface ObjectFactory<A,B> {
    A createMinedObject(B param);
}
