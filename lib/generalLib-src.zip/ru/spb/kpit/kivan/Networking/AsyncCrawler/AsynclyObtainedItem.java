package ru.spb.kpit.kivan.Networking.AsyncCrawler;

import ru.spb.kpit.kivan.Networking.Crawler.Model.ItemWithId;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 03.09.13
 * Time: 13:53
 * To change this template use File | Settings | File Templates.
 */
public abstract class AsynclyObtainedItem extends ItemWithId {

}
