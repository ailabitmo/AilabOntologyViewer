package ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.Flds;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 11:03
 */
public interface ValGetter<A> {
    A getValFromStr(String text);
}
