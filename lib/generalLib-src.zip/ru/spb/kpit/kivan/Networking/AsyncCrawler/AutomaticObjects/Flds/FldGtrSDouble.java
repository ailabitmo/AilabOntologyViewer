package ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.Flds;

import ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.StringProcessor;
import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors.InfoPiece;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 10:50
 */
public class FldGtrSDouble extends FldGtrSingle<Double> {
    public FldGtrSDouble(InfoPiece ip) {
        super(ip);
    }

    public FldGtrSDouble(InfoPiece ip, StringProcessor sp) {
        super(ip, sp);
    }

    @Override
    public Double getValFromStr(String text) {
        return Double.parseDouble(text);
    }
}
