package ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects;

import ru.spb.kpit.kivan.General.DataStructures.DataUtils;
import ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.Flds.FldGtr;
import ru.spb.kpit.kivan.Networking.AsyncCrawler.ObjectMiner;
import ru.spb.kpit.kivan.Randomizer.Pair;

import java.util.HashMap;
import java.util.Map;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 10:01
 */
public class AutoObjectMiner<A> implements ObjectMiner<A> {

    Map<String, FldGtr> fieldGetters = new HashMap<String, FldGtr>();
    Map<String, Object> lastValues = new HashMap<String, Object>();
    ObjectFactory<A, Pair<String,String>> mof;

    protected AutoObjectMiner(ObjectFactory<A,Pair<String,String>> mof, Pair<String, FldGtr>... fieldDescs) {
        this.mof = mof;
        fieldGetters = DataUtils.produceMap(fieldDescs);
    }

    @Override
    public A createObjectFromHTML(String html, String url) {
        A toRet = mof.createMinedObject(new Pair<String, String>(html, url));
        for (Map.Entry<String, FldGtr> name_fg : fieldGetters.entrySet()) {
            try {
                Object o = name_fg.getValue().createObjectFromHTML(html);
                if(o==null) o = lastValues.get(name_fg.getKey());
                else lastValues.put(name_fg.getKey(),o);

                DataUtils.setValueOfFieldUnsafe(name_fg.getKey(), o, toRet);

            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }

        return toRet;
    }
}
