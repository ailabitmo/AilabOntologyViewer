package ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.Flds;

import ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.StringProcessor;
import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors.InfoPiece;
import ru.spb.kpit.kivan.Networking.FieldExtractor.InfoSplitter;

import java.util.ArrayList;
import java.util.List;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 10:54
 */
public abstract class FldGtrList<A> implements FldGtr<List<A>>, ValGetter<A> {

    InfoPiece ip;
    InfoSplitter<String> is = null;
    StringProcessor sp = null;

    public FldGtrList(InfoPiece ip, InfoSplitter<String> is) {
        this.ip = ip;
        this.is = is;
    }

    public FldGtrList(InfoPiece ip, InfoSplitter<String> is, StringProcessor sp) {
        this.ip = ip;
        this.is = is;
    }

    @Override
    public List<A> createObjectFromHTML(String html) {
        String value = ip.getValue(html);
        List<String> a = is.splitInfo(value);

        List<A> a2 = new ArrayList<A>();
        for (String x : a) {
            if(sp!=null) a2.add(getValFromStr(sp.process(x)));
            else a2.add(getValFromStr(x));
        }

        return a2;
    }
}
