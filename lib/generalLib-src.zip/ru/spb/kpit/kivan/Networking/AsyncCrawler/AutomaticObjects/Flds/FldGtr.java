package ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.Flds;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 10:59
 */
public interface FldGtr<A> {
    public A createObjectFromHTML(String html);
}
