package ru.spb.kpit.kivan.Networking.AsyncCrawler.HTMLRequestChecker;

import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.SimpleHTMLRequest;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 31.08.13
 * Time: 11:52
 * To change this template use File | Settings | File Templates.
 */
public class ContainsChecker implements Checker {
    String siteContains;

    public ContainsChecker(String siteContains) {
        this.siteContains = siteContains;
    }

    @Override
    public boolean checkRequest(SimpleHTMLRequest request) {
        return request.getUrl().contains(siteContains);
    }
}
