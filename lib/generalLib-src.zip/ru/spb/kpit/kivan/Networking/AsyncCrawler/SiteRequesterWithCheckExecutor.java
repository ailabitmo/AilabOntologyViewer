package ru.spb.kpit.kivan.Networking.AsyncCrawler;

import ru.spb.kpit.kivan.Networking.AsyncCrawler.Calbacker.HTMLCallbacker;
import ru.spb.kpit.kivan.Networking.AsyncCrawler.HTMLRequestChecker.Checker;
import ru.spb.kpit.kivan.General.Waiter.Waiter;
import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.SimpleHTMLRequest;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 31.08.13
 * Time: 2:14
 * To change this template use File | Settings | File Templates.
 */
public class SiteRequesterWithCheckExecutor extends AsyncSiteRequestExecutor {
    Checker checkRequest;

    public boolean addTask(SimpleHTMLRequest simpleHTMLRequest, HTMLCallbacker callBack, boolean orderedAndPriority) {
        if(!checkRequest.checkRequest(simpleHTMLRequest)) return false;
        return super.addTask(simpleHTMLRequest, callBack,orderedAndPriority);    //To change body of overridden methods use File | Settings | File Templates.
    }

    public boolean check(SimpleHTMLRequest request){
        return checkRequest.checkRequest(request);
    }

    public SiteRequesterWithCheckExecutor(String nameOfRequester, Waiter nextTimeModel, Checker checkRequest) {
        super(nameOfRequester, nextTimeModel);
        this.checkRequest = checkRequest;
    }
}
