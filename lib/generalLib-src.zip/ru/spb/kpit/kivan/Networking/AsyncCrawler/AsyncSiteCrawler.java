package ru.spb.kpit.kivan.Networking.AsyncCrawler;

import ru.spb.kpit.kivan.General.DataStructures.SyncHMCounter;
import ru.spb.kpit.kivan.Networking.Crawler.DataStorage.SyncDS;
import ru.spb.kpit.kivan.Networking.Crawler.Model.ItemWithId;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 04.09.13
 * Time: 1:38
 * To change this template use File | Settings | File Templates.
 */
public abstract class AsyncSiteCrawler<P extends ItemWithId> {

    SyncDS<P> ds;
    protected SiteRequesterPool pool;

    private Set<String> visitingLinks = Collections.synchronizedSet(new HashSet<String>());
    private boolean startedToAddVisitingLinks = false;
    //0 - no, 1 - only count, 2 - urls
    private int processLogType = 0;
    Map<String, Set<String>> visitedUrls = new ConcurrentHashMap<String, Set<String>>();
    SyncHMCounter<String> visitedCountsPerCategory = new SyncHMCounter<String>();

    public SiteRequesterPool getPool() {
        return pool;
    }

    public SyncDS<P> getDs() {
        return ds;
    }

    public AsyncSiteCrawler(SyncDS<P> ds, SiteRequesterPool pool) {
        this.ds = ds;
        this.pool = pool;
    }

    public AsyncSiteCrawler(SyncDS<P> ds, SiteRequesterPool pool, int processLogType) {
        this(ds, pool);
        this.ds = ds;
        this.pool = pool;
        this.processLogType = processLogType;
    }

    public boolean finished() {
        if (!startedToAddVisitingLinks) return false;
        else if (visitingLinks.size() == 0) return true;
        return false;
    }

    public void addVisitingLink(String url) {
        visitingLinks.add(url);
        startedToAddVisitingLinks = true;
    }

    public void removeVisitingLink(String category, String url) {
        if (processLogType == 1) visitedCountsPerCategory.put(category);
        else if (processLogType == 2) {
            Set<String> set = visitedUrls.get(category);
            if(set == null){
                set = Collections.synchronizedSet(new HashSet<String>());
                visitedUrls.put(category, set);
            }
            set.add(url);
        }
        visitingLinks.remove(url);
    }

    public boolean alreadyProcessed(P item) {
        if (ds.contains(item)) return true;
        return false;
    }

    public void processResultChunk(P resultChunk) {
        if (resultChunk != null && !alreadyProcessed(resultChunk))
            ds.addItem(resultChunk);
    }
}
