package ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.Flds;

import ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.StringProcessor;
import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors.InfoPiece;
import ru.spb.kpit.kivan.Networking.FieldExtractor.InfoSplitter;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 11:25
 */
public class FldGtrListDouble extends FldGtrList<Double> {


    public FldGtrListDouble(InfoPiece ip, InfoSplitter<String> is) {
        super(ip, is);
    }

    public FldGtrListDouble(InfoPiece ip, InfoSplitter<String> is, StringProcessor sp) {
        super(ip, is, sp);
    }

    @Override
    public Double getValFromStr(String text) {
        return Double.parseDouble(text);
    }
}
