package ru.spb.kpit.kivan.Networking.AsyncCrawler.Proxy;

import ru.spb.kpit.kivan.General.OperationInfo.ProxyOperationInfo;
import ru.spb.kpit.kivan.General.Strings.StringUtils;
import ru.spb.kpit.kivan.Logger_2_0.Logger;
import ru.spb.kpit.kivan.Networking.AsyncCrawler.AsyncSiteRequestExecutor;
import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.SimpleHTMLRequest;
import ru.spb.kpit.kivan.Networking.MaskUserProperies;
import ru.spb.kpit.kivan.Networking.NetworkingUtils;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 16:34
 */
public class ProxyHtmlRequest extends SimpleHTMLRequest {

    protected ProxyPool proxyPool;
    protected AsyncSiteRequestExecutor asre;

    public ProxyHtmlRequest(String url, ProxyPool proxyPool, AsyncSiteRequestExecutor asre) {
        super(url);
        this.proxyPool = proxyPool;
        this.asre = asre;
    }

    public ProxyHtmlRequest(String url, MaskUserProperies maskUser, ProxyPool proxyPool, AsyncSiteRequestExecutor asre) {
        super(url, maskUser);
        this.proxyPool = proxyPool;
        this.asre = asre;
    }

    public ProxyHtmlRequest(String url, int conTimeOut, int timesTry, ProxyPool proxyPool, AsyncSiteRequestExecutor asre) {
        super(url, conTimeOut, timesTry);
        this.proxyPool = proxyPool;
        this.asre = asre;
    }

    public ProxyHtmlRequest(String url, int conTimeOut, int timesTry, MaskUserProperies maskUser, ProxyPool proxyPool, AsyncSiteRequestExecutor asre) {
        super(url, conTimeOut, timesTry, maskUser);
        this.proxyPool = proxyPool;
        this.asre = asre;
    }

    @Override
    public String executeRequest() {
        info = new ProxyOperationInfo();
        ((ProxyOperationInfo)info).setNormalUrl(url);
        boolean executed = false;
        String result = null;
        while (!executed) {
            ProxyPrismer prismer = proxyPool.getPrismer(asre);
            String proxyUrl = prismer.getRequestStringForProxy(url);
            if (conTimeOut < 0 && timesTry < 0) result= NetworkingUtils.getContentByUrl(proxyUrl, info, maskUser);
            else result = NetworkingUtils.getContentByUrl(proxyUrl, conTimeOut, timesTry, info, maskUser);
            if(!StringUtils.emptyString(result)){
                executed = true;
            } else {
                Logger.l2o.debug("Prismer doesn't work: "+prismer.getInfo());
                proxyPool.prismerDoneBad(prismer);
            }
        }
        return result;
    }
}
