package ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.Flds;

import ru.spb.kpit.kivan.Networking.AsyncCrawler.AutomaticObjects.StringProcessor;
import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors.InfoPiece;
import ru.spb.kpit.kivan.Networking.FieldExtractor.InfoSplitter;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 11:24
 */
public class FldGtrListString extends FldGtrList<String> {
    public FldGtrListString(InfoPiece ip, InfoSplitter<String> is) {
        super(ip, is);
    }

    public FldGtrListString(InfoPiece ip, InfoSplitter<String> is, StringProcessor sp) {
        super(ip, is, sp);
    }

    @Override
    public String getValFromStr(String text) {
        return text;
    }
}
