package ru.spb.kpit.kivan.Networking.AsyncCrawler;

import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.SimpleHTMLRequest;

import java.util.Collections;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 01.09.13
 * Time: 0:41
 * To change this template use File | Settings | File Templates.
 */
public class SiteRequesterPool {
    List<SiteRequesterWithCheckExecutor> siteRequesters;

    public SiteRequesterPool(List<SiteRequesterWithCheckExecutor> siteRequesters) {
        this.siteRequesters = Collections.unmodifiableList(siteRequesters);
    }

    public SiteRequesterWithCheckExecutor getExecutor(SimpleHTMLRequest request){
        for (SiteRequesterWithCheckExecutor siteRequester : siteRequesters) {
            if(siteRequester.check(request)) return siteRequester;
        }
        return null;
    }
}
