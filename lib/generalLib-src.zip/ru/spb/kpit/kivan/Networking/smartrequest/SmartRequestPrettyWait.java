package ru.spb.kpit.kivan.Networking.smartrequest;

/**
 * IDEA
 * : Kivan
 * : 06.02.14
 * : 17:57
 */
public class SmartRequestPrettyWait {
    InfoMessagingProvider imp;

    public SmartRequestPrettyWait(InfoMessagingProvider imp) {
        this.imp = imp;
    }
}
