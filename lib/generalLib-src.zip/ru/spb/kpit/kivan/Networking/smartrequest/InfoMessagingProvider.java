package ru.spb.kpit.kivan.Networking.smartrequest;

/**
 * IDEA
 * : Kivan
 * : 05.02.14
 * : 18:06
 */
public interface InfoMessagingProvider {
    public void errorOccured(Exception e);

    public void errorOccured(String errorString);

    public void waitMessage(String waitMessage);

    public void finishedMessage(String finishedMessage);
}
