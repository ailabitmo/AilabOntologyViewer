package ru.spb.kpit.kivan.Networking;

import ru.spb.kpit.kivan.General.OperationInfo.HtmlOperationInfo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 06.01.13
 * Time: 15:43
 * To change this template use File | Settings | File Templates.
 */
public class NetworkingUtils {
    public static String getContentByUrl(String urli) {
        return getContentByUrl(urli, 10000, 3);
    }

    public static String getContentByUrl(String urli, String encoding) {
        return getContentByUrl(urli, encoding, 10000, 3, null);
    }

    public static String getContentByUrl(String urli, int connectionTimeout, int tryTimes) {
        return getContentByUrl(urli, "UTF-8", connectionTimeout, tryTimes, null);
    }

    public static String getContentByUrl(String urli, HtmlOperationInfo info) {
        return getContentByUrl(urli, 10000, 3, info);
    }

    public static String getContentByUrl(String urli, String encoding, HtmlOperationInfo info) {
        return getContentByUrl(urli, encoding, 10000, 3, info, null);
    }

    public static String getContentByUrl(String urli, int connectionTimeout, int tryTimes, HtmlOperationInfo info) {
        return getContentByUrl(urli, "UTF-8", connectionTimeout, tryTimes, info, null);
    }

    public static String getContentByUrl(String urli, MaskUserProperies maskUser) {
        return getContentByUrl(urli, 10000, 3, maskUser);
    }

    public static String getContentByUrl(String urli, String encoding, MaskUserProperies maskUser) {
        return getContentByUrl(urli, encoding, 10000, 3, maskUser);
    }

    public static String getContentByUrl(String urli, int connectionTimeout, int tryTimes, MaskUserProperies maskUser) {
        return getContentByUrl(urli, "UTF-8", connectionTimeout, tryTimes, maskUser);
    }

    public static String getContentByUrl(String urli, HtmlOperationInfo info, MaskUserProperies maskUser) {
        return getContentByUrl(urli, 10000, 3, info, maskUser);
    }

    public static String getContentByUrl(String urli, String encoding, HtmlOperationInfo info, MaskUserProperies maskUser) {
        return getContentByUrl(urli, encoding, 10000, 3, info, maskUser);
    }

    public static String getContentByUrl(String urli, int connectionTimeout, int tryTimes, HtmlOperationInfo info, MaskUserProperies maskUser) {
        return getContentByUrl(urli, "UTF-8", connectionTimeout, tryTimes, info, maskUser);
    }

    public static String getContentByUrl(String urli, String encoding, int connectionTimeout, int tryTimes, MaskUserProperies maskUser) {
        URL url;
        HttpURLConnection urlc;
        //InputStream is = null; //http://stackoverflow.com/questions/10705240/httpurlconnection-getinputstream-blocks
        if (connectionTimeout < 0) connectionTimeout = 0;
        if (tryTimes <= 0) return "";
        try {
            url = new URL(urli);
            urlc = (HttpURLConnection) url.openConnection();

            if (maskUser != null) {
                urlc.setRequestProperty("User-Agent", maskUser.userAgent);
                urlc.setRequestProperty("Cookie", maskUser.cookie);
            }

            urlc.setReadTimeout(connectionTimeout);
            urlc.setConnectTimeout(connectionTimeout);
            urlc.connect();
            InputStream is = null;
            try {
                is = urlc.getInputStream();
                StringBuilder sb = new StringBuilder();
                Scanner sc = new Scanner(is, encoding);
                while (sc.hasNextLine()) {
                    sb.append(sc.nextLine()).append(" ");
                }
                sc.close();
                return sb.toString();
            } catch (Exception e) {
                String str = getContentByUrl(urli, encoding, connectionTimeout, tryTimes - 1, maskUser);
                if (str == null || "".equals(str)) System.out.println("Can't process request: " + urli);
                //e.printStackTrace();
                System.out.println(e.getMessage());
                return str;
            } finally {
                if (is != null) {
                    try {
                        is.close();
                    } catch (IOException e) {
                    }
                }
                if (urlc != null) {
                    urlc.disconnect();
                }
            }
        } catch (Exception e) {
            String str = getContentByUrl(urli, encoding, connectionTimeout, tryTimes - 1, maskUser);
            if (str == null || "".equals(str)) System.out.println("Can't process request: " + urli);
            //e.printStackTrace();
            System.out.println(e.getMessage());
            return str;
        }
    }

    public static String getContentByUrl(String urli, String encoding, int connectionTimeout, int tryTimes, HtmlOperationInfo info, MaskUserProperies maskUser) {
        if ("".equals(info.operationReport())) {
            info.setUrl(urli);
            info.setEncoding(encoding);
            info.setConnectionTimeoutParam(connectionTimeout);
            info.setTryTimesParam(tryTimes);
            info.setStartTime(System.currentTimeMillis());
        } else {
            info.setBadlyDoneTimes(info.getBadlyDoneTimes() + 1);
        }
        URL url;
        HttpURLConnection urlc;
        //InputStream is = null; //http://stackoverflow.com/questions/10705240/httpurlconnection-getinputstream-blocks
        if (connectionTimeout < 0) connectionTimeout = 0;
        if (tryTimes <= 0) {
            try {
                throw new Exception("Can't process: " + urli);
            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
            return "";
        }
        try {
            url = new URL(urli);
            urlc = (HttpURLConnection) url.openConnection();

            if (maskUser != null) {
                urlc.setRequestProperty("User-Agent", maskUser.userAgent);
                urlc.setRequestProperty("Cookie", maskUser.cookie);
            }
            InputStream is = null;
            urlc.setReadTimeout(connectionTimeout);
            urlc.setConnectTimeout(connectionTimeout);
            urlc.connect();
            try {
                is = urlc.getInputStream();
                StringBuilder sb = new StringBuilder();
                Scanner sc = new Scanner(is, encoding);
                while (sc.hasNextLine()) {
                    sb.append(sc.nextLine()).append(" ");
                }
                sc.close();
                return sb.toString();
            } catch (Exception e) {
                String str = getContentByUrl(urli, encoding, connectionTimeout, tryTimes - 1, info, maskUser);
                if (str == null || "".equals(str)) System.out.println("Can't process request: " + urli);
                //e.printStackTrace();
                System.out.println(e.getMessage());
                return str;
            } finally {
                if (is != null) {
                    try {
                        is.close();
                    } catch (IOException e) {
                    }
                }
                if (urlc != null) {
                    urlc.disconnect();
                }
            }
        } catch (Exception e) {
            String str = getContentByUrl(urli, connectionTimeout, tryTimes - 1, info, maskUser);
            if (str == null || "".equals(str)) {
                System.out.println("Can't process request: " + urli);
                System.out.println(e.getMessage());
                info.setOperationSuccessfull(false);
            }
            return str;
        }
    }


    public static String sendContentToUrl(String urli, String content, String encoding, int connectionTimeout, int tryTimes, MaskUserProperies maskUser){
        URL url;
        HttpURLConnection urlc;
        //InputStream is = null; //http://stackoverflow.com/questions/10705240/httpurlconnection-getinputstream-blocks
        if (connectionTimeout < 0) connectionTimeout = 0;
        if (tryTimes <= 0) {
            try {
                throw new Exception("Can't process: " + urli);
            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
            return "";
        }
        try {
            url = new URL(urli);
            urlc = (HttpURLConnection) url.openConnection();

            if (maskUser != null) {
                urlc.setRequestProperty("User-Agent", maskUser.userAgent);
                urlc.setRequestProperty("Cookie", maskUser.cookie);
            }
            InputStream is = null;
            urlc.setReadTimeout(connectionTimeout);
            urlc.setConnectTimeout(connectionTimeout);
            urlc.setDoOutput(true);
            urlc.connect();

            try {

                OutputStreamWriter osw = new OutputStreamWriter(urlc.getOutputStream());
                osw.write(content);
                osw.close();
                is = urlc.getInputStream();
                StringBuilder sb = new StringBuilder();
                Scanner sc = new Scanner(is, encoding);
                while (sc.hasNextLine()) {
                    sb.append(sc.nextLine()).append(" ");
                }
                sc.close();
                return sb.toString();
            } catch (Exception e) {
                String str = sendContentToUrl(urli,content,  encoding, connectionTimeout, tryTimes - 1, maskUser);
                if (str == null || "".equals(str)) System.out.println("Can't process request: " + urli);
                //e.printStackTrace();
                System.out.println(e.getMessage());
                return str;
            } finally {
                if (is != null) {
                    try {
                        is.close();
                    } catch (IOException e) {
                    }
                }
                if (urlc != null) {
                    urlc.disconnect();
                }
            }
        } catch (Exception e) {
            String str = sendContentToUrl(urli,content, encoding, connectionTimeout, tryTimes - 1,  maskUser);
            if (str == null || "".equals(str)) {
                System.out.println("Can't process request: " + urli);
                System.out.println(e.getMessage());
            }
            return str;
        }
    }
}
