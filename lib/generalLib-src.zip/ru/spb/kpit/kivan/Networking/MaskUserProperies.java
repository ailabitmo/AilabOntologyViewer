package ru.spb.kpit.kivan.Networking;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 03.09.13
 * Time: 21:50
 * To change this template use File | Settings | File Templates.
 */
public class MaskUserProperies {
    String userAgent;
    String cookie;

    public MaskUserProperies(String userAgent, String cookie) {
        this.userAgent = userAgent;
        this.cookie = cookie;
    }
}
