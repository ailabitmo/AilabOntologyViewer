package ru.spb.kpit.kivan.Networking.Crawler;

import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Request;
import ru.spb.kpit.kivan.Networking.Crawler.DataStorage.DataStorage;
import ru.spb.kpit.kivan.Networking.Crawler.Model.ItemWithId;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 15.03.13
 * Time: 4:06
 * To change this template use File | Settings | File Templates.
 */
public abstract class ACrawler<INFO extends ItemWithId> {
    protected DataStorage dataStorage;

    protected ACrawler(DataStorage dataStorage) {
        this.dataStorage = dataStorage;
    }

    public boolean alreadyProcessed(INFO item){
        if(dataStorage.contains(item)) return true;
        return false;
    }

    public void processRequestResults(List<INFO> requestResults) {
        if (requestResults != null)
            for (INFO inf : requestResults) {
                if (!alreadyProcessed(inf)) {
                    dataStorage.addItem(inf);
                }
            }
    }

    public void processRequest(Request<List<INFO>> request) {
        List<INFO> info = request.executeRequest();
        processRequestResults(info);
    }
}
