package ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 03.01.13
 * Time: 19:37
 * To change this template use File | Settings | File Templates.
 */
public interface Request<P> {
    public P executeRequest();
}
