package ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors;

import ru.spb.kpit.kivan.General.Strings.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 16.03.13
 * Time: 3:03
 * To change this template use File | Settings | File Templates.
 */
public class InfoPiece {

    IAnchor startOfPiece;
    IAnchor endOfPiece;

    /**
     *
     * @param startOfPiece ���� ����-��
     * @param endOfPiece ���� �� ����-��, �� ������������ ����������!!! ������ ������ �� ����!!!
     */
    public InfoPiece(IAnchor startOfPiece, IAnchor endOfPiece) {
        this.startOfPiece = startOfPiece;
        this.endOfPiece = endOfPiece;
    }

    public String getValue(String html){
        return getValue(html,0);
    }
    public List<String> getValues(String html){
        return getValues(html,0);
    }

    public String getValue(String initialHtml, int indexFrom){
        try {
            int picSt = startOfPiece.evalAfterLast(initialHtml, indexFrom);
            if (picSt >= 0) {
                int picEnd = endOfPiece.evalBeforeFirst(initialHtml, picSt);
                if(picEnd>=0 && picEnd>picSt){
                    String picVal = StringUtils.goodSubstring(initialHtml, picSt, picEnd);
                    return picVal;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }

    public List<String> getValues(String initialHtml, int indexFrom){
        List<String> vals = new ArrayList<String>();
        int curIndex = indexFrom;
        do{
            try {
                int picst = startOfPiece.evalAfterLast(initialHtml, curIndex);
                if(picst<curIndex) break;
                int picend = endOfPiece.evalBeforeFirst(initialHtml, picst);
                if(picend<=picst) break;

                String picVal = StringUtils.goodSubstring(initialHtml, picst, picend);
                vals.add(picVal);

                curIndex = picend+1;
            } catch (Exception e) {
                e.printStackTrace();
                curIndex = Integer.MAX_VALUE;
            }

        } while (curIndex>indexFrom && curIndex>=0);
        return vals;
    }

    public IAnchor getStartOfPiece() {
        return startOfPiece;
    }

    public IAnchor getEndOfPiece() {
        return endOfPiece;
    }
}
