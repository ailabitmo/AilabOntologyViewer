package ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 18.03.13
 * Time: 0:27
 * To change this template use File | Settings | File Templates.
 */
public class EmtyInfoPiece extends InfoPiece {
    public EmtyInfoPiece() {
        super(new EmptyAnchor(), new EmptyAnchor());
    }


    public String getValue(String initialHtml, int indexFrom) {
        return null;
    }
}
