package ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval;

import ru.spb.kpit.kivan.General.OperationInfo.HtmlOperationInfo;
import ru.spb.kpit.kivan.Networking.MaskUserProperies;
import ru.spb.kpit.kivan.Networking.NetworkingUtils;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 15.03.13
 * Time: 21:43
 * To change this template use File | Settings | File Templates.
 */
public class SimpleHTMLRequest implements Request<String> {
    protected String url;
    protected int conTimeOut=-1;
    protected int timesTry=-1;
    protected MaskUserProperies maskUser = null;

    protected HtmlOperationInfo info = null;

    public void setMaskUser(MaskUserProperies maskUser) {
        this.maskUser = maskUser;
    }

    public HtmlOperationInfo getInfo() {
        return info;
    }

    public String getUrl() {
        return url;
    }

    public SimpleHTMLRequest(String url) {
        this.url = url;
    }
    public SimpleHTMLRequest(String url, MaskUserProperies maskUser) {
        this.url = url;
        this.maskUser = maskUser;
    }

    public SimpleHTMLRequest(String url, int conTimeOut, int timesTry) {
        this.url = url;
        this.conTimeOut = conTimeOut;
        this.timesTry = timesTry;
    }
    public SimpleHTMLRequest(String url, int conTimeOut, int timesTry, MaskUserProperies maskUser) {
        this.url = url;
        this.conTimeOut = conTimeOut;
        this.timesTry = timesTry;
        this.maskUser = maskUser;
    }

    public String executeRequest() {
        info = new HtmlOperationInfo();
        if(conTimeOut<0 && timesTry<0) return NetworkingUtils.getContentByUrl(url,info,maskUser);
        else return NetworkingUtils.getContentByUrl(url,conTimeOut, timesTry,info,maskUser);
    }
}
