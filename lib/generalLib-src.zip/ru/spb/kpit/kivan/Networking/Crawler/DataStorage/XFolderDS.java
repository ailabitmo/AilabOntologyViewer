package ru.spb.kpit.kivan.Networking.Crawler.DataStorage;

import ru.spb.kpit.kivan.General.FileSystem.FileFolderUtils;
import ru.spb.kpit.kivan.General.Strings.StringUtils;
import ru.spb.kpit.kivan.Logger_2_0.Logger;
import ru.spb.kpit.kivan.Logger_2_0.Logger_2_0;
import ru.spb.kpit.kivan.Networking.Crawler.Model.ItemWithId;
import ru.spb.kpit.kivan.XML.XMLSerializer.Xml2ObjConverter;

import java.io.*;
import java.util.Iterator;
import java.util.Scanner;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 15.03.13
 * Time: 3:41
 * To change this template use File | Settings | File Templates.
 */
public class XFolderDS<P extends ItemWithId> implements DataStorage<P> {

    /**
     * We separate articles in subfolders. DO NOT CHANGE THIS NUMBER ON REAL SYSTEM!!!
     */
    protected final static int numOfSeparatingFolders = 1;
    String fileSuffix = ".xml";

    /**
     * Maximum number of charachters in item's filename
     */
    final static int maxNumOfCharsForItemFileName = 200;

    protected boolean allIsOk = true;
    protected File targetFolder;
    Logger_2_0 l2o = new Logger_2_0(Logger_2_0.Level.debug);


    public XFolderDS(String storageFolder) {
        this(storageFolder, new Logger_2_0(Logger_2_0.Level.debug));
    }

    public XFolderDS(String storageFolder, Logger_2_0 l2o) {
        this.l2o = l2o;
        targetFolder = new File(storageFolder);
        if (!targetFolder.exists())
            Logger.l2o.debug("FolderDataStorage: Creating storage folder" + storageFolder + "?" + targetFolder.mkdirs());

        File[] directories = targetFolder.listFiles(new FileFilter() {
            public boolean accept(File pathname) {
                return pathname.isDirectory();
            }
        });
        if (directories.length != numOfSeparatingFolders && directories.length > 0) {
            allIsOk = false;
            Logger.l2o.error("FolderDataStorage: different size of current folder and folder Model!!!" + numOfSeparatingFolders + "<>" + directories.length);
        } else if (directories.length == 0) {
            //���� ������� �������
            for (int i = 0; i < numOfSeparatingFolders; i++) {
                String folderName = (i < 10) ? "0" + i : "" + i;
                File f = new File(targetFolder.getAbsolutePath() + "\\" + folderName);
                f.mkdirs();
            }
        }
    }

    public String getItemFileName(String itemName) {
        return StringUtils.goodSubstring(itemName, 0, maxNumOfCharsForItemFileName)
                .replace('\\', '_')
                .replace('/', '_')
                .replace(':', '_')
                .replace('*', '_')
                .replace('?', '_')
                .replace('"', '_')
                .replace('<', '_')
                .replace('>', '_')
                .replace('|', '_')
                + fileSuffix;
    }


    public Boolean contains(P item) {
        if (!allIsOk) return null;

        int curFolderInd = (item.getId().hashCode() % numOfSeparatingFolders);
        String folderName = (curFolderInd < 10) ? "0" + curFolderInd : "" + curFolderInd;
        String itemFileName = getItemFileName(item.getId());

        File f = new File(targetFolder.getAbsolutePath() + "\\" + folderName+"\\"+itemFileName);
        return  f.exists();
    }

    public void addItem(P item) {
        if (!allIsOk) return;
        if (contains(item)) return;

        String absPath = getAbsolutePathOfItem(item.getId());
        String serialization = Xml2ObjConverter.convertObject(item, null).getXML();

        try {
            Writer fw = FileFolderUtils.getUtf8FileWriter(absPath);
            fw.append(serialization);
            fw.close();
        } catch (IOException e) {
            Logger.l2o.error(e.getMessage());
        }
    }

    protected String getAbsolutePathOfItem(String itemId) {
        int curFolderInd = (Math.abs(itemId.hashCode()) % numOfSeparatingFolders);
        String folderName = (curFolderInd < 10) ? "0" + curFolderInd : "" + curFolderInd;
        String itemFileName = getItemFileName(itemId);
        String absolutePath = targetFolder.getAbsolutePath() + "\\" + folderName + "\\" + itemFileName;
        return absolutePath;
    }

    public boolean deleteItem(String id){
        String path = getAbsolutePathOfItem(id);
        return new File(path).delete();
    }

    public P getItemById(String id) {
        if (!allIsOk) return null;
        String path = getAbsolutePathOfItem(id);
        return (P) createItemFromFile(new File(path));
    }

    @Override
    public void addItem(P item, boolean rewrite) {
        if (!allIsOk) return;
        if (!rewrite && contains(item)) return;

        String absPath = getAbsolutePathOfItem(item.getId());
        String serialization = Xml2ObjConverter.convertObject(item, null).getXML();

        try {
            Writer fw = FileFolderUtils.getUtf8FileWriter(absPath);
            fw.append(serialization);
            fw.close();
        } catch (IOException e) {
            Logger.l2o.error(e.getMessage());
        }
    }


    public Iterator<P> iterator() {
        if (!allIsOk) return null;
        return new Iterator<P>() {


            int curFolderInd;
            File[] curFolderFiles = null;
            int curFileInd;

            {
                curFolderInd = -1;
                curFileInd = -1;
            }


            public boolean hasNext() {
                if (curFolderFiles != null && curFileInd < curFolderFiles.length - 1) return true;
                if (curFolderInd < numOfSeparatingFolders - 1) return true;
                return false;
            }


            public P next() {
                if (curFolderFiles != null && curFileInd < curFolderFiles.length - 1) {
                    try {
                        return createItem();
                    } catch (Exception e) {
                        Logger.l2o.error("nextError:" + e.getMessage());
                    }
                } else if (curFolderInd < numOfSeparatingFolders - 1) {
                    curFolderInd++;
                    String folderName = (curFolderInd < 10) ? "0" + curFolderInd : "" + curFolderInd;
                    curFolderFiles = new File(targetFolder.getAbsolutePath() + "\\" + folderName).listFiles(new FilenameFilter() {

                        public boolean accept(File dir, String name) {
                            return name.indexOf(fileSuffix) > -1;
                        }
                    });
                    curFileInd = -1;

                    try {
                        return createItem();
                    } catch (Exception e) {
                        Logger.l2o.error("nextError:" + e.getMessage());
                    }

                } else return null;

                return null;
            }

            private P createItem() throws FileNotFoundException {
                curFileInd++;
                File f = curFolderFiles[curFileInd];
                return (P) createItemFromFile(f);
            }


            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    public static ItemWithId createItemFromFile(File f) {
        StringBuilder sb = null;
        try {
            sb = new StringBuilder();
            Scanner sc = new Scanner(f, "utf-8");
            //Logger.l2o.debug("Creating item from file:"+f.getAbsolutePath());
            while (sc.hasNextLine()) {
                String newLine = sc.nextLine();
                sb.append(newLine);
                if (sc.hasNextLine()) sb.append("\r\n");
            }
            return (ItemWithId) Xml2ObjConverter.restoreObject(sb.toString());
        } catch (Exception e) {
            Logger.l2o.error(e.getMessage() + " -> " + f.getAbsolutePath());
        }
        return null;
    }
}
