package ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 03.09.13
 * Time: 15:48
 * To change this template use File | Settings | File Templates.
 */
public class MirrorInfoPiece extends InfoPiece {
    public MirrorInfoPiece() {
        super(new EmptyAnchor(), new EmptyAnchor());
    }


    public String getValue(String initialHtml, int indexFrom) {
        return initialHtml.substring(indexFrom);
    }
}
