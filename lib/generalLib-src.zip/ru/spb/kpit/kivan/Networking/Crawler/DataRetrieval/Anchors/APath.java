package ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 16.03.13
 * Time: 2:41
 * To change this template use File | Settings | File Templates.
 */
public class APath implements IAnchor {

    List<IAnchor> aSequence;
    public APath(IAnchor... anchorSequence) {
        aSequence = new ArrayList<IAnchor>(Arrays.asList(anchorSequence));
    }

    public APath(String... anchors) {
        aSequence = new ArrayList<IAnchor>();
        for (String anchor : anchors) {
            aSequence.add(new OAnchor(anchor));
        }

    }

    public int evalBeforeLast(String html, int fromindex) {
        int index = fromindex;
        int maxIndex = -1;
        for (int i = 0; i < aSequence.size()-1; i++) {
            if(index>maxIndex) maxIndex = index;
            else return -1;
            IAnchor iAnchor = aSequence.get(i);
            index = iAnchor.evalAfterLast(html, index);
            if(index<0) return -1;
        }

        if(aSequence.size()>0){
            index = aSequence.get(aSequence.size()-1).evalBeforeLast(html, index);
        }
        return index;
    }

    public int evalAfterLast(String html, int fromindex) {
        int index = fromindex;
        int maxIndex = -1;
        for (IAnchor iAnchor : aSequence) {
            if(index>maxIndex) maxIndex = index;
            else return -1;
            index = iAnchor.evalAfterLast(html, index);
            if(index<0) return -1;
        }
        return index;
    }

    public int evalBeforeFirst(String html, int fromIndex) {
        int index = fromIndex;

        int maxIndex = -1;
        for (int i = 0; i < aSequence.size(); i++) {
            if(index>maxIndex) maxIndex = index;
            else return -1;
            IAnchor iAnchor = aSequence.get(i);
            index = iAnchor.evalAfterLast(html, index);
            if(index<0) return -1;
        }

        if(aSequence.size()>0){
            index = aSequence.get(0).evalBeforeFirst(html, fromIndex);
        }
        return index;
    }

    public int evalAfterFirst(String html, int fromIndex) {
        int index = fromIndex;

        int maxIndex = -1;
        for (int i = 0; i < aSequence.size(); i++) {
            if(index>maxIndex) maxIndex = index;
            else return -1;
            IAnchor iAnchor = aSequence.get(i);
            index = iAnchor.evalAfterLast(html, index);
            if(index<0) return -1;
        }

        if(aSequence.size()>0){
            index = aSequence.get(0).evalAfterFirst(html, fromIndex);
        }
        return index;
    }
}

class OAnchor implements IAnchor{
    String openingValue;

    public OAnchor(String openingValue) {
        this.openingValue = openingValue;
    }

    public int evalBeforeLast(String html, int fromindex) {
        if(fromindex<0) return -1;
        int toRet = html.indexOf(openingValue,fromindex);
        if(toRet<fromindex) return -1;
        return toRet;
    }

    public int evalAfterLast(String html, int fromindex) {
        if(fromindex<0) return -1;
        int index =  html.indexOf(openingValue,fromindex);
        if(index>=0 && index>=fromindex) return index +openingValue.length();
        else return -1;
    }

    public int evalBeforeFirst(String html, int fromindex) {
        if(fromindex<0) return -1;
        int toRet = html.indexOf(openingValue,fromindex);
        if(toRet<fromindex) return -1;
        return toRet;
    }

    public int evalAfterFirst(String html, int fromindex) {
        if(fromindex<0) return -1;
        int index =  html.indexOf(openingValue,fromindex);
        if(index>=0 && index>=fromindex) return index +openingValue.length();
        else return -1;
    }
}
