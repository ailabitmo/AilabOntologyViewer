package ru.spb.kpit.kivan.Networking.Crawler.DataStorage;

import ru.spb.kpit.kivan.Networking.Crawler.Model.ItemWithId;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 03.01.13
 * Time: 19:40
 * To change this template use File | Settings | File Templates.
 */
public interface DataStorage<P extends ItemWithId> extends Iterable<P> {
    /**
     * @param item
     * @return
     */
    public Boolean contains(P item);

    /**
     * @param item
     */
    public void addItem(P item);

    public boolean deleteItem(String id);

    public P getItemById(String id);

    void addItem(P item, boolean rewrite);
}
