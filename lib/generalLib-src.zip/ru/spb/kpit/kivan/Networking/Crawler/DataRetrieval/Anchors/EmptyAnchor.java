package ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 16.03.13
 * Time: 2:58
 * To change this template use File | Settings | File Templates.
 */
public class EmptyAnchor implements IAnchor {
    public int evalBeforeLast(String html, int fromindex) {
        return -1;
    }

    public int evalAfterLast(String html, int fromindex) {
        return -1;
    }
    public int evalBeforeFirst(String html, int fromIndex) {
        return -1;
    }
    public int evalAfterFirst(String html, int fromIndex) {
        return -1;
    }
}
