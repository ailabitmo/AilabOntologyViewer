package ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 16.03.13
 * Time: 2:36
 * To change this template use File | Settings | File Templates.
 */
public interface IAnchor {
    /**
     *
     * @param html
     * @param fromindex
     * @return
     */
    public int evalBeforeLast(String html, int fromindex);
    /**
     *
     * @param html
     * @param fromindex
     * @return
     */
    public int evalAfterLast(String html, int fromindex);

    public int evalBeforeFirst(String html, int fromIndex);
    public int evalAfterFirst(String html, int fromIndex);
}
