package ru.spb.kpit.kivan.Networking.Crawler.DataStorage;

import ru.spb.kpit.kivan.Logger_2_0.Logger_2_0;
import ru.spb.kpit.kivan.Networking.Crawler.Model.ItemWithId;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 15.03.13
 * Time: 3:41
 * To change this template use File | Settings | File Templates.
 */
public class XFullCachedFolderDS<P extends ItemWithId> extends XFolderDS<P> {
    protected HashMap<String, P> cache = null;


    public XFullCachedFolderDS(String storageFolder, boolean cache) {
        this(storageFolder, cache, new Logger_2_0(Logger_2_0.Level.debug));
    }
    public XFullCachedFolderDS(String storageFolder, boolean cache, Logger_2_0 l2o) {
        super(storageFolder,l2o);
        if (cache && allIsOk) {
            l2o.debug("STARTING RESTORE OF DB CACHE");

            this.cache = new HashMap<String, P>();

            File[] directories = targetFolder.listFiles(new FileFilter() {

                public boolean accept(File pathname) {
                    return pathname.isDirectory();
                }
            });

            for (File directory : directories) {
                File[] files = directory.listFiles(new FilenameFilter() {

                    public boolean accept(File dir, String name) {
                        return name.indexOf(fileSuffix) > -1;
                    }
                });

                for (File f : files) {
                    P item = (P) createItemFromFile(f);
                    if (item != null)
                        this.cache.put(item.getId(), item);
                }
            }
            l2o.debug("FINISHED RESTORE OF DB CACHE");
        }
    }


    @Override
    public P getItemById(String id) {
        if (!allIsOk) return null;
        if (cache != null) {
            if (id != null) return cache.get(id);
            return null;
        }
        return super.getItemById(id);
    }

    @Override
    public boolean deleteItem(String id) {
        boolean deleted = super.deleteItem(id);
        if(deleted){
            cache.remove(id);
        }
        return deleted;
    }

    public Boolean contains(P item) {
        if (!allIsOk) return null;
        if (cache != null) {
            if (item.getId() != null && cache.get(item.getId()) != null) return true;
            return false;
        }
        return super.contains(item);    //To change body of overridden methods use File | Settings | File Templates.
    }

    public int size(){
        return cache.size();
    }

    public void addItem(P item) {
        if (!allIsOk) return;
        if (cache != null) {
            if(!contains(item)) super.addItem(item);
            cache.put(item.getId(), item);
        }
    }

    public void addItem(P item, boolean refresh) {
        if (!allIsOk) return;
        if (cache != null) {
            super.addItem(item, refresh);
            cache.put(item.getId(), item);
        }
    }


    public Iterator<P> iterator() {
        if (!allIsOk) return null;
        if (cache != null) {
            return new Iterator<P>() {
                Iterator<P> it;
                {
                    ArrayList<P> clone = new ArrayList<P>(cache.values());
                    it = clone.iterator();
                }

                public boolean hasNext() {
                    return it.hasNext();
                }


                public P next() {
                    return it.next();
                }


                public void remove() {
                    throw new UnsupportedOperationException();
                }
            };
        } else return super.iterator();    //To change body of overridden methods use File | Settings | File Templates.
    }
}
