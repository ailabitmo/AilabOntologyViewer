package ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval;

import ru.spb.kpit.kivan.General.Strings.StringCleaner;
import ru.spb.kpit.kivan.Networking.Crawler.Model.ItemWithId;
import ru.spb.kpit.kivan.Networking.NetworkingUtils;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 27.05.13
 * Time: 11:20
 * To change this template use File | Settings | File Templates.
 */
public abstract class HTMLRequestResult<T> extends ItemWithId implements Request<T> {
    String url;
    String cleanedUrl;
    StringCleaner urlCleaner;
    Long waitTime = 1000l;

    public void setWaitTimeInMilis(Long waitTime) {
        this.waitTime = waitTime;
    }

    protected HTMLRequestResult(String url) {
        this.url = url;
        this.cleanedUrl = url;
    }

    protected HTMLRequestResult(String url, StringCleaner urlCleaner) {
        this.url = url;
        this.cleanedUrl = urlCleaner.clean(url);
        this.urlCleaner = urlCleaner;
    }

    protected String getRequestResult(String url, String encoding) {
        try {
            Thread.sleep(waitTime);
        } catch (InterruptedException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return NetworkingUtils.getContentByUrl(url, encoding);
    }

    @Override
    public String getId() {
        return cleanedUrl;
    }

}
