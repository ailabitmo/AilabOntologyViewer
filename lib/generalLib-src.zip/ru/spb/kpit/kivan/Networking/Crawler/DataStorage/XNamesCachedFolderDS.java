package ru.spb.kpit.kivan.Networking.Crawler.DataStorage;

import ru.spb.kpit.kivan.Logger_2_0.Logger_2_0;
import ru.spb.kpit.kivan.Networking.Crawler.Model.ItemWithId;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 01.09.13
 * Time: 12:38
 * To change this template use File | Settings | File Templates.
 */
public class XNamesCachedFolderDS<P extends ItemWithId> extends XFolderDS<P> {
    protected HashMap<String, String> cache = null;

    public XNamesCachedFolderDS(String storageFolder, boolean cache) {
        this(storageFolder, cache, new Logger_2_0(Logger_2_0.Level.debug));
    }

    public XNamesCachedFolderDS(String storageFolder, boolean cache, Logger_2_0 l2o) {
        super(storageFolder, l2o);
        if (cache && allIsOk) {
            l2o.debug("STARTING RESTORE OF DB CACHE");

            this.cache = new HashMap<String, String>();

            File[] directories = targetFolder.listFiles(new FileFilter() {

                public boolean accept(File pathname) {
                    return pathname.isDirectory();
                }
            });

            for (File directory : directories) {
                File[] files = directory.listFiles(new FilenameFilter() {

                    public boolean accept(File dir, String name) {
                        return name.indexOf(fileSuffix) > -1;
                    }
                });

                for (File f : files) {
                    this.cache.put(f.getName(), f.getAbsolutePath());
                }
            }

            l2o.debug("Cache contains:" + this.cache.size() + " items");

            l2o.debug("FINISHED RESTORE OF DB CACHE");
        }
    }

    public int size() {
        return cache.size();
    }

    @Override
    public Boolean contains(P item) {
        if (!allIsOk) return null;
        String itemFileName = getItemFileName(item.getId());
        if (this.cache.containsKey(itemFileName)) {
            return true;
        }
        return false;
    }

    @Override
    public P getItemById(String id) {
        if (!allIsOk) return null;
        String itemFileName = getItemFileName(id);
        if (this.cache.containsKey(itemFileName)) {
            String path = cache.get(itemFileName);
            return (P) createItemFromFile(new File(path));
        }
        return null;
    }

    @Override
    public boolean deleteItem(String id) {
        boolean deleted =super.deleteItem(id);
        if(deleted){
            String itemFileName = getItemFileName(id);
            cache.remove(itemFileName);
        }
        return deleted;
    }

    @Override
    public void addItem(P item) {
        if (!allIsOk) return;
        if (cache != null) {
            if (!contains(item)) {
                super.addItem(item);
                String absPath = getAbsolutePathOfItem(item.getId());
                String itemFileName = getItemFileName(item.getId());
                cache.put(itemFileName, absPath);
                l2o.debug("Add to cache:" + item.getId());
            } else {
                l2o.debug("Cache already have:" + item.getId());
            }
        }
    }

    @Override
    public void addItem(P item, boolean rewrite) {
        if (!allIsOk) return;
        if (cache != null) {
            if (rewrite || !contains(item)) {
                super.addItem(item,rewrite);
                String absPath = getAbsolutePathOfItem(item.getId());
                String itemFileName = getItemFileName(item.getId());
                cache.put(itemFileName, absPath);
                l2o.debug("Add to cache:" + item.getId());
            } else {
                l2o.debug("Cache already have:" + item.getId());
            }
        }
    }

    @Override
    public Iterator<P> iterator() {
        return new Iterator<P>() {
            Iterator<String> iter;

            {
                SortedSet<String> ss = new TreeSet<String>(cache.keySet());
                iter = ss.iterator();

            }

            @Override
            public boolean hasNext() {
                return iter.hasNext();
            }

            @Override
            public P next() {
                String path = cache.get(iter.next());
                return (P) createItemFromFile(new File(path));
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }
}
