package ru.spb.kpit.kivan.Networking.Crawler.DataStorage;

import ru.spb.kpit.kivan.Networking.Crawler.Model.ItemWithId;

import java.util.Iterator;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 01.09.13
 * Time: 12:40
 * To change this template use File | Settings | File Templates.
 */
public class SyncDS<P extends ItemWithId> implements DataStorage<P> {

    DataStorage<P> notSyncedDS;
    ReentrantLock lock = new ReentrantLock();
    ReadWriteLock rwlock = new ReentrantReadWriteLock();

    public SyncDS(DataStorage<P> notSyncedDS) {
        this.notSyncedDS = notSyncedDS;
    }

    @Override
    public Boolean contains(P item) {
        boolean contains = false;
        try {
            rwlock.readLock().lock();
            contains = notSyncedDS.contains(item);
        } finally {
            rwlock.readLock().unlock();
        }
        return contains;
    }

    @Override
    public void addItem(P item) {
        try {
            rwlock.writeLock().lock();
            notSyncedDS.addItem(item);
        } finally {
            rwlock.writeLock().unlock();
        }
    }

    @Override
    public boolean deleteItem(String id) {
        try {
            rwlock.writeLock().lock();
            return notSyncedDS.deleteItem(id);
        } finally {
            rwlock.writeLock().unlock();
        }
    }

    @Override
    public P getItemById(String id) {
        P contains = null;
        try {
            rwlock.readLock().lock();
            contains = notSyncedDS.getItemById(id);
        } finally {
            rwlock.readLock().unlock();
        }
        return contains;
    }

    @Override
    public void addItem(P item, boolean rewrite) {
        try {
            rwlock.readLock().lock();
            notSyncedDS.addItem(item,rewrite);
        } finally {
            rwlock.readLock().unlock();
        }
    }

    @Override
    public Iterator<P> iterator() {
        try {
            rwlock.readLock().lock();
            return notSyncedDS.iterator();
        } finally {
            rwlock.readLock().unlock();
        }
    }

    public void lock(String message){
        rwlock.writeLock().lock();
        System.out.println("Locked with msg:"+message);
        lockMsg = message;
    }

    String lockMsg = "";

    public void unlock(){
        System.out.println("Unlocked with msg:"+lockMsg);
        lockMsg="";
        rwlock.writeLock().unlock();
    }
}
