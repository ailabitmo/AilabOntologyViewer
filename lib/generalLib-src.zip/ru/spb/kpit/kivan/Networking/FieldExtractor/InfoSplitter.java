package ru.spb.kpit.kivan.Networking.FieldExtractor;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 02.09.13
 * Time: 21:53
 * To change this template use File | Settings | File Templates.
 */
public interface InfoSplitter<P> {
    public List<P> splitInfo(String initial);
}
