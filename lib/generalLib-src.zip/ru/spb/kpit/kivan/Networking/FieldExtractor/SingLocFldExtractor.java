package ru.spb.kpit.kivan.Networking.FieldExtractor;

import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors.IAnchor;
import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors.InfoPiece;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 02.09.13
 * Time: 12:41
 * To change this template use File | Settings | File Templates.
 */
public class SingLocFldExtractor {
    IAnchor contextSetter;
    InfoPiece extractor;

    public SingLocFldExtractor(IAnchor contextSetter, InfoPiece extractor) {
        this.contextSetter = contextSetter;
        this.extractor = extractor;
    }

    public String getFieldValue(String initialHtml, int index){
        try {
            index = contextSetter.evalAfterLast(initialHtml, index);

            String dateVal = extractor.getValue(initialHtml, index);
            return dateVal;
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }
}
