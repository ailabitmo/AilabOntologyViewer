package ru.spb.kpit.kivan.Networking.FieldExtractor;

import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors.InfoPiece;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 02.09.13
 * Time: 12:34
 * To change this template use File | Settings | File Templates.
 */
public class SingGlobFldExtractor {
    InfoPiece extractor;

    public SingGlobFldExtractor(InfoPiece extractor) {
        this.extractor = extractor;
    }

    public String getFieldValue(String initialHtml){
        try {
            String rawVal = extractor.getValue(initialHtml, 0);
            return rawVal;
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }

}
