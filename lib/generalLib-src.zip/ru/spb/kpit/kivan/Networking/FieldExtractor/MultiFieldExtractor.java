package ru.spb.kpit.kivan.Networking.FieldExtractor;

import ru.spb.kpit.kivan.Networking.Crawler.DataRetrieval.Anchors.InfoPiece;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 02.09.13
 * Time: 12:35
 * To change this template use File | Settings | File Templates.
 */
public class MultiFieldExtractor<P> {
    InfoPiece extractor;
    InfoSplitter<P> splitter;

    public MultiFieldExtractor(InfoPiece extractor, InfoSplitter splitter) {
        this.extractor = extractor;
        this.splitter = splitter;
    }

    public List<P> getFieldValues(String initialHtml, int fromIndex) {
        String vals = extractor.getValue(initialHtml, fromIndex);
        if (vals != null)
            return splitter.splitInfo(vals);
        return new ArrayList<P>();
    }
}
