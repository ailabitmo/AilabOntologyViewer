package ru.spb.kpit.kivan.Logger_2_0;

import ru.spb.kpit.kivan.General.Time.DateParser;
import ru.spb.kpit.kivan.General.FileSystem.FileFolderUtils;
import ru.spb.kpit.kivan.Async.AsyncOrderedTaskExecutor;

import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.text.DateFormat;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 01.06.2011
 * Time: 11:19:04
 * To change this template use File | Settings | File Templates.
 */
public class Logger_2_0 {
    final static long msInDay = 24l * 3600l * 1000l; // l a ne 1
    final static long msInMonth = 30l * msInDay; // l a ne 1

    String logPath = null;
    String logFile = "main.log";
    DateParser dp = DateParser.dateParserFactory("hh:mm:ss.SSS|DD.MM.YY");
    DateFormat df = new SimpleDateFormat("dd_MM_yy_HH_mm_ss_SSS");
    DateFormat df1 = new SimpleDateFormat("HH:mm:ss.SSS|dd.MM.yy");

    //4erez skoljko sozdaem novij file
    long msToCreateNewFile = msInDay;
    //4erez skoljko udaljaem faili (checking not by file create date, but by file last changed date)
    long msToStartDeleteFiles = msInMonth;

    boolean toConsole = false;
    boolean onlyToConsole = false;

    boolean showThreadInfo = false;

    final Level lvl;
    AsyncOrderedTaskExecutor executor;

    public Level getLvl() {
        return lvl;
    }

    //��� ����� - ������ � �������!!!
    public Logger_2_0(Level lvl) {
        this.lvl = lvl;
        logPath = null;
        toConsole = true;
        onlyToConsole = true;
        //executor = new AsyncOrderedTaskExecutor(1000);
    }

    public Logger_2_0(Level lvl, String logFolderPath) {
        this.lvl = lvl;
        FileFolderUtils.recursiveFolderCreator(logFolderPath);
        logPath = logFolderPath;
        File f = new File(logPath);
        executor = new AsyncOrderedTaskExecutor(1000);

        try {
            if (!f.exists()) f.mkdir();
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public Logger_2_0(Level lvl, String logFolderPath, boolean toConsole) {
        this(lvl, logFolderPath);
        this.toConsole = toConsole;
    }

    public Logger_2_0(Level lvl, String logFolderPath, boolean toConsole, int daysToCreateNewFileAfter, int daysToDeleteOldFilesAfter) {
        this(lvl, logFolderPath, toConsole);
        msToCreateNewFile = daysToCreateNewFileAfter * msInDay;
        msToStartDeleteFiles = daysToDeleteOldFilesAfter * msInDay;
    }

    public Logger_2_0(Level lvl, String logFolderPath, boolean toConsole, boolean showThreadInfo, int daysToCreateNewFileAfter, int daysToDeleteOldFilesAfter) {
        this(lvl, logFolderPath, toConsole, daysToCreateNewFileAfter, daysToDeleteOldFilesAfter);
        this.showThreadInfo = showThreadInfo;
    }


    public void finish() {
        executor.finish();
    }

    public void debug(final String debug) {
        if (lvl.getLvl() >= Level.debug.getLvl()) {
            final Date curTime = new Date();
            String thrName = Thread.currentThread().getName();
            if(executor!=null) executor.addTask(new LogTimerTask(new RequestToLog(Level.debug, debug, curTime, thrName)));
            else _debug(debug, new Date(), "X" );
        }
    }

    public void info(final String info) {
        if (lvl.getLvl() >= Level.info.getLvl()) {
            final Date curTime = new Date();
            String thrName = Thread.currentThread().getName();
            if(executor!=null) executor.addTask(new LogTimerTask(new RequestToLog(Level.info, info, curTime, thrName)));
            else _info(info, new Date(), "X" );
        }
    }

    public void error(final String error) {
        if (lvl.getLvl() >= Level.error.getLvl()) {
            final Date curTime = new Date();
            String thrName = Thread.currentThread().getName();
            if(executor!=null) executor.addTask(new LogTimerTask(new RequestToLog(Level.error, error, curTime, thrName)));
            else _error(error, new Date(), "X" );
        }
    }

    private void _debug(String debug, Date curTime, String thrName) {
        File f = new File(logPath + "/" + logFile);
        checkFileChangeNeed(f, curTime);
        if (!showThreadInfo)
            debug = String.format("DEBUG: [ %s ] : %s\r\n", df1.format(curTime), debug);
        else
            debug = String.format("DEBUG: [ %s ] @T>%s : %s \r\n", df1.format(curTime), thrName, debug);
        if (toConsole) System.out.print(debug);
        if(!onlyToConsole) writeToFile(f, debug, true);
    }

    private void _info(String info, Date curTime, String thrName) {
        File f = new File(logPath + "/" + logFile);
        checkFileChangeNeed(f, curTime);
        if (!showThreadInfo)
            info = String.format("INFO : [ %s ] : %s\r\n", df1.format(curTime), info);
        else
            info = String.format("INFO : [ %s ] @T>%s : %s \r\n", df1.format(curTime), thrName, info);
        if (toConsole) System.out.print(info);
        if(!onlyToConsole) writeToFile(f, info, true);
    }

    private void _error(String error, Date curTime, String thrName) {
        File f = new File(logPath + "/" + logFile);
        checkFileChangeNeed(f, curTime);
        if (!showThreadInfo)
            error = String.format("ERROR: [ %s ] : %s\r\n", df1.format(curTime), error);
        else
            error = String.format("ERROR: [ %s ] @T>%s : %s \r\n", df1.format(curTime), thrName, error);
        if (toConsole) System.out.print(error);
        if(!onlyToConsole) writeToFile(f, error, true);
    }

    /**
     * 1. ���� ���� �������� �������� ���������� ����� ����� - ������ ���������������,
     * � ����� ������� �� ��� �����.
     * 2. ���� ������� �������� ���� - ��������� ���� ������ ������ � ������� ���, ������� ������ ������
     *
     * @param f
     * @param curTime
     */
    private void checkFileChangeNeed(File f, Date curTime) {
        if(onlyToConsole) return;
        //1
        if (!f.exists()) createNewLogFile(curTime);
        else {
            Scanner scan = null;
            try {
                scan = new Scanner(f);
                // ���� ���� ���� � �����, �� �������� ������� ������ ������ � ����������
                // �� ��� ���� �������� �����. ���� ��� �� - ������ ����� � ����.
                if (scan.hasNextLine()) {
                    try {
                        String dateLine = scan.nextLine();
                        scan.close();
                        Date d = dp.parseDate(dateLine);
                        if (curTime.getTime() - d.getTime() > msToCreateNewFile) {
                            //��������������� ������ ����, ������� �����
                            f.renameTo(new File(logPath + "/main_" + df.format(d) + ".log"));
                            deleteFilesOlderThanMonth(curTime);
                            createNewLogFile(curTime);
                        }
                    } catch (Exception e) {
                        //���� ���� �� ������������� ���������� �������. �� ��� ��������������� � ������� ����� ��� ����.
                        scan.close();
                        f.renameTo(new File(logPath + "/corrupted_" + curTime.getTime() + "_main.log"));
                        createNewLogFile(curTime);
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            } finally {
                scan.close();
            }
        }
    }

    private void deleteFilesOlderThanMonth(Date curTim) {
        File folder = new File(logPath);
        File[] logs = folder.listFiles(new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return name.indexOf(".log") != -1;
            }
        });

        long curTime = curTim.getTime();
        for (File log : logs) {
            if (curTime - log.lastModified() > msToStartDeleteFiles) {
                try {
                    System.out.println("DELETED:" + log.getName());
                    log.delete();
                } catch (Exception e) {
                    e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
            }
        }
    }

    private void createNewLogFile(Date curTime) {
        File f = new File(logPath + "/" + logFile);
        writeToFile(f, df1.format(curTime) + "\r\n", false);
    }

    private void writeToFile(File f, String string, boolean append) {
        Writer fw = null;
        try {
            fw = FileFolderUtils.getUtf8FileWriter(f,append);
            fw.append(string);
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } finally {
            closeWriter(fw);
        }
    }

    private void closeWriter(Writer fw) {
        try {
            if (fw != null) {
                fw.close();
            }
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public static enum Level {
        error(1), info(2), debug(3);

        int lvl;

        public int getLvl() {
            return lvl;
        }

        Level(int i) {
            lvl = i;
        }
    }

    private class LogTimerTask extends TimerTask {

        RequestToLog rtl;

        private LogTimerTask(RequestToLog rtl) {
            this.rtl = rtl;
        }


        public void run() {

            switch (rtl.typeOfEvent) {
                case info:
                    _info(rtl.text, rtl.date, rtl.thrName);
                    break;
                case error:
                    _error(rtl.text, rtl.date, rtl.thrName);
                    break;
                case debug:
                    _debug(rtl.text, rtl.date, rtl.thrName);
                    break;
            }
        }
    }

    private static class RequestToLog {
        public Level typeOfEvent;
        public String text;
        public Date date;
        public String thrName;

        private RequestToLog(Level typeOfEvent, String text, Date date, String thrName) {
            this.typeOfEvent = typeOfEvent;
            this.text = text;
            this.date = date;
            this.thrName = thrName;
        }
    }

    /*public static void main(String[] args) {
        int max = 1;
        int ind = 0;
        Logger_2_0 log = new Logger_2_0(Level.debug, "logs");
        while (max > 0) {
            log.debug("debug:" + ind++);
            log.debug("debug:" + ind++);
            log.debug("debug:" + ind++);
            log.debug("debug:" + ind++);
            log.info("info:" + ind++);
            log.info("info:" + ind++);
            log.info("info:" + ind++);
            log.info("info:" + ind++);
            log.info("info:" + ind++);
            log.error("error:" + ind++);
            log.info("info:" + ind++);
            log.error("error:" + ind++);
            log.info("info:" + ind++);
            log.error("error:" + ind++);
            log.info("info:" + ind++);
            log.error("error:" + ind++);
            log.info("info:" + ind++);
            log.error("error:" + ind++);
            log.info("info:" + ind++);
            log.error("error:" + ind++);
            max--;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }
        log.finish();
    }*/
}
