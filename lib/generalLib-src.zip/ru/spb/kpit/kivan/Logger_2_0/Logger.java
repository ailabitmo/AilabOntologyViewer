package ru.spb.kpit.kivan.Logger_2_0;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 15.03.13
 * Time: 4:22
 * To change this template use File | Settings | File Templates.
 */
public class Logger {
    static {
        l2o = new Logger_2_0(Logger_2_0.Level.debug, "logs",true);
    }
    public static Logger_2_0 l2o;
}
