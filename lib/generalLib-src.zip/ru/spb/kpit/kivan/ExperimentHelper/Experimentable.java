package ru.spb.kpit.kivan.ExperimentHelper;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 10.06.12
 * Time: 16:17
 * To change this template use File | Settings | File Templates.
 */
public interface Experimentable {
    public String getInfoAboutExperiment();
}
