package ru.spb.kpit.kivan.General;

import java.awt.*;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 03.04.12
 * Time: 17:43
 * To change this template use File | Settings | File Templates.
 * ����� ��� ������� ����� ������.
 */
public class ColorRotator {

    int changeSpeed;

    int curR;
    int curG;
    int curB;

    State state;

    public ColorRotator(int changeSpeed){
        this.changeSpeed = changeSpeed;

        curR = 0;
        curG = 255;
        curB = 0;
        state = State.B_UP;
    }

    public Color getNextColor(){



        return new Color(curR,curG,curB);
    }


    private enum State{
        R_DOWN,
        R_UP,
        G_DOWN,
        G_UP,
        B_DOWN,
        B_UP
    }
}
