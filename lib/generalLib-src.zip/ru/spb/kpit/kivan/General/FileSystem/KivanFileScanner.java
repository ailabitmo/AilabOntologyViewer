package ru.spb.kpit.kivan.General.FileSystem;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.Scanner;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 05.01.13
 * Time: 18:30
 * To change this template use File | Settings | File Templates.
 */
public class KivanFileScanner implements Iterable<String>{

    Scanner sc;
    String charset;

    public KivanFileScanner(File source) throws FileNotFoundException {
        sc = new Scanner(source);
    }

    public KivanFileScanner(File source,String charSetName) throws FileNotFoundException {
        sc = new Scanner(source,charSetName);
        this.charset = charSetName;
    }

    public void close(){
        sc.close();
    }

    public Iterator<String> iterator() {

        return new Iterator<String>() {

            boolean firstLine = true;

            public boolean hasNext() {
                boolean hasNext = sc.hasNextLine();
                if(!hasNext) {
                    close();
                }
                return hasNext;
            }

            public String next() {
                if("utf-8".equalsIgnoreCase(charset) && firstLine){
                    String toRet = sc.nextLine();
                    toRet = toRet.substring(1);
                    firstLine = false;
                    return toRet;
                }
                return sc.nextLine();
            }

            public void remove() {
                throw new NotImplementedException();
            }
        };
    }
}
