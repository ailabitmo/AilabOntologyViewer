package ru.spb.kpit.kivan.General.FileSystem;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 12.06.2011
 * Time: 16:11:25
 * To change this template use File | Settings | File Templates.
 */

import ru.spb.kpit.kivan.Randomizer.Pair;
import ru.spb.kpit.kivan.Randomizer.SSRand;

import java.io.*;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class FileFolderUtils {

    public static Pair<String, Integer> executeCMDComand(String cmd) {
        int endState = -1;
        StringBuffer sb = new StringBuffer("");
        // ������ �������� �� ����� ��������� ��� ��� ����
        try {
            Process p = Runtime.getRuntime().exec(cmd);
            try {
                endState = p.waitFor();
            } catch (InterruptedException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
            InputStream is = p.getErrorStream();

            int cur = is.read();
            while (cur != -1) {
                sb.append((char) cur);
                cur = is.read();
            }
            //System.out.println(new String(sb.toString().getBytes(), "windows-1251"));

        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return new Pair<String, Integer>(sb.toString(), endState);
    }

    public static String getFileContents(String filePath) {
        try {
            StringBuilder sb = new StringBuilder();
            KivanFileScanner scanner = new KivanFileScanner(new File(filePath));
            for (String line : scanner) {
                sb.append(line).append("\r\n");
            }
            scanner.close();
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }

    public static String getFileContents(String filePath, String charSetName) {
        try {
            StringBuilder sb = new StringBuilder();
            KivanFileScanner scanner = new KivanFileScanner(new File(filePath), charSetName);
            for (String line : scanner) {
                sb.append(line).append("\r\n");
            }
            scanner.close();
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }

    public static void writeToFile(String filePath, String text) {
        writeToFile(filePath, text, false);
    }

    public static void writeToFile(String filePath, String text, String encoding) {
        writeToFile(filePath, text, encoding, false);
    }

    public static void writeToFile(String filePath, String text, boolean append) {
        writeToFile(filePath, text, "utf-8", append);
    }

    public static void writeToFile(String filePath, String text, String encoding, boolean append) {
        File f = new File(filePath);
        if (!f.exists()) {
            f.getAbsoluteFile().getParentFile().mkdirs();
        }
        OutputStreamWriter fw = null;
        try {
            fw = new OutputStreamWriter(new FileOutputStream(filePath, append), encoding);
            fw.append(text);
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } finally {
            close(fw);
        }
    }

    public static void merge2Files(File toMerge, File mergeDestination) {

        try {
            InputStream inn = new FileInputStream(toMerge);
            OutputStream outt = new FileOutputStream(mergeDestination, true);

            byte[] buf = new byte[8192];
            int len;
            while ((len = inn.read(buf)) > 0) {
                outt.write(buf, 0, len);
            }
            inn.close();
            outt.close();
            System.out.println("File copied.");
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage() + " in the specified directory.");
            System.exit(0);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void mergeAllFilesInPath(String pathWithFiles, File fileToMerge) {
        File[] files = new File(pathWithFiles).listFiles();
        for (File file : files) {
            FileFolderUtils.merge2Files(file, fileToMerge);
        }
    }

    /**
     * copy the file of a given URL to the given destination
     *
     * @param source      URL: the URL of the source file
     * @param destination String: the filename of the destination
     */
    public static void copy(URL source, String destination) {

        InputStream in = null;
        FileOutputStream out = null;
        try {
            in = source.openStream();
            out = new FileOutputStream(destination);
            int c;
            byte[] buffer = new byte[2048];
            int read = in.read(buffer);
            while (read != -1) {
                out.write(buffer, 0, read);
                read = in.read(buffer);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (in != null) try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (out != null) try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * copy the file of a given URL to the given destination
     *
     * @param source      String: the name of the source file
     * @param destination String: the filename of the destination
     */
    public static void copy(String source, String destination) {

        FileInputStream in = null;
        FileOutputStream out = null;
        try {
            File inputFile = new File(source);
            File outputFile = new File(destination);

            in = new FileInputStream(inputFile);
            out = new FileOutputStream(outputFile);

            byte[] buffer = new byte[2048];
            int read = in.read(buffer);
            while (read != -1) {
                out.write(buffer, 0, read);
                read = in.read(buffer);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (in != null) try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (out != null) try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Creating folder, and all folders in path if they don't exist
     *
     * @param folderPath
     */
    public static void recursiveFolderCreator(String folderPath) {
        recursiveFolderCreator(folderPath.substring(0, folderPath.indexOf('\\') + 1), folderPath.substring(folderPath.indexOf('\\') + 1));
    }

    /**
     * Deletes file or folder. Folder could contain files or even other folders
     *
     * @param pathToFolderOrFile
     * @return
     */
    public static boolean recursiveDelete(File pathToFolderOrFile) {
        if (pathToFolderOrFile.isFile() && pathToFolderOrFile.exists()) {
            pathToFolderOrFile.delete();
        } else if (pathToFolderOrFile.exists()) {
            File[] files = pathToFolderOrFile.listFiles();
            for (int i = 0; i < files.length; i++) {
                if (files[i].isDirectory()) {
                    recursiveDelete(files[i]);
                } else {
                    files[i].delete();
                }
            }
        }
        return (pathToFolderOrFile.delete());
    }

    /**
     * extract a file from a jar archive
     *
     * @param jarArchive    String: the filename of the source archive
     * @param fileToExtract String: the name of the file to extract (full path from
     *                      archive root)
     */
    public static void extractFile(String jarArchive, String fileToExtract,
                                   String destination) {

        FileOutputStream writer = null;
        ZipInputStream zipStream = null;
        try {
            FileInputStream inputStream = new FileInputStream(jarArchive);
            BufferedInputStream bufferedStream = new BufferedInputStream(
                    inputStream);
            zipStream = new ZipInputStream(bufferedStream);
            writer = new FileOutputStream(new File(destination));
            ZipEntry zipEntry = null;
            while ((zipEntry = zipStream.getNextEntry()) != null) {
                if (zipEntry.getName().equals(fileToExtract)) {
                    int size = (int) zipEntry.getSize();
                    for (int i = 0; i < size; i++) {
                        writer.write(zipStream.read());
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (zipStream != null) try {
                zipStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (writer != null) try {
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void renameAllFilesInDir(String dir) {
        File f = new File(dir);
        if (!f.isDirectory()) return;
        File[] fis = f.listFiles(new FileFilter() {
            public boolean accept(File pathname) {
                return pathname.isFile();
            }
        });
        for (File fi : fis) {
            try {
                if (fi.getName().indexOf(".") != -1)
                    fi.renameTo(new File(f, SSRand.N_thrdSf().randomString() + fi.getName().substring(fi.getName().indexOf("."))));
                else
                    fi.renameTo(new File(f, SSRand.N_thrdSf().randomString()));
            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }
    }

    public static Writer getUtf8FileWriter(String file, boolean append) throws FileNotFoundException, UnsupportedEncodingException {
        return new OutputStreamWriter(new FileOutputStream(file, append), "utf-8");
    }

    public static Writer getW1251FileWriter(String file, boolean append) throws FileNotFoundException, UnsupportedEncodingException {
        return new OutputStreamWriter(new FileOutputStream(file, append), "windows-1251");
    }

    public static Writer getUtf8FileWriter(File file, boolean append) throws FileNotFoundException, UnsupportedEncodingException {
        return new OutputStreamWriter(new FileOutputStream(file, append), "utf-8");
    }

    public static Writer getW1251FileWriter(File file, boolean append) throws FileNotFoundException, UnsupportedEncodingException {
        return new OutputStreamWriter(new FileOutputStream(file, append), "windows-1251");
    }

    public static Writer getUtf8FileWriter(String file) throws FileNotFoundException, UnsupportedEncodingException {
        return new OutputStreamWriter(new FileOutputStream(file, false), "utf-8");
    }

    public static Writer getW1251FileWriter(String file) throws FileNotFoundException, UnsupportedEncodingException {
        return new OutputStreamWriter(new FileOutputStream(file, false), "windows-1251");
    }

    public static Writer getUtf8FileWriter(File file) throws FileNotFoundException, UnsupportedEncodingException {
        return new OutputStreamWriter(new FileOutputStream(file, false), "utf-8");
    }

    public static Writer getW1251FileWriter(File file) throws FileNotFoundException, UnsupportedEncodingException {
        return new OutputStreamWriter(new FileOutputStream(file, false), "windows-1251");
    }

    private static void recursiveFolderCreator(String prefixPath, String postfixPath) {
        if (!"".equals(postfixPath) && postfixPath.contains("\\")) {
            prefixPath = prefixPath + postfixPath.substring(0, postfixPath.indexOf('\\') + 1);
            postfixPath = postfixPath.substring(postfixPath.indexOf('\\') + 1);
            new File(prefixPath).mkdir();
            recursiveFolderCreator(prefixPath, postfixPath);
        }
    }

    public static void close(Closeable fw) {
        try {
            fw.close();
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public static void changeEncoding(String filePath, String wasEncoding, String becomeEncoding) throws IOException {
        Reader reader = null;
        Writer writer = null;
        File temp = File.createTempFile("encoding_changer", "ultra");
        try {
            reader = new InputStreamReader(new FileInputStream(filePath), wasEncoding);

            writer = new OutputStreamWriter(new FileOutputStream(temp), becomeEncoding);
            char[] buffer = new char[2048];
            int read = reader.read(buffer);
            while (read != -1) {
                writer.write(buffer, 0, read);
                read = reader.read(buffer);
            }
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            throw new IOException(e);
        } finally {
            close(reader);
            close(writer);
        }

        boolean deleted = new File(filePath).delete();
        if (deleted) {
            copy(temp.getAbsolutePath(),filePath);
        } else  throw new IOException("Can't delete file:" + filePath);
    }

    public static void main(String[] args) {
        try {
            changeEncoding("D:\\_QUIVER_\\Dropbox\\Projects\\Java\\temp\\Moxa2\\config.properties","utf-8", "windows-1251");
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }
}
