package ru.spb.kpit.kivan.General.Time;

import java.util.GregorianCalendar;
import java.util.Date;

/**
 * User: Kivan(Kivan)
 * Date: 19.08.2007
 * Time: 23:51:28
 * ������ �������, � �������� ����� �������� ���(�����) ����, ��������� � �����.
 * <div style="color:green">��� ������� ������� ������� �.�.[Kivan]</div>
 */
public class TimeStructure {
    public static final String version = "timeStructure(0.0.2)";

    public GregorianCalendar gc;

    public long inMiliseconds;

    public String ms;
    public String sec;
    public String min;
    public String hour;
    public String monthDay;
    public String weekDay;
    public String weekOfYear;
    public String month;
    /**
     * 2 �����
     */
    public String year;
    public boolean hasYearBig;
    /**
     * 4 ����� - c 2000 ����
     */
    public String yearBig;

    public TimeStructure() {        
        this(new GregorianCalendar());
    }

    public TimeStructure(GregorianCalendar gc) {
        getMainInfo(gc);
    }

    public int compareTo(TimeStructure ts){
        return gc.compareTo(ts.gc);
    }

    public TimeStructure(Date d){
        GregorianCalendar gc = new GregorianCalendar();
        gc.setTime(d);
        getMainInfo(gc);
    }

    public String toString(){
        return monthDay+"."+month+"."+yearBig;
    }

    public String toStringWithTime(){
        return monthDay+"."+month+"."+yearBig+"_"+hour+"."+min+"."+sec;
    }

    public String toStringWithTimeMS(){
        return monthDay+"."+month+"."+yearBig+"_"+hour+"."+min+"."+sec+"."+ms;
    }

    public static void main(String[] args) {
        TimeStructure ts = new TimeStructure();
        int i=0;
    }

    private void getMainInfo(GregorianCalendar gc) {
        this.gc = gc;
        ms = gc.get(GregorianCalendar.MILLISECOND)+"";
        ms = (ms.length()==1)?new StringBuilder().append("0").append("0").append(ms).toString():
                (ms.length()==2)?new StringBuilder().append("0").append(ms).toString():ms;
        sec = gc.get(GregorianCalendar.SECOND)+"";
        sec = (sec.length()==1)?new StringBuilder().append("0").append(sec).toString():sec;
        min = gc.get(GregorianCalendar.MINUTE)+"";
        min = (min.length()==1)?new StringBuilder().append("0").append(min).toString():min;
        hour = gc.get(GregorianCalendar.HOUR_OF_DAY)+"";
        hour = (hour.length()==1)?new StringBuilder().append("0").append(hour).toString():hour;
        monthDay = gc.get(GregorianCalendar.DAY_OF_MONTH)+"";
        monthDay = (monthDay.length()==1)?new StringBuilder().append("0").append(monthDay).toString():monthDay;
        weekDay = gc.get(GregorianCalendar.DAY_OF_WEEK)+"";
        weekOfYear = gc.get(GregorianCalendar.WEEK_OF_YEAR)+"";
        weekOfYear = (weekOfYear.length()==1)?new StringBuilder().append("0").append(weekOfYear).toString(): weekOfYear;
        month = (gc.get(GregorianCalendar.MONTH)+1)+"";
        month = (month.length()==1)?new StringBuilder().append("0").append(month).toString():month;
        year = gc.get(GregorianCalendar.YEAR)+"";
        hasYearBig = (year.length()==4)?true:false;
        year = (hasYearBig)?year.substring(2):year;
        yearBig = gc.get(GregorianCalendar.YEAR)+"";

        inMiliseconds = gc.getTimeInMillis();
    }
}
