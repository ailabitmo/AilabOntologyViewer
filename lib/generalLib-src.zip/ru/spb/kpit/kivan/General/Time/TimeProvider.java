package ru.spb.kpit.kivan.General.Time;

import java.util.Date;

/**
 * IDEA
 * : Kivan
 * : 07.01.14
 * : 15:09
 */
public interface TimeProvider {
    public Date getCurrentDate();
}
