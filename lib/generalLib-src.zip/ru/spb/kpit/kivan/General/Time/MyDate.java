package ru.spb.kpit.kivan.General.Time;

import java.util.Date;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 28.09.13
 * MomentOfSilence: 14:35
 */
public class MyDate {

    DateParser dpShort;
    DateParser dpLong;

    public MyDate() {
        this.dpShort = DateParser.dateParserFactory("DD.MM.YYYY");
        this.dpLong = DateParser.dateParserFactory("hh:mm DD.MM.YYYY");
    }

    public MyDate(String templateShort) {
        this.dpShort = DateParser.dateParserFactory(templateShort);
        this.dpLong = DateParser.dateParserFactory(templateShort);
    }

    public MyDate(String templateShort,String templateLong) {
        this.dpShort = DateParser.dateParserFactory(templateShort);
        this.dpLong = DateParser.dateParserFactory(templateLong);
    }

    public Date S(String dateShort){
        return dpShort.parseDate(dateShort);
    }

    public Date L(String dateLong){
        return dpLong.parseDate(dateLong);
    }
}
