package ru.spb.kpit.kivan.General.Time;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 08.06.2011
 * Time: 13:05:40
 * To change this template use File | Settings | File Templates.
 */
public class Ms {
    public final static long msInSec = 1000L;
    public final static long msInMin = 60L * msInSec;
    public final static long msInHour = 60L * msInMin;
    public final static long msInDay = 24L * msInHour;
    public final static long msInWeek = 7L * msInDay;

    public int ms = -1;
    public int sec = -1;
    public int min = -1;
    public int hour = -1;
    public int day = -1;
    public int week = -1;

    Long toRet = null;

    public Ms() {
        this(0);
    }

    public Ms(int ms) {
        this.ms = ms;
    }

    public Ms(int ms, int sec) {
        this.ms = ms;
        this.sec = sec;
    }

    public Ms(int ms, int sec, int min) {
        this.ms = ms;
        this.sec = sec;
        this.min = min;
    }

    public Ms(int ms, int sec, int min, int hour) {
        this.ms = ms;
        this.sec = sec;
        this.min = min;
        this.hour = hour;
    }

    public Ms(int ms, int sec, int min, int hour, int day) {
        this.ms = ms;
        this.sec = sec;
        this.min = min;
        this.hour = hour;
        this.day = day;
    }

    public Ms(int ms, int sec, int min, int hour, int day, int week) {
        this.ms = ms;
        this.sec = sec;
        this.min = min;
        this.hour = hour;
        this.day = day;
        this.week = week;
    }

    public Ms(int time, TimeType tt) {
        if (tt.equals(TimeType.Ms)) ms = time;
        else if (tt.equals(TimeType.Sec)) sec = time;
        else if (tt.equals(TimeType.Min)) min = time;
        else if (tt.equals(TimeType.Hour)) hour = time;
        else if (tt.equals(TimeType.Day)) day = time;
        else if (tt.equals(TimeType.Week)) week = time;
    }

    public long getInMs() {
        if (this.toRet == null) {
            Long toRet = 0L;
            if (ms != -1) toRet += ms;
            else if (sec != -1) toRet += sec * msInSec;
            else if (min != -1) toRet += min * msInMin;
            else if (hour != -1) toRet += hour * msInHour;
            else if (day != -1) toRet += day * msInDay;
            else if (week != -1) toRet += week * msInWeek;
            this.toRet = toRet;
        }
        return toRet;
    }

    public static long FromSec(int sec){
        return sec*msInSec;
    }
    public static long FromMin(int min){
        return min*msInMin;
    }
    public static long FromHour(int hour){
        return hour*msInHour;
    }
    public static long FromDay(int day){
        return day*msInDay;
    }

    public static enum TimeType {
        Ms, Sec, Min, Hour, Day, Week
    }
}
