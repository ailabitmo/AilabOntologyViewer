package ru.spb.kpit.kivan.General.Waiter;

public class SimpleWaiter implements Waiter {

    long waitTime=0l;
    public SimpleWaiter(long waitTime) {
        this.waitTime = waitTime;
    }

    public long getNextWaitTime() {
        return waitTime;
    }

    @Override
    public long getNextWaitTime(long timeAlreadyWaited) {
        long toRet = waitTime-timeAlreadyWaited;
        return (toRet>0)? toRet:0;
    }
}
