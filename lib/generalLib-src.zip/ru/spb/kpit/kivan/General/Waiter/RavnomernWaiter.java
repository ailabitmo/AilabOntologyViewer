package ru.spb.kpit.kivan.General.Waiter;

import ru.spb.kpit.kivan.General.Time.Ms;
import ru.spb.kpit.kivan.Randomizer.SSRand;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 04.09.13
 * Time: 12:55
 * To change this template use File | Settings | File Templates.
 */
public class RavnomernWaiter implements Waiter {
    int from;
    int to;

    public RavnomernWaiter(int fromSec, int toSec) {
        this.from = fromSec;
        this.to = toSec;
    }

    @Override
    public long getNextWaitTime() {
        int secsToRand = SSRand.thrdSf().randomInt(from,to);
        secsToRand = (secsToRand>0)?secsToRand:0;
        return Ms.FromSec(secsToRand);
    }

    @Override
    public long getNextWaitTime(long timeAlreadyWaited) {
        long toRet = getNextWaitTime()-timeAlreadyWaited;
        return (toRet>0)? toRet:0;
    }
}
