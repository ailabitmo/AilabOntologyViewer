package ru.spb.kpit.kivan.General.Waiter;

import ru.spb.kpit.kivan.General.Time.Ms;
import ru.spb.kpit.kivan.Randomizer.SSRand;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 31.08.13
 * Time: 1:15
 * To change this template use File | Settings | File Templates.
 */
public class GaussianWaiter implements Waiter {

    long minVal = 0;
    long mean = Ms.FromSec(10);
    long sko = Ms.FromSec(2);

    public GaussianWaiter(long mean, long sko) {
        this.mean = mean;
        this.sko = sko;
    }

    @Override
    public long getNextWaitTime() {
        long toRet = Math.round(SSRand.thrdSf().randomGaussian(mean+0d,sko+0d));
        return (toRet>minVal)? toRet:minVal;
    }

    @Override
    public long getNextWaitTime(long timeAlreadyWaited) {
        long toRet = getNextWaitTime()-timeAlreadyWaited;
        return (toRet>minVal)? toRet:minVal;
    }
}
