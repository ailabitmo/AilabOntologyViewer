package ru.spb.kpit.kivan.General.Waiter;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 31.08.13
 * Time: 1:13
 * To change this template use File | Settings | File Templates.
 */
public interface Waiter {
    public long getNextWaitTime();

    public long getNextWaitTime(long timeAlreadyWaited);
}

