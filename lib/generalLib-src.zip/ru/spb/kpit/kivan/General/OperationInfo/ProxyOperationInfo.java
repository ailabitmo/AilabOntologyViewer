package ru.spb.kpit.kivan.General.OperationInfo;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 19:00
 */
public class ProxyOperationInfo extends HtmlOperationInfo {
    String proxyUrl;

    @Override
    public void setUrl(String url) {
        proxyUrl = url;
    }

    public String getProxyUrl() {
        return proxyUrl;
    }

    public void setNormalUrl(String url) {
        super.setUrl(url);
    }
}
