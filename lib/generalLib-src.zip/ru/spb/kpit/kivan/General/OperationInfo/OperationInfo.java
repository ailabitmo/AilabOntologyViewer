package ru.spb.kpit.kivan.General.OperationInfo;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 30.08.13
 * Time: 23:51
 * To change this template use File | Settings | File Templates.
 */
public interface OperationInfo {
    public String operationReport();
}
