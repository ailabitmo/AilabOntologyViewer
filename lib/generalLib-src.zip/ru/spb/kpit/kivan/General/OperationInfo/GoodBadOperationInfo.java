package ru.spb.kpit.kivan.General.OperationInfo;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 31.08.13
 * Time: 21:36
 * To change this template use File | Settings | File Templates.
 */
public class GoodBadOperationInfo implements OperationInfo {
    protected boolean operationSuccessfull=false;

    public GoodBadOperationInfo() {
    }

    public void setOperationSuccessfull(boolean operationSuccessfull) {
        this.operationSuccessfull = operationSuccessfull;
    }

    public boolean isOperationSuccessfull() {
        return operationSuccessfull;
    }

    public String operationReport() {
        return "Succesfull:"+operationSuccessfull+"\r\n";
    }
}
