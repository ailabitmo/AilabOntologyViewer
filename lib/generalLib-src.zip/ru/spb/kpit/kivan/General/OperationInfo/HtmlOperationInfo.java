package ru.spb.kpit.kivan.General.OperationInfo;

import ru.spb.kpit.kivan.General.Time.TimeStructure;

import java.text.MessageFormat;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 31.08.13
 * Time: 21:35
 * To change this template use File | Settings | File Templates.
 */
public class HtmlOperationInfo extends GoodBadOperationInfo {
    private String url="";
    private String encoding="";
    private int connectionTimeoutParam=0;
    private int tryTimesParam=0;
    private int badlyDoneTimes = 0;

    private long startTime = 0l;
    private long endTime = 0l;

    private int sizeOfOutput = 0;

    private long requestNumber = 0;

    public long getRequestNumber() {
        return requestNumber;
    }

    public void setRequestNumber(long requestNumber) {
        this.requestNumber = requestNumber;
    }

    public int getSizeOfOutput() {
        return sizeOfOutput;
    }

    public void setSizeOfOutput(int sizeOfOutput) {
        this.sizeOfOutput = sizeOfOutput;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public int getBadlyDoneTimes() {
        return badlyDoneTimes;
    }

    public void setBadlyDoneTimes(int badlyDoneTimes) {
        this.badlyDoneTimes = badlyDoneTimes;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getEncoding() {
        return encoding;
    }

    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    public int getConnectionTimeoutParam() {
        return connectionTimeoutParam;
    }

    public void setConnectionTimeoutParam(int connectionTimeoutParam) {
        this.connectionTimeoutParam = connectionTimeoutParam;
    }

    public int getTryTimesParam() {
        return tryTimesParam;
    }

    public void setTryTimesParam(int tryTimesParam) {
        this.tryTimesParam = tryTimesParam;
    }

    public HtmlOperationInfo() {
        super();
    }

    public String operationReport() {
        if("".equals(url)) return "";
        return MessageFormat.format("ID: {10}\r\n{0}Url:{1}\r\nEncoding:{2}\r\nTimeOut:{3}\r\nTryParam:{4}\r\nBadTimes:{5}\r\nStart:{6}\r\nFinish:{7}\r\nLasts:{8}\r\nSizeOfIncoming:{9}",
                super.operationReport(), url, encoding, connectionTimeoutParam,  tryTimesParam,
                badlyDoneTimes, new TimeStructure(new Date(startTime)).toStringWithTimeMS(), new TimeStructure(new Date(endTime)).toStringWithTimeMS(),((double)(endTime-startTime))/1000+"s",
                sizeOfOutput, requestNumber
        );
    }
}
