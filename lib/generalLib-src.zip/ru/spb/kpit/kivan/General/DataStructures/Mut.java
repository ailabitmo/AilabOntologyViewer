package ru.spb.kpit.kivan.General.DataStructures;

/**
 * User: Kivan(hia)
 * Date: 06.09.2007
 * Time: 17:28:31
 * Mutable
 */
public class Mut<T>{
    public static String vesrion = "mut(1.0.0)";
    public T val;

    public Mut(T val) {
        this.val = val;
    }

    public String toString(){
        return val.toString();
    }
}
