package ru.spb.kpit.kivan.General.DataStructures;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 12.06.2011
 * Time: 18:11:22
 * To change this template use File | Settings | File Templates.
 */
public class HMList<A, B extends List> extends HM<A, B> {
    public B getCollectionOrCreateIt(A val){
        if(containsKey(val)) return get(val);
        B list = (B) new ArrayList();
        put(val, list);
        return list;
    }
}
