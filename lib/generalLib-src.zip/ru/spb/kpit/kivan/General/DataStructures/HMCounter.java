package ru.spb.kpit.kivan.General.DataStructures;

import ru.spb.kpit.kivan.Randomizer.Pair;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 15.01.2012
 * Time: 18:48:20
 * To change this template use File | Settings | File Templates.
 */
public class HMCounter<P> extends HashMap<P, Integer> {

    public int put(P key) {
        Integer numOfTimes = get(key);
        if (numOfTimes == null) {
            numOfTimes = 0;
        }
        super.put(key, numOfTimes + 1);
        return numOfTimes + 1;
    }

    public int put(P key, int value) {
        Integer numOfTimes = get(key);
        if (numOfTimes == null) {
            numOfTimes = 0;
        }
        super.put(key, numOfTimes + value);
        return numOfTimes + value;
    }

    public String printAscending() {
        HMList<Integer, List<P>> reverse = new HMList<Integer, List<P>>();
        for (P p : keySet()) {
            List<P> pp = reverse.getCollectionOrCreateIt(get(p));
            pp.add(p);
        }

        List<Integer> getEls = new ArrayList<Integer>(reverse.keySet());
        Collections.sort(getEls);

        StringBuilder sb = new StringBuilder("");
        for (Integer getEl : getEls) {
            sb.append(getEl + ":" + reverse.get(getEl) + "\r\n");
        }
        return sb.toString();
    }

    public List<Pair<P, Integer>> getValsWithHighestCounter() {
        List<Pair<P, Integer>> toRetList = new ArrayList<Pair<P, Integer>>();
        long maxValues = -1;
        for (Map.Entry<P, Integer> keyValuePair : this.entrySet()) {
            if (keyValuePair.getValue() > maxValues) {
                toRetList.clear();
                toRetList.add(new Pair<P, Integer>(keyValuePair.getKey(), keyValuePair.getValue()));
                maxValues = keyValuePair.getValue();
            } else if (keyValuePair.getValue() == maxValues)
                toRetList.add(new Pair<P, Integer>(keyValuePair.getKey(), keyValuePair.getValue()));
        }
        return toRetList;
    }

    public List<Pair<P, Integer>> getAllValuesSorted(Boolean ascending) {
        List<Pair<P, Integer>> toRetList = new ArrayList<Pair<P, Integer>>();
        for (Map.Entry<P, Integer> keyValuePair : this.entrySet()) {
            toRetList.add(new Pair<P, Integer>(keyValuePair.getKey(), keyValuePair.getValue()));
        }
        if (ascending) Collections.sort(toRetList, new Comparator<Pair<P, Integer>>() {
            public int compare(Pair<P, Integer> pair, Pair<P, Integer> pair1) {
                return pair.b.compareTo(pair1.b);
            }
        });
        else Collections.sort(toRetList, new Comparator<Pair<P, Integer>>() {
            public int compare(Pair<P, Integer> pair, Pair<P, Integer> pair1) {
                return -pair.b.compareTo(pair1.b);
            }
        });
        return toRetList;
    }

}
