package ru.spb.kpit.kivan.General.DataStructures;

import java.util.Set;
import java.util.HashSet;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 12.06.2011
 * Time: 23:09:12
 * To change this template use File | Settings | File Templates.
 */
public class HMSet<A, B extends Set> extends HM<A, B> {
    public B getCollectionOrCreateIt(A val){
        if(containsKey(val)) return get(val);
        B list = (B) new HashSet();
        put(val, list);
        return list;
    }
}

