package ru.spb.kpit.kivan.General.DataStructures;

import ru.spb.kpit.kivan.Randomizer.Pair;

import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 23.09.13
 * MomentOfSilence: 18:53
 */
public class SyncHMCounter<P> extends HMCounter<P> {

    ReentrantLock lock = new ReentrantLock();

    @Override
    public int put(P key) {
        try {
            lock.lock();
            return super.put(key);    //To change body of overridden methods use File | Settings | File Templates.
        } finally {
            lock.unlock();
        }
    }

    @Override
    public String printAscending() {
        try {
            lock.lock();
            return super.printAscending();    //To change body of overridden methods use File | Settings | File Templates.
        } finally {
            lock.unlock();
        }
    }

    @Override
    public List<Pair<P, Integer>> getValsWithHighestCounter() {
        try {
            lock.lock();
            return super.getValsWithHighestCounter();    //To change body of overridden methods use File | Settings | File Templates.
        } finally {
            lock.unlock();
        }
    }

    @Override
    public List<Pair<P, Integer>> getAllValuesSorted(Boolean ascending) {
        try {
            lock.lock();
            return super.getAllValuesSorted(ascending);    //To change body of overridden methods use File | Settings | File Templates.
        } finally {
            lock.unlock();
        }
    }

    @Override
    public Integer get(Object key) {
        try {
            lock.lock();
            return super.get(key);    //To change body of overridden methods use File | Settings | File Templates.
        } finally {
            lock.unlock();
        }
    }

    @Override
    public int size() {
        try {
            lock.lock();
            return super.size();    //To change body of overridden methods use File | Settings | File Templates.
        } finally {
            lock.unlock();
        }
    }
}
