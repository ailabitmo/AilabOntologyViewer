package ru.spb.kpit.kivan.General.DataStructures;

import java.util.HashSet;

/**
 * User: Kivan
 * Date: 18.02.2010
 * Time: 13:31:10
 */
public class HS<A> extends HashSet<A>{
}
