package ru.spb.kpit.kivan.General.DataStructures;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 03.07.2011
 * Time: 20:17:41
 * To change this template use File | Settings | File Templates.
 */
public class ArrList<P extends MyClone> extends ArrayList<P> {
    
    public ArrList<P> put(P p) {
        super.add(p);
        return this;
    }

    public ArrList<P> cloneDeep(){
        ArrList<P> arrp = new ArrList<P>();
        for (P p : this) {
            arrp.add((P) p.cloneMe());
        }
        return arrp;
    }

}
