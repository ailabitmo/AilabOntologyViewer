package ru.spb.kpit.kivan.General.DataStructures;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 12.06.2011
 * Time: 23:10:30
 * To change this template use File | Settings | File Templates.
 */
public class HMMap<A, B extends Map> extends HM<A, B> {
    public B getCollectionOrCreateIt(A val){
        if(containsKey(val)) return get(val);
        B list = (B) new HMMap();
        put(val, list);
        return list;
    }
}
