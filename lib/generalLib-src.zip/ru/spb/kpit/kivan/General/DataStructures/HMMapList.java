package ru.spb.kpit.kivan.General.DataStructures;

import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 08.12.12
 * Time: 17:43
 * To change this template use File | Settings | File Templates.
 */
public class HMMapList<A, B extends Map> extends HM<A, B> {
    public B getCollectionOrCreateIt(A val){
        if(containsKey(val)) return get(val);
        B list = (B) new HMList();
        put(val, list);
        return list;
    }
}
