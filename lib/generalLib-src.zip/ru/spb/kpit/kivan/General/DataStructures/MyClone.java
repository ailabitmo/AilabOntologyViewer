package ru.spb.kpit.kivan.General.DataStructures;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 06.07.2011
 * Time: 13:58:17
 * To change this template use File | Settings | File Templates.
 */
public interface MyClone<P> {
    public P cloneMe();
}
