package ru.spb.kpit.kivan.General.DataStructures;

import ru.spb.kpit.kivan.General.Strings.StringUtils;

import java.util.Comparator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 02.06.12
 * Time: 14:17
 * To change this template use File | Settings | File Templates.
 */
public class SortedSetWithLimit<V> {
    SortedSet<V> set;
    int numOfElements;
    Comparator<V> compa;

    public SortedSetWithLimit(int numOfElements, Comparator<V> comp) {
        this.numOfElements = numOfElements;
        set = new TreeSet<V>(comp);
        compa = comp;
    }

    public void add(V obj) {
        if (set.size() < numOfElements) set.add(obj);
        else {
            V last = set.last();
            if (compa.compare(last, obj) > 0 && !set.contains(obj)) {
                set.remove(last);
                set.add(obj);
            }
        }
    }

    public Set<V> getSet(){
        return set;
    }

    public static void main(String[] args) {
        SortedSetWithLimit<Double> doubleSet = new SortedSetWithLimit<Double>(3, new Comparator<Double>() {
            public int compare(Double o1, Double o2) {
                return o1.compareTo(o2);
            }
        });

        doubleSet.add(1d);
        doubleSet.add(2d);
        doubleSet.add(3d);
        doubleSet.add(4d);
        doubleSet.add(5d);
        doubleSet.add(0d);
        doubleSet.add(0d);
        System.out.println(StringUtils.gStrFrColEls(doubleSet.set));
    }
}
