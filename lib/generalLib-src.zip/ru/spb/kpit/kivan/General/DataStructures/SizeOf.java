package ru.spb.kpit.kivan.General.DataStructures;

import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.Set;

public class SizeOf {

    private static final boolean SKIP_STATIC_FIELD = true;
    private static final boolean SKIP_FINAL_FIELD = false;
    private static Class strCls;

    static {
        try {
            strCls = Class.forName("java.lang.String");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public static long sizeOf(Object object) {
        Mut<Long> nn = new Mut<Long>(0l);
        Mut<Long> links = new Mut<Long>(0l);
        HashSet<Integer> objects = new HashSet<Integer>();
        try {
            sizeOf(object, objects, nn,links, null);
        } catch (IllegalAccessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return nn.val + links.val * 4; //���������� ������ �������� �� 4 �����
    }

    private static void sizeOf(Object o, Set<Integer> doneObj, Mut<Long> currentSum, Mut<Long> countLinksToObjs, Field f) throws IllegalAccessException {
        if (o == null) return;
        Long size = getSizeIfPossible(o, f);
        if (size != null) currentSum.val += size;
            //Arrays
        else {
            countLinksToObjs.val++;
            int hash = System.identityHashCode(o);
            if (doneObj.contains(hash)) return;
            doneObj.add(hash);

            if (o.getClass() == strCls) {
                currentSum.val+=Long.valueOf(((String) o).getBytes().length) + 12;
                return;
            }

            String className = o.getClass().toString();
            if (className.contains("[")) {
                int arrayLength = Array.getLength(o);
                Long arrSize = getSizeOfArrayIfPossible(className, arrayLength);
                if (arrSize != null) currentSum.val += arrSize;
                else for (int i = 0; i < arrayLength; i++) {
                    Object nodeVal = null;
                    try {
                        nodeVal = Array.get(o, i);
                        sizeOf(nodeVal, doneObj, currentSum,countLinksToObjs, f);
                    } catch (Exception e) {
                        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                    }
                }
            }
            //Objects
            else {
                Field[] fields = o.getClass().getDeclaredFields();
                for (Field ff : fields) {
                    ff.setAccessible(true);

                    int modificatori = ff.getModifiers();
                    if (SKIP_STATIC_FIELD && Modifier.isStatic(modificatori)) continue;
                    else if (SKIP_FINAL_FIELD && Modifier.isFinal(modificatori)) continue;

                    Object obj = ff.get(o);
                    sizeOf(obj, doneObj, currentSum,countLinksToObjs, ff);
                }
            }
        }
    }

    private static Long getSizeOfArrayIfPossible(String className, int arraySize) {
        if("class [I".equals(className)) return (long) (4 * arraySize);
        if("class [D".equals(className)) return (long) (8 * arraySize);
        if("class [J".equals(className)) return (long) (8 * arraySize);
        if("class [S".equals(className)) return (long) (2 * arraySize);
        if("class [F".equals(className)) return (long) (4 * arraySize);
        if("class [Z".equals(className)) return (long) arraySize;
        if("class [B".equals(className)) return (long) arraySize;
        if("class [C".equals(className)) return (long) (2 * arraySize);
        return null;
    }

    private static Long getSizeIfPossible(Object obj, Field f) {
        Class c = (f != null) ? f.getType() : obj.getClass();
        if (c == java.lang.Integer.TYPE) return 4l;
        if (c == java.lang.Double.TYPE) return 8l;
        if (c == java.lang.Float.TYPE) return 4l;
        if (c == java.lang.Long.TYPE) return 8l;
        if (c == java.lang.Boolean.TYPE) return 1l;
        if (c == java.lang.Character.TYPE) return 2l;
        if (c == java.lang.Byte.TYPE) return 1l;
        if (c == java.lang.Short.TYPE) return 2l;
        if (c == java.lang.Void.TYPE) return 0l;

        return null;
    }

    private static String[] unit = {"b", "Kb", "Mb", "Gb"};

    /**
     * Format size in a human readable format
     *
     * @param size
     * @return a string representation of the size argument followed by
     *         b for byte, Kb for kilobyte or Mb for megabyte
     */
    public static String humanReadable(long size) {
        /*return size+"";*/
        int i;
        double dSize = size;//new Double(size);
        int x = 1000;
        for (i = 0; i < 4; ++i) {
            if (dSize < x)
                break;
            dSize /= x;
        }

        int rs = (int) (dSize * 100);
        dSize = (double) rs / 100;

        return dSize + unit[i];
    }

    public static void main(String[] args) throws IOException, IllegalAccessException {
        int size = 1000000;
        String[] buf = new String[]{"123456789012345678901234567890","098765432109876543210987654321","564738291056473829105647382910"};
        long frmem1 = Runtime.getRuntime().freeMemory();
        long allmem1 = Runtime.getRuntime().totalMemory();

        /*String[] arr = new String[size];
        for (int i = 0; i < size; i++) {
            //arr[i] = SSRand.thrdSf().randomString(20,20);
            arr[i] = buf[SSRand.thrdSf().randomInt(0,2)];
        }*/

        Integer[] arr = new Integer[size];
        for (int i = 0; i < size; i++) {
            arr[i] = 1;
        }

        /*List<Integer> arr = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            arr.add(1);
        }*/

        long frmem2 = Runtime.getRuntime().freeMemory();
        long allmem2 = Runtime.getRuntime().totalMemory();
        long dif = (allmem2 - frmem2) - (allmem1 - frmem1);
        long sz = SizeOf.sizeOf(arr);
        long difWithSize = Math.abs(sz - dif);
        System.out.println("Real:" + SizeOf.humanReadable(dif) + " Calc:" + SizeOf.humanReadable(sz) + " Dif:" + SizeOf.humanReadable(difWithSize) + " OTN:"+((double)sz/dif));
    }
}

