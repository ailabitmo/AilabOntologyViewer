package ru.spb.kpit.kivan.General.DataStructures;

import ru.spb.kpit.kivan.Randomizer.Pair;

import java.lang.reflect.Field;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 02.07.2011
 * Time: 23:54:35
 * To change this template use File | Settings | File Templates.
 */
public class DataUtils {
    public static <A,B> Map<A,B> produceMap(Pair<A,B>... p) {
        HashMap<A,B> hm = new HashMap<A, B>();
        for (Pair<A,B> pair : p) {
            hm.put(pair.a, pair.b);
        }
        return hm;
    }

    public static Object getValueOfFieldUnsafe(String fieldName, Object object){
        try {
            Field fld = object.getClass().getDeclaredField(fieldName);
            fld.setAccessible(true);
            return fld.get(object);
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }

    public static void setValueOfFieldUnsafe(String fieldName, Object value, Object object){
        try {
            Field fld = object.getClass().getDeclaredField(fieldName);
            fld.setAccessible(true);
            fld.set(object,value);
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    /**
     * ��������� ���� ������������� ���������
     *
     * @return
     */
    public static Collection flattenCollection(Collection col) {

        Collection toRet = null;
        try {
            toRet = col.getClass().newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (IllegalAccessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        for (Object o : col) {
            if (o instanceof Collection) {
                toRet.addAll(flattenCollection((Collection) o));
            } else {
                toRet.add(o);
            }
        }
        return toRet;
    }

    /**
     * ��������� ��������� � �������� ����� ����������
     *
     * @param dpA
     * @return
     */
    public static Collection flattenSmall(Collection dpA) {
        Collection toRet = null;
        try {
            toRet = dpA.getClass().newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (IllegalAccessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        for (Object o : dpA) {
            if (o instanceof Collection) {
                Collection c = (Collection) o;
                Collection cc = flattenSmall((Collection) o);
                if (cc.size() >= 2) {
                    toRet.add(cc);
                } else if (cc.size() == 1) {
                    toRet.add(cc);
                }

            } else {
                toRet.add(o);
            }
        }
        return toRet;
    }
}
