package ru.spb.kpit.kivan.General.DataStructures;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Queue;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 11.07.2011
 * Time: 19:03:36
 * To change this template use File | Settings | File Templates.
 */
public class ListWithLimit<P> implements Iterable<P>{
    ArrayList<P> list = new ArrayList<P>();

    int size;

    public ListWithLimit(int size) {
        this.size = size;
    }

    public int size() {
        return list.size();
    }

    public P get(int i){
        return list.get(i);
    }
    
    /**
     * If limit is exceeded - then push out first element and return it. else return null;
     * @param p
     * @return
     */
    public P add(P p) {
        if(list.size()<size){
            list.add(p);
            return null;
        } else{
            list.add(p);
            return list.remove(0);
        }
    }


    public Iterator<P> iterator() {
        return list.iterator();
    }
}
