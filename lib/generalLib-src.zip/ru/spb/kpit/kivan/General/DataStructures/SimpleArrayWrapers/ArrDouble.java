package ru.spb.kpit.kivan.General.DataStructures.SimpleArrayWrapers;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 09.07.2011
 * Time: 17:37:22
 * To change this template use File | Settings | File Templates.
 */
public class ArrDouble {
    public double[] arr;

    public ArrDouble(double... arr) {
        this.arr = arr;
    }
}
