package ru.spb.kpit.kivan.General.DataStructures;

import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.Equation;
import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.EquationSystem;
import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.FuncType;
import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Poly.Poly1_linear;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 30.01.12
 * Time: 14:19
 * To change this template use File | Settings | File Templates.
 */
public class ListOfNumsWLimit extends ListWithLimit<Number> {
    public ListOfNumsWLimit(int size) {
        super(size);
    }

    public Number getMedian() {
        List<Number> arrayCopy = new ArrayList<Number>(list);
        Collections.sort(arrayCopy, new Comparator<Number>() {
            public int compare(Number o1, Number o2) {
                return new Double(o1.doubleValue()).compareTo(o2.doubleValue());
            }
        });

        return arrayCopy.get(arrayCopy.size() / 2);
    }

    public Number getAverage() {
        Double sum = 0d;
        for (Number number : list) {
            sum += number.doubleValue();
        }

        return sum / list.size();
    }

    /**
     * ����������� � ��� �������� ���������
     */
    public Number getDifferential() {
        EquationSystem es = new EquationSystem();
        for (int k = 0; k < list.size(); k++) {
            Double vr = list.get(k).doubleValue();
            es.add(new Equation(new double[]{k}, vr));
        }

        Poly1_linear fs = (Poly1_linear) es.regressFunction(FuncType.poly1_lin);
        return fs.getA();
    }
    
    public Number getDiffBetweenFirstAndLast(){
        return list.get(list.size()-1).doubleValue()-list.get(0).doubleValue();
    }

}
