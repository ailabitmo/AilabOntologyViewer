package ru.spb.kpit.kivan.General.DataStructures;

import ru.spb.kpit.kivan.Randomizer.Pair;

import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 17.04.2011
 * Time: 13:57:16
 * To change this template use File | Settings | File Templates.
 */
public class HM<A, B> extends HashMap<A, B>   {
    public HM() {
    }

    public HM<A,B> add(A a, B b){
        this.put(a, b);
        return this;
    }

    public HM(Pair<A,B> ... vals){
        for (Pair<A, B> val : vals) {
            this.put(val.a, val.b);
        }
    }
}
