package ru.spb.kpit.kivan.General.DataStructures;


import ru.spb.kpit.kivan.General.Strings.StringUtils;

import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class MultiSet<P> implements Collection<P>, Iterable<P>{
    private HashMap<P, Integer> occurances = new HashMap<P, Integer>();

    public MultiSet() {
        super();
    }

    public MultiSet(MultiSet<P> c) {
        // Build the hashtable
        Iterator<P> it = occurances.keySet().iterator();
        while (it.hasNext()) {
            P next = it.next();
            addOccurance(it.next(), occurances.get(next));
        }
    }

    /**
     * ���� ��������� ���, �� �������� ���������� ���������, ����� ��������� � ��� ������������
     * @param o
     * @param count
     */
    public void addOccurance(P o, int count) {
        if (count > 0) {
            Integer i = (Integer) occurances.get(o);
            if (i == null) {
                occurances.put(o, new Integer(count));
            } else {
                occurances.put(o, new Integer(i.intValue() + count));
            }
        }
    }

    /**
     * ���������� �������� ���������� ���������.
     * @param o
     * @param count
     */
    public void setOccurance(P o, int count) {
        if (count > 0) {
            Integer i = (Integer) occurances.get(o);
            if (i == null) {
                occurances.put(o, new Integer(count));
            } else {
                occurances.put(o, new Integer(count));
            }
        }
    }

    public boolean removeOccurance(P o) {
        Integer i = (Integer) occurances.get(o);
        if (i == null) {
            return false;
        } else {
            int j = i.intValue() - 1;
            if (j > 0) {
                occurances.put(o, new Integer(j));
            } else {
                occurances.remove(o);
            }
            return true;
        }
    }

    public boolean add(P o) {
        addOccurance(o, 1);
        return true;
    }


    public void clear() {
        occurances.clear();
    }


    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MultiSet multiSet = (MultiSet) o;

        if (occurances != null ? !occurances.equals(multiSet.occurances) : multiSet.occurances != null) return false;

        return true;
    }


    public int hashCode() {
        return occurances != null ? occurances.hashCode() : 0;
    }

    public MultiSet<P> clone() {
        return new MultiSet<P>(this);
    }

    public int getOccurances(P o) {
        if (occurances.containsKey(o)) {
            return ((Integer) occurances.get(o)).intValue();
        } else {
            return 0;
        }
    }

    public boolean remove(Object o) {
        return removeOccurance((P) o);
    }

    public boolean containsAll(Collection<?> c) {
        try {
            throw new Exception("Not implemented!!!");
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return false;
    }

    public boolean addAll(Collection<? extends P> c) {
        for (P p : c) {
            add(p);
        }
        return true;
    }

    public boolean removeAll(Collection<?> c) {
        for (Object o : c) {
            removeOccurance((P) o);
        }
        return true;
    }

    public boolean retainAll(Collection<?> c) {
        try {
            throw new Exception("Not implemented!!!");
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return false;
    }

    public Set<P> convertToSet() {
        return occurances.keySet();
    }

    public int size() {
        int elements = 0;
        for (Integer integer : occurances.values()) {
            elements+=integer;
        }
        return elements;
    }

    public boolean isEmpty() {
        return occurances.size()==0;
    }

    public boolean contains(Object o) {
        return occurances.containsKey(o);
    }

    public Iterator<P> iterator(){
        return new MultiSetIterator<P>(this);
    }

    public Object[] toArray() {
        Object[] toRet = new Object[size()];
        int i =0;
        for (P p : this) {
            toRet[i++] = p;
        }
        return toRet;
    }

    public <T> T[] toArray(T[] a) {
        try {
            throw new Exception("Not implemented!!!");
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }

    public class MultiSetIterator<P> implements Iterator<P>{

        MultiSet<P> parent;
        Iterator<P> iteratorOverSet;
        int numsLeftInIterator;
        P curElement;
        boolean noMoreElements = false;

        public MultiSetIterator(MultiSet<P> ms) {
            parent = ms;
            iteratorOverSet = parent.occurances.keySet().iterator();
            if(!iteratorOverSet.hasNext()) {
                noMoreElements = true;
                return;
            } else {
                curElement = iteratorOverSet.next();
                numsLeftInIterator = occurances.get(curElement);
            }
        }

        public boolean hasNext() {
            if(numsLeftInIterator>0) noMoreElements = false;
            else if(numsLeftInIterator==0){
                noMoreElements = !iteratorOverSet.hasNext();
            }
            return !noMoreElements;
        }

        public P next() {
            if(noMoreElements) return null;
            else {
                if(numsLeftInIterator>0){
                    numsLeftInIterator--;
                    return curElement;
                } else if(numsLeftInIterator == 0){
                    if(!iteratorOverSet.hasNext()) {
                        noMoreElements = true;
                        return null;
                    } else {
                        curElement = iteratorOverSet.next();
                        numsLeftInIterator = occurances.get(curElement);
                        numsLeftInIterator--;
                        return curElement;
                    }
                }
            }
            return null;
        }

        public void remove() {
            try {
                throw new Exception("Not supported!");
            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }
    }

    public String toString() {
        return StringUtils.gStrFrMapEls(occurances);
    }

}
