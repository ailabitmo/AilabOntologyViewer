package ru.spb.kpit.kivan.General.CodeWritingInformer;

import ru.spb.kpit.kivan.General.DataStructures.HS;
import ru.spb.kpit.kivan.General.Strings.StringUtils;
import ru.spb.kpit.kivan.Randomizer.Pair;
import ru.spb.kpit.kivan.XML.XMLSerializer.Xml2ObjConverter;

import java.io.File;
import java.text.DateFormat;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 15.04.13
 * Time: 17:17
 * To change this template use File | Settings | File Templates.
 */
public class CodeWritingInformer {

    final static String sourcePathName = "src";

    public static void main(String[] args) {
        String pathToCode = "D:\\_QUIVER_\\Dropbox\\Projects\\Java";
        File f = new File(pathToCode);

        IdeaCodeExtractor extractor = new IdeaCodeExtractor();
        List<CodeInfo> ci = extractor.extractCode(f);
        Xml2ObjConverter.saveObject(ci, "MyCodeAsFor_15_04_2013",new File("D:\\_QUIVER_\\Dropbox\\Projects\\Java\\MyCodeAsFor_28_09_2013.xml"));

        List<CodeInfo> codeInfos = (List<CodeInfo>) Xml2ObjConverter.restoreObject(new File("D:\\_QUIVER_\\Dropbox\\Projects\\Java\\MyCodeAsFor_28_09_2013.xml"));
        HowMuchCodeIWrote(codeInfos);

        System.out.println();
        System.out.println("=========================================");
        System.out.println();
        WhichProjectsExist(codeInfos);

        System.out.println();
        System.out.println("=========================================");
        System.out.println();
        CodeLinesByProject(codeInfos);

        System.out.println();
        System.out.println("=========================================");
        System.out.println();
        periodBetweenCreateAndRemake(codeInfos);

        HS<String>  users = new HS<String>();
        for (CodeInfo codeInfo : codeInfos) {
          users.add(codeInfo.userCreated);
        }
        System.out.println(StringUtils.gStrFrColEls(users));

        int k = 0;
    }

    private static void periodBetweenCreateAndRemake(List<CodeInfo> codeInfos) {

        List<Pair<Long, CodeInfo>> lpa = new ArrayList<Pair<Long, CodeInfo>>();
        for (CodeInfo codeInfo : codeInfos) {
            if (codeInfo.lastEditedDate != null && codeInfo.creationDate != null && ("kivan".equalsIgnoreCase(codeInfo.userCreated) || "hia".equalsIgnoreCase(codeInfo.userCreated) || "hia".equalsIgnoreCase(codeInfo.userCreated) )) {
                Pair<Long, CodeInfo> longCodeInfoPair = new Pair<Long, CodeInfo>(codeInfo.lastEditedDate.getTime() - codeInfo.creationDate.getTime(), codeInfo);
                lpa.add(longCodeInfoPair);
            } else {
                lpa.add(new Pair<Long, CodeInfo>(0l, codeInfo));
            }
        }

        Collections.sort(lpa, new Comparator<Pair<Long, CodeInfo>>() {
            public int compare(Pair<Long, CodeInfo> o1, Pair<Long, CodeInfo> o2) {
                return -o1.a.compareTo(o2.a);
            }
        });

        DateFormat df = DateFormat.getInstance();
        for (Pair<Long, CodeInfo> longCodeInfoPair : lpa) {
            try {
                System.out.println(df.format(new Date(longCodeInfoPair.a)) +
                        " " +
                        longCodeInfoPair.b.codeAbsoluteFilePath+
                " "+df.format(longCodeInfoPair.b.creationDate) + " "+df.format(longCodeInfoPair.b.lastEditedDate));
            } catch (Exception e) {

            }
        }

    }

    //1. ������� �� ����� ���������� ����� ����?
    public static void HowMuchCodeIWrote(List<CodeInfo> codeInfos) {
        long codeLines = 0;
        for (CodeInfo codeInfo : codeInfos) {
            codeLines += codeInfo.codeLines;
        }
        System.out.println(codeLines);
    }

    //2. ����� ������������� ����� ���� �� ��������?
    public static void CodeLinesByProject(List<CodeInfo> codeInfos) {
        final HashMap<String, Integer> projectCodeLines = new HashMap<String, Integer>();
        Set<String> projectNames = new TreeSet<String>(new Comparator<String>() {
            public int compare(String o1, String o2) {
                return o1.toLowerCase().compareTo(o2.toLowerCase());
            }
        });
        for (CodeInfo codeInfo : codeInfos) {
            projectNames.add(codeInfo.projectFolderName);
            if (projectCodeLines.containsKey(codeInfo.projectFolderName)) {
                projectCodeLines.put(codeInfo.projectFolderName, projectCodeLines.get(codeInfo.projectFolderName) + codeInfo.codeLines);
            } else {
                projectCodeLines.put(codeInfo.projectFolderName, codeInfo.codeLines);
            }
        }

        Set<String> projectNames2 = new TreeSet<String>(new Comparator<String>() {
            public int compare(String o1, String o2) {
                return -projectCodeLines.get(o1).compareTo(projectCodeLines.get(o2));
            }
        });
        projectNames2.addAll(projectNames);

        for (String projectName : projectNames2) {
            System.out.println(projectName + ": " + projectCodeLines.get(projectName));
        }

    }

    //2.1. ����� ������ ������� ����?
    public static void WhichProjectsExist(List<CodeInfo> codeInfos) {
        Set<String> projectNames = new TreeSet<String>(new Comparator<String>() {
            public int compare(String o1, String o2) {
                if(o1 == null) o1 = "";
                if(o2 == null) o2 = "";
                return o1.toLowerCase().compareTo(o2.toLowerCase());
            }
        });

        for (CodeInfo codeInfo : codeInfos) {
            projectNames.add(codeInfo.projectFolderName);
        }

        System.out.println(projectNames.size());
        System.out.println(StringUtils.gStrFrColEls(projectNames, "\r\n"));
    }

}

