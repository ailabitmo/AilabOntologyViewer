package ru.spb.kpit.kivan.General.CodeWritingInformer;

import ru.spb.kpit.kivan.General.FileSystem.KivanFileScanner;
import ru.spb.kpit.kivan.General.Strings.StringUtils;
import ru.spb.kpit.kivan.General.Time.DateParser;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 15.04.13
 * Time: 18:06
 * To change this template use File | Settings | File Templates.
 */
public class IdeaCodeExtractor extends FileStructureRunnerExtractor {
    public CodeInfo processFile(File file) {
        CodeInfo ci = new CodeInfo();

        KivanFileScanner kfs = null;
        try {
            kfs = new KivanFileScanner(file);
            if(file.getName().indexOf(".groovy")>=0)ci.language = "Groovy";
            else ci.language = "Java";
            State state = State.Started;
            String date = "";
            //User + Date
            DateParser dp = DateParser.dateParserFactory("DD.MM.YY hh:mm");
            DateParser dp1 = DateParser.dateParserFactory("DD.MM.YYYY hh:mm");
            for (String kf : kfs) {
                if("".equals(kf.trim())) continue;
                if ((kf.contains("IntelliJ IDEA") || kf.contains("IntelliJ IDEA")) && state == State.Started) state = State.User;
                else if ((kf.contains("User:") || kf.contains("CodeGod:")) && state == State.User) {
                    String user = kf.substring(kf.indexOf(":")+ 1).trim();
                    ci.userCreated = user;
                    state = State.Date;
                } else if ((kf.contains("Date:") || kf.contains("ContinuumBreak")) && state == State.Date) {
                    date = kf.substring(kf.indexOf(":")+ 1).trim();
                    state = State.Time;
                } else if ((kf.contains("Time:") || kf.contains("MomentOfSilence")) && state == State.Time) {
                    String time = normalizeTime(kf.substring(kf.indexOf(":")+ 1).trim());
                    String dateAndTime = date + " " + time;
                    try {
                        ci.creationDate = dp.parseDate(dateAndTime);
                    } catch (RuntimeException e) {
                        try {
                            ci.creationDate = dp1.parseDate(dateAndTime);
                        } catch (RuntimeException e1) {
                            try {
                                dateAndTime = processStrangeIdeaDateTimeFormat(ci, dateAndTime);
                                ci.creationDate = dp1.parseDate(dateAndTime);
                            } catch (RuntimeException e2) {
                                e2.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                            }
                        }
                    }
                    state = State.WaitingForCode;
                } else if(!kf.contains("*") && state==State.WaitingForCode){
                    if(!"".equals(kf.trim())) ci.codeLines++;
                    state = State.Code;
                } else if (state == State.Code){
                    if(!"".equals(kf.trim())) ci.codeLines++;
                }
            }

            //File name, File path, File last edited
            ci.codeFileName = file.getName();
            ci.codeAbsoluteFilePath = file.getAbsolutePath();
            ci.lastEditedDate = new Date(file.lastModified());

            //ProjectName, File packagePath
            getProjectNameAndPackagePath(ci, file);


        } catch (FileNotFoundException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } finally {
            if (kfs != null)
                kfs.close();
        }
        return ci;
    }

    private String processStrangeIdeaDateTimeFormat(CodeInfo ci, String dateAndTime) {
        //"Sep 12, 2010 06:16"
        List<String> strings = StringUtils.split(dateAndTime,":, ");
        int month = monthsToNums.get(strings.get(0));
        String sMonth = month<10?"0"+month:month+"";
        String day = strings.get(1).length()==1?"0"+strings.get(1):strings.get(1);
        String year = strings.get(2);
        String hour = strings.get(3);
        String min = strings.get(4);
        //"DD.MM.YYYY hh:mm"
        String finalString = day+"."+sMonth+"."+year+ " "+hour+":"+min;
        return finalString;
    }

    private static HashMap<String, Integer> monthsToNums = new HashMap<String, Integer>();
    static {
        int i = 0;
        monthsToNums.put("Jan",i++);
        monthsToNums.put("Feb",i++);
        monthsToNums.put("Mar",i++);
        monthsToNums.put("Apr",i++);
        monthsToNums.put("May",i++);
        monthsToNums.put("Jun",i++);
        monthsToNums.put("Jul",i++);
        monthsToNums.put("Aug",i++);
        monthsToNums.put("Sep",i++);
        monthsToNums.put("Oct",i++);
        monthsToNums.put("Nov",i++);
        monthsToNums.put("Dec",i++);
    }

    private void getProjectNameAndPackagePath(CodeInfo ci, File file) {
        List<String> packages = new ArrayList<String>();
        boolean projectNameOk = true;
        while (true) {
            File parent = file.getParentFile();
            if (file.equals(rootFolder)) {
                projectNameOk = false;
                break;
            }
            file = parent;
            if (!"src".equalsIgnoreCase(parent.getName())) {
                packages.add(0, parent.getName());
            } else break;
        }
        String packagesS = "";
        String folderName = "";
        if(projectNameOk){
            folderName = file.getParentFile().getName();
            packagesS = StringUtils.gStrFrColEls(packages, ".");
        } else {
            folderName = packages.remove(0);
            folderName = packages.remove(0);
            packagesS = StringUtils.gStrFrColEls(packages,".");
        }
        ci.packagePath = packagesS;
        ci.projectFolderName = folderName;
    }

    private String normalizeTime(String time) {
        List<String> splitedTime = StringUtils.split(time, ":");
        String hour = splitedTime.get(0).length() == 1 ? "0" + splitedTime.get(0) : splitedTime.get(0);
        String minute = splitedTime.get(1);
        return hour + ":" + minute;
    }

    @Override
    public boolean isSuitableFile(File file) {
        if (file.getName().indexOf(".java") > 0 || file.getName().indexOf(".groovy") > 0) {
            KivanFileScanner kfs = null;
            try {
                kfs = new KivanFileScanner(file);
                for (String kf : kfs) {
                    if (kf.contains("Created with IntelliJ IDEA") || kf.contains("Created by IntelliJ IDEA") ) return true;
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            } finally {
                if (kfs != null)
                    kfs.close();
            }

        } else return false;
        return false;
    }

    private enum State {
        Started, User, Date, Time, WaitingForCode, Code;
    }
}
