package ru.spb.kpit.kivan.General.CodeWritingInformer;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 15.04.13
 * Time: 17:39
 * To change this template use File | Settings | File Templates.
 */
public class CodeInfo {
    public String projectFolderName;
    public String packagePath;
    public String codeFileName;
    public String codeAbsoluteFilePath;
    public String userCreated;
    public String language;
    public Date creationDate;
    public Date lastEditedDate;
    public int codeLines = 0;


    @Override
    public String toString() {
        return codeAbsoluteFilePath;
    }
}
