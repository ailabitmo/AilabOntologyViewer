package ru.spb.kpit.kivan.General.CodeWritingInformer;

import ru.spb.kpit.kivan.General.FileSystem.FileFolderUtils;
import ru.spb.kpit.kivan.General.FileSystem.KivanFileScanner;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 15.04.13
 * Time: 17:44
 * To change this template use File | Settings | File Templates.
 */
public abstract class FileStructureRunnerExtractor<P> {

    protected File rootFolder;
    public List<P> extractCode(File fileOrFolder){
        rootFolder = fileOrFolder;
        List<String> filePaths = processFolderFile(fileOrFolder);
        List<P> ci = new ArrayList<P>();
        for (String filePath : filePaths) {
            File f = new File(filePath);
            ci.add(processFile(f));
        }
        return ci;
    }

    protected List<String> processFolderFile(File fileOrFolder){
        List<String> filePaths = new ArrayList<String>();
        if(fileOrFolder.isDirectory()){
            File[] contents = fileOrFolder.listFiles();
            for (File content : contents) {
                filePaths.addAll(processFolderFile(content));
            }
        } else {
            if(isSuitableFile(fileOrFolder)) filePaths.add(fileOrFolder.getAbsolutePath());
        }
        return filePaths;
    }

    protected abstract P processFile(File file);
    protected abstract boolean isSuitableFile(File file);

    /*public static void main(String[] args) throws IOException {
        String toFile = "D:\\TEMP\\ToMitja\\all.txt";
        FileWriter fw = null;
        try {
            fw = new FileWriter(toFile);
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        String prefix = "D:\\TEMP\\ToMitja\\SvetaItmoCrawler2013\\src";
        final File f = new File("D:\\TEMP\\ToMitja\\SvetaItmoCrawler2013\\src");
        final FileWriter finalFw = fw;
        FileStructureRunnerExtractor ce = new FileStructureRunnerExtractor() {
            @Override
            protected Object processFile(File file) {
                try {
                    KivanFileScanner kfs = new KivanFileScanner(file,"windows-1251");
                    finalFw.append("\r\n");
                    finalFw.append("-------------------------------\n");
                    finalFw.append("����: "+file.getAbsolutePath()+"\r\n");
                    finalFw.append("\r\n");
                    int state = 0;
                    for (String kf : kfs) {
                        if(state==2) state=0;
                        if(kf.indexOf("*//*")>-1) state = 1;
                        else if(kf.indexOf("*//*")>-1) state = 2;
                        if(state==0) finalFw.append(kf).append("\r\n");
                    }
                } catch (IOException e) {
                    e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
                return null;
            }

            @Override
            protected boolean isSuitableFile(File file) {
                return (file.getName().indexOf(".java")>-1);
            }
        };

        ce.extractCode(f);
        fw.close();
    }*/

    public static void main(String[] args) {
        final String fromFolder = "D:\\_QUIVER_\\Dropbox\\Projects\\Web\\AilabOntologyViewer\\ailab.ontology.viewer.server\\src";
        final String toFile = "D:\\_QUIVER_\\Dropbox\\Projects\\Web\\AilabOntologyViewer\\code.txt";

        A a = new A();
        A b = new B();

        if(a.getClass().isAssignableFrom(b.getClass())){
            System.out.println("a<b");
        }
        if(b.getClass().isAssignableFrom(a.getClass())){
            System.out.println("a>b");
        }

        System.out.println(a.a+" "+b.a);

        /*try {
            final Writer fw = FileFolderUtils.getUtf8FileWriter(new File(toFile));

            FileStructureRunnerExtractor ce = new FileStructureRunnerExtractor() {
                @Override
                protected Object processFile(File file) {
                    try {

                        KivanFileScanner kfs = new KivanFileScanner(file,"utf-8");
                        fw.append("\r\n");
                        fw.append("-------------------------------\n");
                        fw.append("����: "+file.getAbsolutePath().substring(file.getAbsolutePath().indexOf("ru"))+"\r\n");
                        fw.append("\r\n");
                        int state = 0;
                        for (String kf : kfs) {
                            if(kf.indexOf("%%%")>-1){
                                fw.append("��������: ").append(kf.substring(kf.indexOf("%%%")+3)).append("\r\n\r\n");
                                state = 1;
                            }
                            else if(state==1 && kf.indexOf("*//*")>-1) state = 2;
                            else if(state==2) fw.append(kf).append("\r\n");
                        }
                    } catch (IOException e) {
                        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                    }
                    return null;
                }

                @Override
                protected boolean isSuitableFile(File file) {
                    return (file.getName().indexOf(".java")>-1);
                }
            };

            ce.extractCode(new File(fromFolder));
            fw.close();

            FileFolderUtils.changeEncoding(toFile,"utf-8","windows-1251");

        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }*/
    }

}

class A{
    public static int a = 0;
    static {
        a = 5;
    }

}

class B extends A{
    public static int b = 0;
    static {
        a = 4;
    }
};
