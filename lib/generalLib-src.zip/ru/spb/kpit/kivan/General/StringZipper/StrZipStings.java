package ru.spb.kpit.kivan.General.StringZipper;

import java.util.Date;

/**
 * User: Kivan(hia)
 * Date: 14.08.2007
 * Time: 17:43:24
 */
public class StrZipStings {
    public static String hello =        "<<<<<<<<<<<<<<<<<<<Hello>>>>>>>>>>>>>>>>>";
    public static String welcome =      "Welcome to -=Kivan's=- String Ziper tool.";
    public static String start =        "String Ziper g0t String with params :";
    public static String size =         "Size = ";
    public static String newSize =      "New Size = ";
    public static String bytes =        " bytes";
    public static String actionZip =    "Action = Zip";
    public static String actionUnzip =  "Action = Unzip";
    public static String Statistcs=     "-------------------Stats-----------------";
    public static String time =         "Work Time = ";
    public static String ms =           " ms";

    public static void header(int size, boolean zipOrUnzip){
        if(StrZip.getPrintText()){
            System.out.println(StrZipStings.hello);
            System.out.println(StrZipStings.welcome);
            System.out.println(StrZipStings.start);
            System.out.print(StrZipStings.size);
            System.out.print(size);
            System.out.println(StrZipStings.bytes);
            System.out.println((zipOrUnzip)?StrZipStings.actionZip:StrZipStings.actionUnzip);            
        }
    }

    public static void footer(int size, Date t2, Date t1){
        if(StrZip.getPrintText()){
            System.out.println(StrZipStings.Statistcs);
            System.out.print(StrZipStings.time);
            System.out.print(t2.getTime() - t1.getTime());
            System.out.println(StrZipStings.ms);
            System.out.print(StrZipStings.newSize);
            System.out.print(size);
            System.out.println(StrZipStings.bytes);
            System.out.println();
        }
    }
}
