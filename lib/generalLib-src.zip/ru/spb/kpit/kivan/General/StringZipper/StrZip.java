package ru.spb.kpit.kivan.General.StringZipper;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.Date;
import java.util.Arrays;

/**
 * User: Kivan(hia)
 * Date: 14.08.2007
 * Time: 16:34:12
 */
public class StrZip {
    public final static String version = "stringziper(0.1.2)"; 
    private static boolean printText = true;
    private final static int dif1 = 848;
    private final static int dif2 = 921;
    private final static int dif3 = 857;

    public static void setPrintText(boolean printText){
        StrZip.printText = printText;
    }
    public static boolean getPrintText(){
        return printText;
    }

    public static byte[] zip(String toZip){
        Date t1 = new Date();
        byte[] toRet;
        StrZipStings.header(toZip.length(),true);
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            GZIPOutputStream gzipos = new GZIPOutputStream(baos);

            gzipos.write(toZip.getBytes());
            gzipos.close();

            toRet = baos.toByteArray();
            Date t2 = new Date();
            StrZipStings.footer(toRet.length, t2, t1);
        } catch (IOException e) {e.printStackTrace();toRet=null;}
        return toRet;
    }

    public static String unZip(byte[] unZip){
        Date t1 = new Date();
        String toRet;
        StrZipStings.header(unZip.length,false);
        try {
            ByteArrayInputStream bais = new ByteArrayInputStream(unZip);
            GZIPInputStream gzipis = new GZIPInputStream(bais);

            StringBuilder sb  = new StringBuilder("");
            char curchar=(char)gzipis.read();

            while(curchar!='\uffff'){
                sb.append(curchar);
                curchar = (char)gzipis.read();
            }
            toRet = rusNorm(sb.toString());
            Date t2 = new Date();
            StrZipStings.footer(toRet.length(), t2, t1);
        } catch (IOException e) {e.printStackTrace();toRet="";}
        return toRet;
    }

    private static boolean isRus(char t){
        int intVal = (int)t;
        return (intVal >= 224 && intVal <= 255) || (intVal>=192 && intVal<=223) || intVal == 184 || intVal == 168;
    }

    private static int convRus(char t){
        int intVal = (int)t;
        if((intVal >= 224 && intVal <= 255) || (intVal>=192 && intVal<=223)) intVal+=dif1;
        else if(intVal == 184) intVal+=dif2;
        else if(intVal == 168) intVal+=dif3;
        return intVal;
    }

    public static String rusNorm(String input){
        char [] charset = input.toCharArray().clone();
        for(int i=0;i<charset.length;i++){
            if(isRus(charset[i])){
                charset[i] = (char)convRus(charset[i]);
            }
        }
        return new String(charset);
    }

    public static void main(String[] argv){
        StringBuilder sb = new StringBuilder();
        sb.append("� ����, � ��� ��� ����� kolotajment");

        byte[] zipped = StrZip.zip(sb.toString());
        System.out.println(Arrays.asList(zipped));
        String unziped = StrZip.unZip(zipped);
        System.out.println(unziped);
    }
}
