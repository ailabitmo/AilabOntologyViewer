package ru.spb.kpit.kivan.General.Strings;

import ru.spb.kpit.kivan.Randomizer.Pair;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 02.07.2011
 * Time: 19:49:22
 * To change this template use File | Settings | File Templates.
 */
public class SmartStringReader {
    String str;
    ArrayList<Pair<Integer, Integer>> infoParts = new ArrayList<Pair<Integer, Integer>>();

    public SmartStringReader(String str, String... delims) {
        this.str = str;
        Arrays.sort(delims);

        int startIndex = 0;
        for (int i = 0; i < str.length(); i++) {
            char curChar = str.charAt(i);
            if (Arrays.binarySearch(delims, curChar+"") >= 0) {
                infoParts.add(new Pair<Integer, Integer>(startIndex, i - 1));
                startIndex = i + 1;
            }
        }

        if (startIndex < str.length()) {
            infoParts.add(new Pair<Integer, Integer>(startIndex, str.length() - 1));
        }
    }

    public String getInfoInPart(int partNum) {
        if (partNum < infoParts.size()) {
            Pair<Integer, Integer> st_end = infoParts.get(partNum);
            return str.substring(st_end.a, st_end.b+1).trim();
        }
        return null;
    }

    public int numOfInfos(){
        return infoParts.size();
    }

    public static void main(String[] args) {
        String toTest = "2009-04-14 16:01:32.750,DROZDOVA,R,Released,RPL,Ready for planning,20494,�� �������� ������� ���� �8 �� ���������,S-����,�������,";
        SmartStringReader ssr = new SmartStringReader(toTest, ",");
        for(int i=0; i<ssr.numOfInfos(); i++){
            System.out.println(i+":"+ ssr.getInfoInPart(i));
        }
    }
}
