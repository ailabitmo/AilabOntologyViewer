package ru.spb.kpit.kivan.General.Strings;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 24.05.13
 * Time: 0:42
 * To change this template use File | Settings | File Templates.
 */
public class XmlStringCleaner extends StringReplacer {

    public XmlStringCleaner(Character ... chars) {
        super();
        for (Character aChar : chars) {
            addReplacement(aChar,"");
        }
        //addReplacement('&',"");
        //addReplacement('#',"");
        /*addReplacement('<',"");
        addReplacement('>',"");*/
        //addReplacement('\'',"");
        //addReplacement('"',"");
        //addReplacement('/',"");
    }
}
