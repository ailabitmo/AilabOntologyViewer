package ru.spb.kpit.kivan.General.Strings;

import java.util.Arrays;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 24.05.13
 * Time: 0:23
 * To change this template use File | Settings | File Templates.
 */
public class StringReplacer {
    private static final String[] _REPLACEMENT = new String[Character.MAX_VALUE+1];
    private String[] REPLACEMENT = new String[Character.MAX_VALUE+1];

    static {
        for(int i=Character.MIN_VALUE;i<=Character.MAX_VALUE;i++)
            _REPLACEMENT[i] = Character.toString(((char) i));
        /*// substitute
        REPLACEMENT['?'] =  "a";
        // remove
        REPLACEMENT['-'] =  "";
        // expand
        REPLACEMENT['?'] = "ae";*/
    }


    public StringReplacer() {
        REPLACEMENT = Arrays.copyOf(_REPLACEMENT,_REPLACEMENT.length );
    }

    public void addReplacement(Character ch, String replace){
        REPLACEMENT[ch] = replace;
    }

    public String replace(String toReplace){
        StringBuilder sb = new StringBuilder(toReplace.length());
        for(int i=0;i<toReplace.length();i++)
            sb.append(REPLACEMENT[toReplace.charAt(i)]);
        return sb.toString();
    }
}
