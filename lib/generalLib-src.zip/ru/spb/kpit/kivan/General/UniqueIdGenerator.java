package ru.spb.kpit.kivan.General;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 17.04.12
 * Time: 12:13
 * To change this template use File | Settings | File Templates.
 */
public class UniqueIdGenerator {
    private static long id=0;
    public synchronized static long nextId(){
        return id++;
    }
}
