package ru.spb.kpit.kivan.UI.LoadingPanel;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 17.04.12
 * Time: 18:20
 * To change this template use File | Settings | File Templates.
 */
public class PublisherProxy implements Publisher {
    public void toPublish(String str) {
        //System.out.println(str);
    }

    public void toPublish(String str, int val) {
        //System.out.println(str+":"+val);
    }

    public void toPublish(int val) {
        //System.out.println(val);
    }

    public void reset() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setIndeterminance(boolean indeterminate) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void newMaximumWithReset(Integer newMax) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void newMaximumWOReset(Integer newMax) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void toPublish100Percent(String info) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void toPublish() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public int getCurrentMaximum() {
        return -1;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Publisher startChildPublisher(LoadingPanel otherLp) {
        return new PublisherProxy();  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void stopChildPublisher() {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
