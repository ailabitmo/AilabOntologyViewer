package ru.spb.kpit.kivan.UI.LoadingPanel;

import javax.swing.*;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 22.01.12
 * Time: 19:53
 * To change this template use File | Settings | File Templates.
 */
public class LoadingPanel extends JComponent {
    private JProgressBar pr_mainProgress;
    private JPanel p_main;

    public LoadingPanel() {
        add(p_main);
        pr_mainProgress.setIndeterminate(true);
        pr_mainProgress.setVisible(false);
    }

    SwingWorkerPublisher sw;

    public void runTask(String strForIndeterminate, final MyRunnableWithLoading run) {
        sw = new SwingWorkerPublisher() {

            protected Object doInBackground() throws Exception {
                run.run();
                return null;
            }


            protected void done() {
                runChild = false;
                pr_mainProgress.setVisible(false);
                pr_mainProgress.setIndeterminate(true);
                revalidate();
                repaint();
                run.finised();
            }


            long lastJustMsgId = -1;
            long lastrstMsg = -1;
            long lastnewMsg = -1;
            long lastCid = -1;


            protected void process(List<MessageToLoader> chunks) {

                JustInfoMessage lastInfoMsg = new JustInfoMessage(lastJustMsgId, "", -1);
                ResetMessage rstMsg = new ResetMessage(lastrstMsg, true);
                NewMaxMessage newMsg = new NewMaxMessage(lastnewMsg, -1);
                ChangeIndetermMessage cid = new ChangeIndetermMessage(lastCid, true);

                for (MessageToLoader chunk : chunks) {
                    if (chunk instanceof JustInfoMessage) {
                        if (chunk.idMessage > lastInfoMsg.idMessage) lastInfoMsg = (JustInfoMessage) chunk;
                    } else if (chunk instanceof NewMaxMessage) {
                        if (chunk.idMessage > newMsg.idMessage) newMsg = (NewMaxMessage) chunk;
                    } else if (chunk instanceof ResetMessage) {
                        if (chunk.idMessage > rstMsg.idMessage) rstMsg = (ResetMessage) chunk;
                    } else if (chunk instanceof ChangeIndetermMessage) {
                        if (chunk.idMessage > cid.idMessage) cid = (ChangeIndetermMessage) chunk;
                    }
                }

                TreeSet<MessageToLoader> loaderSet = new TreeSet<MessageToLoader>(new Comparator<MessageToLoader>() {
                    public int compare(MessageToLoader o1, MessageToLoader o2) {
                        return new Long(o1.idMessage).compareTo(o2.idMessage);
                    }
                });
                if (cid.idMessage > lastCid) loaderSet.add(cid);
                if (rstMsg.idMessage > lastrstMsg) loaderSet.add(rstMsg);
                if (newMsg.idMessage > lastnewMsg) loaderSet.add(newMsg);
                if (lastInfoMsg.idMessage > lastJustMsgId) loaderSet.add(lastInfoMsg);
                for (MessageToLoader msg : loaderSet) {
                    if (lastInfoMsg.idMessage == msg.idMessage) {
                        lastJustMsgId = lastInfoMsg.idMessage;
                        pr_mainProgress.setValue(lastInfoMsg.value);
                        if (lastInfoMsg.info != null && !"".equals(lastInfoMsg.info))
                            pr_mainProgress.setString(lastInfoMsg.info);
                    } else if (rstMsg.idMessage == msg.idMessage) {
                        lastrstMsg = rstMsg.idMessage;
                        if (rstMsg.reset) pr_mainProgress.setValue(0);
                    } else if (newMsg.idMessage == msg.idMessage) {
                        lastnewMsg = newMsg.idMessage;
                        pr_mainProgress.setMaximum(newMsg.newMax);
                    } else if (cid.idMessage == msg.idMessage) {
                        lastCid = cid.idMessage;
                        pr_mainProgress.setIndeterminate(cid.indeterm);
                    }
                }

                pr_mainProgress.revalidate();
                //revalidate();
                //repaint();
            }
        };

        pr_mainProgress.setString(strForIndeterminate);
        pr_mainProgress.setVisible(true);
        revalidate();
        repaint();
        sw.execute();
    }

    public Publisher getPublisher() {
        sw.reset();
        return sw;
    }

    private abstract class SwingWorkerPublisher extends SwingWorker<Object, MessageToLoader> implements Publisher {

        long publishId = 0;

        long getPublishId() {
            return publishId++;
        }

        long lastUpdatedMs = -1;
        long minTimeBetweenUpdates = 500;

        int curValue;
        int maxValue;
        volatile boolean runChild = true;

        public void reset() {
            curValue = 0;
            super.publish(new ResetMessage(getPublishId(), true));
        }

        public void setIndeterminance(boolean indeterminate) {
            super.publish(new ChangeIndetermMessage(getPublishId(), indeterminate));
        }

        public void newMaximumWithReset(Integer newMax) {
            reset();
            maxValue = newMax;
            super.publish(new NewMaxMessage(getPublishId(), newMax));
        }

        public void newMaximumWOReset(Integer newMax) {
            maxValue = newMax;
            super.publish(new NewMaxMessage(getPublishId(), newMax));
        }

        public void toPublish100Percent(String info) {
            super.publish(new JustInfoMessage(getPublishId(), info, curValue++));
        }

        public void toPublish(String info) {
            if (testSend())
                super.publish(new JustInfoMessage(getPublishId(), info, curValue++));
            else curValue++;
        }

        public void toPublish() {
            if (testSend())
                super.publish(new JustInfoMessage(getPublishId(), curValue++));
            else curValue++;
        }

        public int getCurrentMaximum() {
            return maxValue;
        }

        public void toPublish(int val) {
            if (testSend())
                super.publish(new JustInfoMessage(getPublishId(), val));
        }

        public void toPublish(String str, int val) {
            if (testSend()) {
                long pid = getPublishId();
                System.out.println("pid = " + pid);
                super.publish(new JustInfoMessage(pid, str, val));
            }

        }


        public Publisher startChildPublisher(final LoadingPanel otherLp) {
            runChild = true;
            otherLp.runTask("", new MyRunnableWithLoading() {

                public void finised() {
                    otherLp.setVisible(false);
                    revalidate();
                    repaint();
                }

                public void run() {
                    while (runChild)
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                        }
                }
            });
            return otherLp.getPublisher();
        }

        public void stopChildPublisher() {
            runChild = false;
        }

        private boolean testSend() {
            Long curms = System.currentTimeMillis();
            if (curms - lastUpdatedMs > minTimeBetweenUpdates) {
                lastUpdatedMs = curms;
                return true;
            }
            return false;
        }
    }

    private abstract class MessageToLoader {
        long idMessage;

        protected MessageToLoader(long idMessage) {
            this.idMessage = idMessage;
        }
    }

    private class JustInfoMessage extends MessageToLoader {
        String info;
        int value;


        private JustInfoMessage(long idMessage, int value) {
            super(idMessage);
            this.value = value;
        }

        private JustInfoMessage(long idMessage, String info, int value) {
            super(idMessage);
            this.info = info;
            this.value = value;
        }
    }

    private class ResetMessage extends MessageToLoader {
        boolean reset;

        private ResetMessage(long idMessage, boolean reset) {
            super(idMessage);
            this.reset = reset;
        }
    }

    private class NewMaxMessage extends MessageToLoader {
        int newMax;

        private NewMaxMessage(long idMessage, int newMax) {
            super(idMessage);
            this.newMax = newMax;
        }
    }

    private class ChangeIndetermMessage extends MessageToLoader {
        boolean indeterm;

        private ChangeIndetermMessage(long idMessage, boolean indeterm) {
            super(idMessage);
            this.indeterm = indeterm;
        }
    }


}
