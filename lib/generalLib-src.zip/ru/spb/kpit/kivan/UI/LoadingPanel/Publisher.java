package ru.spb.kpit.kivan.UI.LoadingPanel;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 22.01.12
 * Time: 21:19
 * To change this template use File | Settings | File Templates.
 */
public interface Publisher {
    public void toPublish(String str);

    public void toPublish(String str, int val);

    public void toPublish(int val);

    public void reset();

    public void setIndeterminance(boolean indeterminate);

    public void newMaximumWithReset(Integer newMax);

    public void newMaximumWOReset(Integer newMax);

    public void toPublish100Percent(String info);

    public void toPublish();
    
    public int getCurrentMaximum();

    public Publisher startChildPublisher(LoadingPanel otherLp);

    public void stopChildPublisher();

}
