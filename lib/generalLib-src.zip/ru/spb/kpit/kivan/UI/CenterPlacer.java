package ru.spb.kpit.kivan.UI;

import java.awt.*;

/**
 * User: Kivan(hia)
 * Date: 07.09.2007
 * Time: 11:16:44
 * ����� � ������� �������� ����� ����������� ���� � ������ ������ :)
 */
public class CenterPlacer {

    public final static String version = "centerplacer(0.1.4)";

    static Toolkit kit;
    static {
        kit = Toolkit.getDefaultToolkit();
    }

    public static Dimension centerCoordsDim(){
        return new Dimension(kit.getScreenSize().width>>1,kit.getScreenSize().height>>1);
    }

    public static Point centerCoords(){
        return new Point(kit.getScreenSize().width>>1,kit.getScreenSize().height>>1);
    }

    public static Dimension makeWindowCeneteredDim(Dimension windowSize){
        Dimension center = centerCoordsDim();
        Integer x = center.width - windowSize.width/2;
        Integer y = center.height - windowSize.height/2;
        return new Dimension(x,y);
    }

    public static Point makeWindowCenetered(Dimension windowSize){
        Dimension center = centerCoordsDim();
        Integer x = center.width - windowSize.width/2;
        Integer y = center.height - windowSize.height/2;
        return new Point(x,y);
    }

    public static void main(String[] args) {

    }
}
