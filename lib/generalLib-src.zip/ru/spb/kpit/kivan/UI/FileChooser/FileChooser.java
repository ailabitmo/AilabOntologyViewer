package ru.spb.kpit.kivan.UI.FileChooser;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 21.01.12
 * Time: 20:35
 * To change this template use File | Settings | File Templates.
 */
public class FileChooser extends JComponent {
    private JTextField tf_file_path;
    private JButton b_openPNet;
    private JLabel l_lbl;
    private JPanel p_main;
    private JPanel p_topLevel;

    private String textForFiles = "File for you ...";
    private String[] fileType = new String[]{"txt"};

    public FileChooser() {

    }

    public String getFileName() {
        return tf_file_path.getText();
    }

    public File getFile() {
        return new File(getFileName());
    }

    public boolean fileExist() {
        return getFile().exists();
    }

    public void setFileType(String[] fileType) {
        this.fileType = fileType;
    }

    public void setTextForFiles(String textForFiles) {
        this.textForFiles = textForFiles;
    }

    public void setText(String text) {
        l_lbl.setText(text);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("FileChooser");
        frame.setContentPane(new FileChooser().p_topLevel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private void createUIComponents() {
        add(p_topLevel);
        String text = "������� ���� � �����";
        l_lbl.setText(text);
        b_openPNet.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser(new File("").getAbsolutePath());
                FileNameExtensionFilter filter = new FileNameExtensionFilter(
                        textForFiles, fileType);
                chooser.setFileFilter(filter);
                int returnVal = chooser.showOpenDialog(p_main);
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    tf_file_path.setText(chooser.getSelectedFile().getAbsolutePath());
                }
            }
        });
    }
}
