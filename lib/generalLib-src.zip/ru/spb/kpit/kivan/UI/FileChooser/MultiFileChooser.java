package ru.spb.kpit.kivan.UI.FileChooser;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 24.01.12
 * Time: 16:33
 * To change this template use File | Settings | File Templates.
 */
public class MultiFileChooser extends JComponent {
    private JList list1;
    private JButton b_add;
    private JButton removeButton;
    public JPanel jp_main;

    private String textForFiles = "File for you ...";
    private String[] fileType = new String[]{"txt"};

    public MultiFileChooser() {
        add(jp_main);
        list1.setModel(new DefaultListModel());
        b_add.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser(new File("").getAbsolutePath());
                FileNameExtensionFilter filter = new FileNameExtensionFilter(
                        textForFiles, fileType);
                chooser.setFileFilter(filter);
                int returnVal = chooser.showOpenDialog(jp_main);
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    if (chooser.getSelectedFile().getAbsolutePath() != null)
                        ((DefaultListModel) list1.getModel()).addElement(chooser.getSelectedFile().getAbsolutePath());
                }
            }
        });
        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int ind = list1.getSelectedIndex();
                ((DefaultListModel) list1.getModel()).remove(ind);
            }
        });

    }

    public void setFileType(String[] fileType) {
        this.fileType = fileType;
    }

    public void setTextForFiles(String textForFiles) {
        this.textForFiles = textForFiles;
    }

    public List<String> getFileNameList() {
        ArrayList<String> lst = new ArrayList<String>();
        for (int i = 0; i < ((DefaultListModel) list1.getModel()).getSize(); i++) {
            String val = (String) ((DefaultListModel) list1.getModel()).get(i);
            lst.add(val);
        }
        return lst;
    }

    public List<File> getFileList() {
        ArrayList<File> lst = new ArrayList<File>();
        for (int i = 0; i < ((DefaultListModel) list1.getModel()).getSize(); i++) {
            String val = (String) ((DefaultListModel) list1.getModel()).get(i);
            lst.add(new File(val));
        }
        return lst;
    }

    public List<File> getExistedFileList() {
        ArrayList<File> lst = new ArrayList<File>();
        for (int i = 0; i < ((DefaultListModel) list1.getModel()).getSize(); i++) {
            String val = (String) ((DefaultListModel) list1.getModel()).get(i);
            File f = new File(val);
            if (f.exists())
                lst.add(new File(val));
        }
        return lst;
    }

}
