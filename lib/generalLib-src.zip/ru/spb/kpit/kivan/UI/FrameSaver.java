package ru.spb.kpit.kivan.UI;

import ru.spb.kpit.kivan.Async.AsyncOrderedTaskExecutor;
import ru.spb.kpit.kivan.Randomizer.Pair;

import javax.swing.*;
import java.io.File;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 15.07.12
 * Time: 13:46
 * To change this template use File | Settings | File Templates.
 */
public class FrameSaver {

    public volatile boolean finished = false;

    public FrameSaver(final List<Pair<String, JFrame>> frames, String baseFolder, int secsToWait) {
        if(baseFolder.charAt(baseFolder.length()-1)!='\\') baseFolder=baseFolder+"\\";
        new File(baseFolder).mkdirs();
        for (Pair<String, JFrame> fr : frames) {
            if(!fr.b.isVisible())fr.b.setVisible(true);
        }

        final AsyncOrderedTaskExecutor executor = new AsyncOrderedTaskExecutor(secsToWait * 1000);
        final String finalOR1 = baseFolder;
        executor.addTask(new Runnable() {
            public void run() {

                for (Pair<String, JFrame> fr_path : frames) {
                    UiUtils.defaultSaveComponent(fr_path.b.getContentPane(), finalOR1 + fr_path.a);
                }

                for (Pair<String, JFrame> fr_path : frames) {
                    fr_path.b.dispose();
                }
                finished = true;
                executor.finish();
            }
        });
    }

}
