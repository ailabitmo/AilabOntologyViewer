package ru.spb.kpit.kivan.UI;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

import ru.spb.kpit.kivan.General.FileSystem.FileFolderUtils;

import javax.imageio.ImageIO;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 07.07.2011
 * Time: 12:22:43
 * To change this template use File | Settings | File Templates.
 */
public class UiUtils {
    public static void saveComponentAsJPEG(Component myComponent, String filename) {
        Dimension size = myComponent.getSize();
        BufferedImage myImage =
                new BufferedImage(size.width, size.height,
                        BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = myImage.createGraphics();
        myComponent.paint(g2);
        try {
            //����� �� �����������...
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        try {
            File f = new File(filename+".jpeg");
            if (!f.getParentFile().exists()) {
                FileFolderUtils.recursiveFolderCreator(f.getParentFile().getAbsolutePath()+"\\");
            }
            ImageIO.write(myImage, "jpeg", f);

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void saveComponentAsBMP(Component myComponent, String filename) {
        Dimension size = myComponent.getSize();
        BufferedImage myImage =
                new BufferedImage(size.width, size.height,
                        BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = myImage.createGraphics();
        myComponent.paint(g2);
        try {
            //����� �� �����������...
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        try {
            File f = new File(filename+".bmp");
            if (!f.getParentFile().exists()) {
                FileFolderUtils.recursiveFolderCreator(f.getParentFile().getAbsolutePath()+"\\");
            }

            ImageIO.write(myImage, "bmp", f);

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void saveComponentAsPNG(Component myComponent, String filename) {
        Dimension size = myComponent.getSize();
        BufferedImage myImage =
                new BufferedImage(size.width, size.height,
                        BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = myImage.createGraphics();
        myComponent.paint(g2);
        try {
            //����� �� �����������...
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        try {
            File f = new File(filename+".png");
            if (!f.getParentFile().exists()) {
                FileFolderUtils.recursiveFolderCreator(f.getParentFile().getAbsolutePath()+"\\");
            }

            ImageIO.write(myImage, "png", f);

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void defaultSaveComponent(Component myComponent, String filename){
        saveComponentAsPNG(myComponent, filename);
    }

}
