package ru.spb.kpit.kivan.Config;

import ru.spb.kpit.kivan.General.FileSystem.FileFolderUtils;

import java.io.*;
import java.util.Properties;
import java.util.List;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 * User: Kivan
 * Date: 19.02.2010
 * Time: 22:42:14
 */
public class Config {
    Properties p = new Properties();

    public String file;

    public Config(String file, String defaultFileData) {
        this.file = file;

        FileInputStream fis = null;
        InputStreamReader inR = null;
        try {
            fis = new FileInputStream(file);
            inR = new InputStreamReader(fis, "Windows-1251");
        } catch (IOException e) {
            createDefaultFile(file, defaultFileData);
            try {
                fis = new FileInputStream(file);
            } catch (FileNotFoundException e1) {
                e1.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }

        try {
            p.load(inR);

        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    private void createDefaultFile(String s, String defaultFileData) {
        FileFolderUtils.writeToFile(s, defaultFileData);
    }

    private void createDefaultFile(String s, String defaultFileData, String encoding) {
        FileFolderUtils.writeToFile(s, defaultFileData,encoding);
    }

    /**
     * �������� ������
     *
     * @param key
     * @return
     */
    public String gS(String key) {
        String st = p.getProperty(key);
        if (st != null)
            return st.trim();
        return null;
    }

    public void setS(String key, String val) {
        p.setProperty(key, val);
    }

    public void save() {
        try {
            p.store(new FileWriter(file), "");
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    /**
     * �������� ���� �����. ����������� ���������� ����������, �������� "|" ��� ";"
     */
    public List<String> gLS(String key, String delimeter) {
        String stringWithList = p.getProperty(key);
        if (stringWithList == null) return null;
        StringTokenizer st = new StringTokenizer(stringWithList, delimeter);
        List<String> toRet = new ArrayList<String>(st.countTokens());
        while (st.hasMoreElements()) {
            String token = st.nextToken().trim();
            if (!"".equals(token))
                toRet.add(token);
        }
        return toRet;
    }

    /**
     * �������� ���� ����� �����. ����������� ���������� ����������, �������� "|" ��� ";"
     */
    public List<Integer> gLI(String key, String delimeter) {
        String stringWithList = p.getProperty(key);
        if (stringWithList == null) return null;
        StringTokenizer st = new StringTokenizer(stringWithList, delimeter);
        List<Integer> toRet = new ArrayList<Integer>(st.countTokens());
        while (st.hasMoreTokens()) {
            String token = st.nextToken().trim();
            if (!"".equals(token))
                toRet.add(Integer.valueOf(token));
        }
        return toRet;
    }

    /**
     * �������� �����
     *
     * @param key
     * @return
     */
    public Integer gI(String key) {
        String st = p.getProperty(key);
        if (st != null)
            return Integer.valueOf(p.getProperty(key).trim());
        return null;
    }

    /**
     * �������� ������� �����
     *
     * @param key
     * @return
     */
    public Float gF(String key) {
        String st = p.getProperty(key);
        if (st != null)
            return Float.valueOf(p.getProperty(key).trim());
        return null;
    }

    public void addParam(String key, String value) {
        p.setProperty(key, value);
    }
}
