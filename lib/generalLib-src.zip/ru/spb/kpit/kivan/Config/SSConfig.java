package ru.spb.kpit.kivan.Config;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 17.04.2011
 * Time: 13:37:13
 * To change this template use File | Settings | File Templates.
 */
public class SSConfig {
    static volatile Config config = null;
    static String file;
    static String defFileData;

    public static void init(String file, String defFileData) {
        if (config == null)
            config = new Config(file, defFileData);
    }

    public static Config provide() {
        if(config==null) config = new Config("config.properties", defFileData);

        assert config != null;
        return config;
    }

}
