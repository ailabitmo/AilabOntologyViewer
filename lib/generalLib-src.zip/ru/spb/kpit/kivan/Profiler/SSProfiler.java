package ru.spb.kpit.kivan.Profiler;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 17.04.2011
 * Time: 13:52:14
 * To change this template use File | Settings | File Templates.
 */
public class SSProfiler {
    static Profiler sync_prof = null;
    static Profiler unsafe_prof = null;

    static {
        sync_prof = new SyncProfiler();
        unsafe_prof = new PlainProfiler();
    }

    public static Profiler thrdSafe() {
        return sync_prof;
    }

    public static Profiler thrdNOTSafe() {
        return unsafe_prof;
    }

}
