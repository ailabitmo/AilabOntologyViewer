package ru.spb.kpit.kivan.Profiler;

import java.util.HashMap;
import java.util.TreeSet;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 15.09.2010
 * Time: 12:12:20
 * To change this template use File | Settings | File Templates.
 */
public class PlainProfiler implements Profiler {
    HashMap<String, HashMap<String, ProfileInfo>> info = new HashMap<String, HashMap<String, ProfileInfo>>();
    boolean dontwork = false;

    private String def = "default group";

    @Override
    public Long getTime() {
        return System.nanoTime();
    }

    @Override
    public void start(String label) {
        start(label, def);
    }

    @Override
    public void start(String label, int num) {
        start(label, num + "");
    }

    @Override
    public void start(String label, String group) {
        if (!dontwork) {
            HashMap<String, ProfileInfo> groupMap = info.get(group);
            if (groupMap == null) {
                groupMap = new HashMap<String, ProfileInfo>();
                info.put(group, groupMap);
            }



            ProfileInfo inf = groupMap.get(label);
            if (inf == null) {
                inf = new ProfileInfo(getTime());
                groupMap.put(label, inf);
            } else {
                inf.lastTimeStart = getTime();
            }
        }
    }

    @Override
    public void end(String label) {
        end(label, def);
    }

    @Override
    public void end(String label, int num) {
        end(label, num + "");
    }

    @Override
    public void end(String label, String group) {
        if (!dontwork) {
            Long curTime = getTime();
            HashMap<String, ProfileInfo> groupMap = info.get(group);
            if (groupMap == null) {
                System.out.println("WRONG USAGE : NO GROUP EXISTS" + group);
            }
            ProfileInfo inf = groupMap.get(label);
            if (inf == null) {
                System.out.println("WRONG USAGE : NO STARTING INVOCATION FOR LABEL " + label);
            } else {
                Long differAnce = curTime - inf.lastTimeStart;
                //    System.out.println(differAnce);
                inf.allTimesDone++;
                inf.allTimeSpent += differAnce;
            }
        }
    }

    @Override
    public String getInfo(String label) {
        return getInfo(label,def);
    }

    @Override
    public String getInfo(String label, String group) {
        if (!dontwork) {
            StringBuilder sb = new StringBuilder("");
            HashMap<String, ProfileInfo> curInfo = info.get(group);

            sb.append(getInfo(label, curInfo));

            return sb.toString();
        }
        return "";
    }

    private String getInfo(String label, HashMap<String, ProfileInfo> curInfo) {
        if (!dontwork) {
            ProfileInfo inf = curInfo.get(label);
            StringBuffer sb = new StringBuffer("    ");
            sb.append(label).append(" : ").append((double) inf.allTimeSpent / 1000000000).append("").append(" s, ").append(inf.allTimesDone).append(" times. Per one=")
                    .append((double) inf.allTimeSpent / (inf.allTimesDone * 1000000000)).append(" s");
            return sb.toString();
        }
        return "";
    }

    @Override
    public String getInfo() {
        if (!dontwork) {
            StringBuffer sb = new StringBuffer("");
            TreeSet<String> ts = new TreeSet(info.keySet());
            for (String s : ts) {
                sb.append(s).append(":\r\n");
                HashMap<String, ProfileInfo> curInfo = info.get(s);
                TreeSet<String> tz = new TreeSet(curInfo.keySet());
                for (String s1 : tz) {
                    sb.append(getInfo(s1, curInfo)).append("\r\n");
                }
            }
            return sb.toString();
        }
        return "";
    }

    class ProfileInfo {
        public Long lastTimeStart;

        public Long allTimeSpent = 0l;
        public Long allTimesDone = 0l;

        ProfileInfo(Long lastTimeStart) {
            this.lastTimeStart = lastTimeStart;
        }
    }
}
