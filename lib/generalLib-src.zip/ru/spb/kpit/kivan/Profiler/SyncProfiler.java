package ru.spb.kpit.kivan.Profiler;

import java.util.concurrent.locks.ReentrantLock;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 01.09.13
 * Time: 0:12
 * To change this template use File | Settings | File Templates.
 */
public class SyncProfiler implements Profiler {
    PlainProfiler profiler = new PlainProfiler();
    ReentrantLock lock = new ReentrantLock();

    @Override
    public Long getTime() {
        return System.nanoTime();
    }

    @Override
    public void start(String label) {
        lock.lock();
        try {
            profiler.start(label);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void start(String label, int num) {
        lock.lock();
        try {
            profiler.start(label,num);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void start(String label, String group) {
        lock.lock();
        try {
            profiler.start(label,group);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void end(String label) {
        lock.lock();
        try {
            profiler.end(label);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void end(String label, int num) {
        lock.lock();
        try {
            profiler.end(label,num);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void end(String label, String group) {
        lock.lock();
        try {
            profiler.end(label,group);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public String getInfo(String label) {
        lock.lock();
        String toRet;
        try {
            toRet = profiler.getInfo(label);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public String getInfo(String label, String group) {
        lock.lock();
        String toRet;
        try {
            toRet = profiler.getInfo(label,group);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public String getInfo() {
        lock.lock();
        String toRet;
        try {
            toRet = profiler.getInfo();
        } finally {
            lock.unlock();
        }
        return toRet;
    }
}
