package ru.spb.kpit.kivan.Profiler;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 01.09.13
 * Time: 0:11
 * To change this template use File | Settings | File Templates.
 */
public interface Profiler {
    Long getTime();

    void start(String label);

    void start(String label, int num);

    void start(String label, String group);

    void end(String label);

    void end(String label, int num);

    void end(String label, String group);

    String getInfo(String label);

    String getInfo(String label, String group);

    String getInfo();
}
