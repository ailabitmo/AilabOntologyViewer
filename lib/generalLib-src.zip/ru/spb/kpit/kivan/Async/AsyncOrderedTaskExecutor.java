package ru.spb.kpit.kivan.Async;

import java.util.*;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 01.06.2011
 * Time: 18:48:31
 * To change this template use File | Settings | File Templates.
 * <p/>
 * One timer-thread checks list and resolves runnables once per second... or once per period
 * Should be explicitly finished.
 * <p/>
 * For relatively simple tasks which should be executed in specified order. Not for async time consuming calculation
 * tasks.
 * <p/>
 * All tasks are executed in one thread .
 */
public class AsyncOrderedTaskExecutor {
    List<Runnable> tasks;
    ReentrantLock locker = new ReentrantLock();
    boolean isDaemon = true;
    Timer listChecker = new Timer("Executor", isDaemon);
    volatile String lockMsg;
    volatile boolean finished = false;


    public AsyncOrderedTaskExecutor(long period) {
        tasks = new ArrayList<Runnable>();
        listChecker.schedule(new ExecutorTimerTask(false), period, period);
        Runtime.getRuntime().addShutdownHook(new Thread(
                new Runnable() {
                    public void run() {
                        System.out.println("Shutdown hook started for "+AsyncOrderedTaskExecutor.this);
                        finish();
                        System.out.println("Shutdown hook finished for"+AsyncOrderedTaskExecutor.this);
                    }
                }
        ));
    }

    public AsyncOrderedTaskExecutor() {
        this(1000);
    }

    /**
     * @deprecated daemon ������ �� ������������ - �� ������ ������ ������ � ����� � ������� ����� ��� ��������
     * @param isDaemon
     */
    public AsyncOrderedTaskExecutor(boolean isDaemon) {
        this();
        listChecker = new Timer("Executor",isDaemon);
    }

    /**
     * @deprecated daemon ������ �� ������������ - �� ������ ������ ������ � ����� � ������� ����� ��� ��������
     * @param period
     * @param isDaemon
     */
    public AsyncOrderedTaskExecutor(long period, boolean isDaemon) {
        this(period);
        listChecker = new Timer("Executor",isDaemon);
    }

    private class ExecutorTimerTask extends TimerTask {

        boolean finisher;

        private ExecutorTimerTask(boolean finisher) {
            this.finisher = finisher;
        }


        public void run() {

            if (finisher) {

                while (tasks.size() > 0) {
                    Runnable task = tasks.get(0);
                    tasks.remove(task);
                    lockMsg += task.getClass().getName() + ",";
                    try {
                        task.run();
                    } catch (Exception e) {
                        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                    }
                }

                finished = true;

            } else {
                try {
                    lock("Starting executing querry:");
                    if (!finished) {
                        while (tasks.size() > 0) {
                            Runnable task = tasks.get(0);
                            tasks.remove(task);
                            lockMsg += task.getClass().getName() + ",";
                            try {
                                task.run();
                            } catch (Exception e) {
                                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                            }
                        }
                    }
                } finally {
                    unlock();
                }
            }
        }
    }

    public void finish() {
        if (!finished) {
            try {
                lock("Starting executing querry:");
                listChecker.cancel();
                new ExecutorTimerTask(true).run();
                finished = true;
            } finally {
                unlock();
            }
        }
    }

    public boolean finished() {
        return finished;
    }

    public void addTask(Runnable task) {
        try {
            lock("Adding Task:");
            tasks.add(task);
        } finally {
            unlock();
        }
    }

    public void lock(String msg) {
        locker.lock();
        lockMsg = msg;
    }

    public void unlock() {
        locker.unlock();
        lockMsg = "";
    }
}
