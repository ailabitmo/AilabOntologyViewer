package ru.spb.kpit.kivan.Async;

import java.util.*;
import java.util.concurrent.*;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 02.06.12
 * Time: 12:30
 * To change this template use File | Settings | File Templates.
 */
public class AsyncMultiTaskExecutor<V> {

    boolean startWhenFirstCommited;
    Map<String,FutureTask<V>> tasks = new HashMap<String, FutureTask<V>>();
    final ExecutorService es;
    long timeSleep;

    public AsyncMultiTaskExecutor(boolean startWhenFirstCommited) {
        this.startWhenFirstCommited = startWhenFirstCommited;
        es = Executors.newFixedThreadPool(4);
        timeSleep = 100;
    }

    public AsyncMultiTaskExecutor(boolean startWhenFirstCommited, long timeSleep, int numOfThreads) {
        this.startWhenFirstCommited = startWhenFirstCommited;
        es = Executors.newFixedThreadPool(numOfThreads);
        this.timeSleep = timeSleep;
    }

    public void commitTask(String id, Callable<V> task){
        FutureTask<V> ttask = new FutureTask<V>(task);
        tasks.put(id, ttask);
        if(startWhenFirstCommited){
            es.submit(task);
        }
    }

    private static long taskId = 0;
    public void commitTask(Callable<V> task){
        FutureTask<V> ttask = new FutureTask<V>(task);
        tasks.put(taskId+++"", ttask);
        if(startWhenFirstCommited){
            es.submit(task);
        }
    }

    public AsyncMultiTaskExecutor start(){
        if(!startWhenFirstCommited){
            for (FutureTask<V> vFutureTask : tasks.values()) {
                es.submit(vFutureTask);
            }
        }
        return this;
    }

    volatile boolean finished = false;
    public void waitUntilFinished(){
        do {
            boolean finish = true;
            for (FutureTask task : tasks.values()) {
                if (!task.isDone()) {
                    finish = false;
                    break;
                }
            }
            finished = finish;
            try {
                if (finished == false) Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        } while (!finished);
    }

    public V getResult(String taskId){
        if(finished){
            try {
                return tasks.get(taskId).get();
            } catch (InterruptedException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            } catch (ExecutionException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }
        return null;
    }

    public Collection<FutureTask<V>> getTasks(){
        Collection<FutureTask<V>> toRet = new ArrayList<FutureTask<V>>();
        List<String> keys = new ArrayList<String>(tasks.keySet());
        Collections.sort(keys);
        for (String key : keys) {
            toRet.add(tasks.get(key));
        }
        return toRet;
    }


}
