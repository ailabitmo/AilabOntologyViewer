package ru.spb.kpit.kivan.Parser;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 17.03.13
 * Time: 19:09
 * To change this template use File | Settings | File Templates.
 */
public interface MyStemMineStrategy<T extends WordInfo> {
    public String myStemOptions();
    public List<T> processStemedFile(String filePath);
}
