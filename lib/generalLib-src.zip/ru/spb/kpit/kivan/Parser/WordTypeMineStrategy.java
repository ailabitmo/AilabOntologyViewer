package ru.spb.kpit.kivan.Parser;

import ru.spb.kpit.kivan.General.Strings.StringUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 17.03.13
 * Time: 19:12
 * To change this template use File | Settings | File Templates.
 */
public class WordTypeMineStrategy implements MyStemMineStrategy<WordInfo> {
    HashSet<WType> wTypes;

    public WordTypeMineStrategy(HashSet<WType> wordTypes) {
        this.wTypes = wordTypes;
        if (wTypes == null) wTypes = new HashSet<WType>();
    }

    public WordTypeMineStrategy(WType... wordTypes) {
        wTypes = new HashSet<WType>();
        for (WType wordType : wordTypes) {
            wTypes.add(wordType);
        }
    }

    public String myStemOptions() {
        return "ni";
    }

    public List<WordInfo> processStemedFile(String filePath) {
        Scanner sc = null;
        //List<String> words = new ArrayList<String>();
        List<WordInfo> finalResults = new ArrayList<WordInfo>();

        try {
            sc = new Scanner(new File(filePath));
            while (sc.hasNextLine()) {
                String newLine = sc.nextLine();
                String oldWord = newLine.substring(0, newLine.indexOf("{"));

                /*if(oldWord.startsWith("�����")){
                    int k = 0;
                }*/

                String line = newLine.substring(newLine.indexOf("{") + 1, newLine.indexOf("}"));

                String parsedWord = "";
                HashSet<String> types = new HashSet<String>();
                if (line.contains("??")) {
                    /*continue;*/
                    int k = 0;
                    parsedWord = line;
                    types.add("UNK");
                } else {
                    parsedWord = line.substring(0, line.indexOf("="));
                    int zpja = line.indexOf(",");
                    int ravno = line.indexOf("=", line.indexOf("=") + 1);
                    int index = -1;
                    if (zpja == -1 && ravno == -1) index = line.length() - 1;
                    else if (zpja == -1) index = ravno;
                    else if (ravno == -1) index = zpja;
                    else index = Math.min(zpja, ravno);
                    String type = line.substring(line.indexOf("=") + 1, index);
                    boolean checkType = checkType(type);
                    if (!checkType) continue;

                    types.add(type);
                    String thisType = type;

                    int pointer = -1;
                    while (line.indexOf("|", pointer) > -1) {
                        int newIndex = line.indexOf("|", pointer + 1);

                        zpja = line.indexOf(",", newIndex);
                        ravno = line.indexOf("=", line.indexOf("=", newIndex) + 1);
                        index = -1;
                        if (zpja == -1 && ravno == -1) index = line.length() - 1;
                        else if (zpja == -1) index = ravno;
                        else if (ravno == -1) index = zpja;
                        else index = Math.min(zpja, ravno);
                        type = line.substring(line.indexOf("=", newIndex) + 1, index);
                        pointer = newIndex + 1;
                        types.add(type);
                    }
                }
                parsedWord = parsedWord.replace("?", "");
                if (parsedWord.length() > 0)
                    finalResults.add(new WordInfo(oldWord, parsedWord, StringUtils.gStrFrColEls(types, "+")));
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } finally {
            sc.close();
        }
        return finalResults;
    }

    private boolean checkType(String type) {
        if (type == null) return false;
        if (wTypes.size() == 0) return true;
        for (WType wType : wTypes) {
            if (wType.getMstVal().equalsIgnoreCase(type)) return true;
        }
        return false;
    }
}
