package ru.spb.kpit.kivan.Parser;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 08.09.13
 * Time: 23:35
 * To change this template use File | Settings | File Templates.
 */
public class ConcatStrProcAll extends ConcatStrProcStrategy {
    public ConcatStrProcAll(int minWordSize) {
        super(minWordSize);
    }

    @Override
    public void processWords(List<WordInfo> words) {
        try {
            rwl.writeLock().lock();
            StringBuilder sb = new StringBuilder();
            for (WordInfo word : words) {
                if (word.getParsedWord().length() >= minWordSize)
                    sb.append(word.getInitWord()).append("_(").append(word.getParsedWord()).append(")_{").append(word.getType()).append("} ");
            }
            result = sb.toString().trim();
        } finally {
            rwl.writeLock().unlock();
        }
    }
}
