package ru.spb.kpit.kivan.Parser;

import ru.spb.kpit.kivan.Config.SSConfig;
import ru.spb.kpit.kivan.General.DataStructures.HMList;
import ru.spb.kpit.kivan.General.FileSystem.FileFolderUtils;
import ru.spb.kpit.kivan.General.Strings.StringUtils;
import ru.spb.kpit.kivan.General.UniqueIdGenerator;
import ru.spb.kpit.kivan.Logger_2_0.Logger;
import ru.spb.kpit.kivan.Randomizer.Pair;
import ru.spb.kpit.kivan.XML.XMLGenerator.Node;
import ru.spb.kpit.kivan.XML.XMLSerializer.Xml2ObjConverter;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.text.MessageFormat;
import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 17.03.13
 * Time: 12:59
 * To change this template use File | Settings | File Templates.
 */
public class Stemer {
    private static Map<String, Pair<String, String>> stemCache;
    private static String stemCacheFile = null;
    private static Lock stemCacheLock = new ReentrantLock();
    private static long overallRequests = 0;
    private static long successfullRequests = 0;
    private static Timer cachSave = new Timer(true);

    public static boolean cacheContains(String key) {
        try {
            stemCacheLock.lock();
            initStemCache();
            boolean pairs = stemCache.containsKey(key);
            return pairs;
        } finally {
            stemCacheLock.unlock();
        }
    }

    public static Pair<String, String> getFromStemCache(String key) {
        Pair<String, String> pairs;
        try {
            stemCacheLock.lock();
            initStemCache();
            overallRequests++;
            pairs = stemCache.get(key);
            if (pairs != null) successfullRequests++;
            if (overallRequests % 1000 == 0)
                Logger.l2o.debug(MessageFormat.format("    Stemmer cache STATS:( {0} )/( {1} )", successfullRequests, overallRequests));
        } finally {
            stemCacheLock.unlock();
        }
        return pairs;
    }

    public static void addAllToStemCache(HashMap<String, Pair<String, String>> val) {
        try {
            stemCacheLock.lock();
            initStemCache();
            stemCache.putAll(val);
            Logger.l2o.debug(MessageFormat.format("    Stemmer cache ADDED: ( {0} ) = [{1}]", val.size(), StringUtils.gStrFrMapEls(val)));
            Logger.l2o.debug(MessageFormat.format("    Stemmer cache NOW:  {0} ", stemCache.size()));
        } finally {
            stemCacheLock.unlock();
        }
    }

    private static void initStemCache() {
        if (stemCache == null) {
            File stemCacheF = new File(stemCacheFile);
            if (!stemCacheF.exists())
                stemCache = new HashMap<String, Pair<String, String>>();
            else {
                Logger.l2o.debug("Starting stemCache restore");
                stemCache = (Map) Xml2ObjConverter.restoreObject(stemCacheF);
                Logger.l2o.debug("Finished stemCache restore");
                cachSave.schedule(new TimerTask() {
                    public void run() {
                        try {
                            stemCacheLock.lock();
                            Logger.l2o.debug("Save stemCache by timer...");
                            saveStemCache();
                        }
                        finally {
                            Logger.l2o.debug("...Save stemCache by timer finished!");
                            stemCacheLock.unlock();
                        }
                    }
                }, 60 * 1000, 60 * 1000);
            }
        }
    }

    public static void saveStemCache() {
        if (stemCache != null) {
            Logger.l2o.debug("Starting stemCache save");
            Node xmlStruct = Xml2ObjConverter.convertObject(stemCache, "StemCache");
            FileFolderUtils.writeToFile(stemCacheFile, xmlStruct.getXML());
            Logger.l2o.debug("Finished stemCache save");
        }
    }

    MSTParser parser;

    public Stemer() {
        SSConfig.init("config.properties", "");//If not initited
        if (stemCacheFile == null){
            stemCacheFile = SSConfig.provide().gS("stemCacheFile");
        }
        parser = new MSTParser<WordInfoProcStrategy>(
                SSConfig.provide().gS("myStemPath") + "\\" + SSConfig.provide().gS("myStemExe"),
                SSConfig.provide().gS("myStemPath") + "\\" + SSConfig.provide().gS("myStemIN") + "_" + UniqueIdGenerator.nextId() + ".txt",
                SSConfig.provide().gS("myStemPath") + "\\" + SSConfig.provide().gS("myStemOUT") + "_" + UniqueIdGenerator.nextId() + ".txt",
                new WordTypeMineStrategy(), new WordInfoProcStrategy()
        );
    }

    public String stemText(String text) {
        text = text.toLowerCase();
        StringTokenizer st = new StringTokenizer(text);
        List<WordInfo> wordList = new ArrayList<WordInfo>();
        HMList<String, List<WordInfo>> unknownWordsCache = new HMList<String, List<WordInfo>>();
        HashMap<String, Pair<String, String>> addToCache = new HashMap<String, Pair<String, String>>();

        StringBuilder toStem = new StringBuilder("");
        while (st.hasMoreTokens()) {
            String word = st.nextToken().trim();
            word = StringUtils.leaveOnlyLetters(word);
            Pair<String, String> wordInfo = getFromStemCache(word);
            if (wordInfo != null) wordList.add(new WordInfo(word, wordInfo.a, wordInfo.b));
            else if (wordInfo == null && cacheContains(word)) wordList.add(new WordInfo(word, null, null));
            else {
                if (word != null && !"".equals(word)) {
                    WordInfo wi = new WordInfo(word, null, null);
                    wordList.add(wi);
                    unknownWordsCache.getCollectionOrCreateIt(word).add(wi);
                    toStem.append(word).append(" ");
                }
            }
        }

        if (!"".equals(toStem.toString())) {
            WordInfoProcStrategy result = (WordInfoProcStrategy) parser.processByMystem(toStem.toString().toLowerCase());
            for (WordInfo wordInfo : result.getWords()) {
                if (unknownWordsCache.containsKey(wordInfo.getInitWord())) {
                    List<WordInfo> wiii = unknownWordsCache.get(wordInfo.getInitWord());
                    for (WordInfo info : wiii) {
                        info.setParsedWord(wordInfo.getParsedWord());
                        info.setType(wordInfo.getType());
                    }
                    unknownWordsCache.remove(wordInfo.getInitWord());
                }
                addToCache.put(wordInfo.getInitWord(), new Pair<String, String>(wordInfo.getParsedWord(), wordInfo.getType()));
            }
        }

        for (String s : unknownWordsCache.keySet()) {
            addToCache.put(s, null);
        }

        if (addToCache.size() > 0) addAllToStemCache(addToCache);

        StringBuilder sb = new StringBuilder();
        for (WordInfo wordInfo : wordList) {
            String type = (wordInfo.getParsedWord() == null) ? "UNK" : wordInfo.getType();
            sb.append(wordInfo.getParsedWord()).append("__T:").append(type).append(" ");
        }
        String toRet = null;
        try {
            toRet = new String(sb.toString().trim().getBytes("UTF-8"), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        return toRet;
    }
}
