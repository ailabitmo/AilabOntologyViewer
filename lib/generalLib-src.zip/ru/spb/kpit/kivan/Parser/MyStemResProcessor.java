package ru.spb.kpit.kivan.Parser;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 17.03.13
 * Time: 19:31
 * To change this template use File | Settings | File Templates.
 */
public interface MyStemResProcessor <T extends WordInfo> {
    void processWords(List<T> words);
}
