package ru.spb.kpit.kivan.Parser;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 15.03.13
 * Time: 21:29
 * To change this template use File | Settings | File Templates.
 */
public class Text {
    String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Text(String text) {
        this.text = text;
    }
}
