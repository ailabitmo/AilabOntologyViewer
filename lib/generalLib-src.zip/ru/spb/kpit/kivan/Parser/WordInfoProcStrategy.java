package ru.spb.kpit.kivan.Parser;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 17.03.13
 * Time: 22:55
 * To change this template use File | Settings | File Templates.
 */
public class WordInfoProcStrategy implements MyStemResProcessor<WordInfo> {
    List<WordInfo> words;

    public List<WordInfo> getWords() {
        return words;
    }
    public void processWords(List<WordInfo> words) {
        this.words = words;
    }
}
