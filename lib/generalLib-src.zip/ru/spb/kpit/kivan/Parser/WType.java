package ru.spb.kpit.kivan.Parser;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 17.03.13
 * Time: 19:13
 * To change this template use File | Settings | File Templates.
 */
public enum WType {
    PRILAG("A"),
    NARE4("ADV"),
    MESTOIM_NARE4("ADVPRO"),
    PORJADK_CHISLIT("ANUM"),
    MESTOIM_PRILAG("APRO"),
    SOYZ("CONJ"),
    MEZDOMETIE("INTJ"),
    CHISLIT("NUM"),
    CHASTICA("PART"),
    PREDLOG("PR"),
    SUWESTVIT("S"),
    MESTOIMENIE("SPRO"),
    GLAGOL("V");

    String mstVal;

    public String getMstVal() {
        return mstVal;
    }

    WType(String a) {
        mstVal = a;
    }
}
