package ru.spb.kpit.kivan.Parser;

import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 17.03.13
 * Time: 19:33
 * To change this template use File | Settings | File Templates.
 */
public class ConcatStrProcStrategy implements MyStemResProcessor<WordInfo> {
    String result = "";
    ReadWriteLock rwl = new ReentrantReadWriteLock();
    int minWordSize;

    public ConcatStrProcStrategy(int minWordSize) {
        this.minWordSize = minWordSize;
    }

    public void processWords(List<WordInfo> words) {
        try {
            rwl.writeLock().lock();
            StringBuilder sb = new StringBuilder();
            for (WordInfo word : words) {
                if (word.getParsedWord().length() >= minWordSize)
                    sb.append(word.getParsedWord()).append(" ");
            }
            result = sb.toString().trim();
        } finally {
            rwl.writeLock().unlock();
        }

    }

    public String getResultingString() {
        try {
            rwl.readLock().lock();
            return result;
        } finally {
            rwl.readLock().unlock();
        }
    }
}
