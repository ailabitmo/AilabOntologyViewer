package ru.spb.kpit.kivan.Parser;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 15.03.13
 * Time: 20:56
 * To change this template use File | Settings | File Templates.
 */
public class StemedText extends Text {
    String stemedText;

    public String getStemedText() {
        return stemedText;
    }

    public void setStemedText(String stemedText) {
        this.stemedText = stemedText;
    }

    public StemedText(String text) {
        super(text);

        Stemer stem = new Stemer();
        this.stemedText = stem.stemText(text);
    }
}
