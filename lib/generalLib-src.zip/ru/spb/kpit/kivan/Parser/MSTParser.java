package ru.spb.kpit.kivan.Parser;

import ru.spb.kpit.kivan.General.FileSystem.FileFolderUtils;

import java.io.File;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 17.03.13
 * Time: 19:03
 * To change this template use File | Settings | File Templates.
 */
public class MSTParser<T extends MyStemResProcessor> {

    static volatile String mystemPath = "mystem.exe";

    public static String getMystemPath() {
        return mystemPath;
    }

    public static void setMystemPath(String mystemPath) {
        MSTParser.mystemPath = mystemPath;
    }

    String pathToMystem;
    String pathToTempInput = "mstm_temp_input.txt";
    String pathToTempOuput = "mstm_temp_input.txt";
    MyStemMineStrategy mineStrategy = new WordTypeMineStrategy();
    T processStrategy = (T) new ConcatStrProcStrategy(1);

    public MSTParser() {
        pathToMystem = getMystemPath();
    }

    public MSTParser(String pathToMystem) {
        this.pathToMystem = pathToMystem;
    }

    public MSTParser(MyStemMineStrategy minestrategy, T procStrategy) {
        this();
        this.mineStrategy = minestrategy;
        this.processStrategy = procStrategy;
    }

    public MSTParser(String pathToMystem, MyStemMineStrategy mineStrategy, T processStrategy) {
        this.pathToMystem = pathToMystem;
        this.mineStrategy = mineStrategy;
        this.processStrategy = processStrategy;
    }

    public MSTParser(String pathToMystem, String pathToTempInput, String pathToTempOuput) {
        this.pathToMystem = pathToMystem;
        this.pathToTempInput = pathToTempInput;
        this.pathToTempOuput = pathToTempOuput;
    }

    public MSTParser(String pathToMystem, String pathToTempInput, String pathToTempOuput,
                     MyStemMineStrategy minestrategy, T procStrategy) {
        this.pathToMystem = pathToMystem;
        this.pathToTempInput = pathToTempInput;
        this.pathToTempOuput = pathToTempOuput;
        this.mineStrategy = minestrategy;
        this.processStrategy = procStrategy;
    }

    public T processByMystem(String textToProcess) {
        String pathToMystem = this.pathToMystem;
        String pathToTempInput = this.pathToTempInput;
        String pathToTempOutput = this.pathToTempOuput;
        try {
            // 1.
            FileFolderUtils.writeToFile(pathToTempInput, textToProcess,"windows-1251");

            //2.
            String cmd = "\"" + pathToMystem + "\" -" + mineStrategy.myStemOptions() + " " + pathToTempInput + " " + pathToTempOutput;
            FileFolderUtils.executeCMDComand(cmd);

            //3
            List<WordInfo> parsed = mineStrategy.processStemedFile(pathToTempOutput);
            processStrategy.processWords(parsed);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                FileFolderUtils.recursiveDelete(new File(pathToTempInput));
                FileFolderUtils.recursiveDelete(new File(pathToTempOutput));
            } catch (Exception e) {
            }
        }
        return processStrategy;
    }
}
