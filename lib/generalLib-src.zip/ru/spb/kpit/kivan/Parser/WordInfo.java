package ru.spb.kpit.kivan.Parser;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 17.03.13
 * Time: 19:27
 * To change this template use File | Settings | File Templates.
 */
public class WordInfo {
    String initWord;
    String parsedWord;
    String type;

    public WordInfo(String initWord, String parsedWord, String type) {
        this.initWord = initWord;
        this.parsedWord = parsedWord;
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getInitWord() {
        return initWord;
    }

    public void setInitWord(String initWord) {
        this.initWord = initWord;
    }

    public String getParsedWord() {
        return parsedWord;
    }

    public void setParsedWord(String parsedWord) {
        this.parsedWord = parsedWord;
    }
}
