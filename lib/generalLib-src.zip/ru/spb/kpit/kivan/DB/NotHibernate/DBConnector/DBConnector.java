package ru.spb.kpit.kivan.DB.NotHibernate.DBConnector;

import java.sql.*;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 17.04.2011
 * Time: 12:04:49
 * To change this template use File | Settings | File Templates.
 */
public class DBConnector {
    Connection con = null;
    String driver;
    //Without schema and login pas. Like this: "jdbc:mysql://localhost:3306/"
    String connectionString;

    String schema;
    String username;
    String pas;

    public static void closePrepStatement(PreparedStatement ps) {
        try {
            if(ps!=null)
            ps.close();
        } catch (Exception e) {
        }
    }

    public static void closeResSet(ResultSet rs) {
        try {
            if(rs!=null)
            rs.close();
        } catch (Exception e) {
        }
    }

    public DBConnector(String driver, String connectionString, String schema, String username, String pas) {
        this.driver = driver;
        this.connectionString = connectionString;
        this.schema = schema;
        this.username = username;
        this.pas = pas;
    }

    public Connection getCon() {
        if (con == null) createConnection();
        return con;
    }

    public void closeConnection() {
        try {
            con.close();
            con = null;
        } catch (SQLException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    private void createConnection() {
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(
                    connectionString+schema,
                    username,
                    pas);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
