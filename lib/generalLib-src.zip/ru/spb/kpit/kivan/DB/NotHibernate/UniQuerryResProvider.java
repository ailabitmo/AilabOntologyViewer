package ru.spb.kpit.kivan.DB.NotHibernate;


import ru.spb.kpit.kivan.DB.NotHibernate.DBConnector.DBConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 17.04.2011
 * Time: 12:01:42
 * To change this template use File | Settings | File Templates.
 */
public class UniQuerryResProvider {

    public final static String emptyFieldSign = "0";

    String querry;
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    /**
     * @param querry - ������
     *               �� ���� �������������� ����� ����� � ������. ����� - ������ ��������, ������ - �������� ��������.
     *               ����� next() ����� �������� �� � ������������ � ���� �������� - �� ���� ������� ������� ��� �� ����������
     *               ��, ��� �� �������.
     */
    public UniQuerryResProvider(String querry, Connection con) {
        this.querry = querry;
        this.con = con;
        try {
            ps = con.prepareStatement(querry);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public void closeAll() {
        DBConnector.closeResSet(rs);
        DBConnector.closePrepStatement(ps);
    }

    public static void closeUQRP(UniQuerryResProvider uqrp){
        if(uqrp!=null){
            try {
                uqrp.closeAll();
            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            } finally {

            }
        }
    }

    public boolean hasNext() {
        try {
            if (rs.isLast()) {
                closeAll();
                return false;
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean next() {
        try {
            boolean next = rs.next();
            if (!next) {
                closeAll();
            }
            return next;
        } catch (SQLException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return false;
    }

    public String getValueForField(String field) {
        try {
            String res = rs.getString(field);
            if (res == null) return null;
            else return res;
        } catch (SQLException e) {
            System.out.println(field);
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }

    /**
     * 0 - ������
     *
     * @param fieldNum
     * @return
     */
    public String getValueForField(int fieldNum) {
        try {
            String res = rs.getString(fieldNum + 1);
            if (res == null) return null;
            else return res;
        } catch (SQLException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }

    public void toBegin() {
        try {
            closeAll();
            ps = con.prepareStatement(querry);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public void remove() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public ResultSet getRs() {
        return rs;
    }


}
