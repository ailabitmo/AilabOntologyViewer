package ru.spb.kpit.kivan.Mathematic.KernelMethods;

import ru.spb.kpit.kivan.Mathematic.Integration.NormalDistrib;
import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Function;
import ru.spb.kpit.kivan.Randomizer.Pair;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 10.09.12
 * Time: 17:07
 * To change this template use File | Settings | File Templates.
 */
public class Kernel1dFunctionRegression {

    final static double msq5 = Math.sqrt(5);
    final static double other = 3 / (4 * msq5);
    final static double last = 1 / 5;
    Function kernel = new Function() {

        public void regress(double[][] data) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public double calcValue(double... X) {
            double x = X[0];
            /*if (x > -msq5 && x < msq5) return other * (1 - last * x * x);*/
            NormalDistrib nd = new NormalDistrib(0,h);
            return nd.evaluate(x);
            //return 0;
        }
    };
    List<Pair<Double,Double>> data;
    double h;

    double minX = Double.MAX_VALUE;
    double maxX = -Double.MAX_VALUE;

    public Kernel1dFunctionRegression(double h, List<Pair<Double, Double>> dt) {
        this.h = h;
        this.data = dt;
        for (Pair<Double, Double> data : dt) {
            minX = (data.a<minX)?data.a:minX;
            maxX = (data.a>maxX)?data.a:maxX;
        }
    }


    public Kernel1dFunctionRegression(List<Pair<Double, Double>> dt) {
        this.data = dt;
        for (Pair<Double, Double> data : dt) {
            minX = (data.a<minX)?data.a:minX;
            maxX = (data.a>maxX)?data.a:maxX;
        }

        this.h = (maxX - minX)/50;
    }

    public double regressionValue(double x){
        double upperSum = 0;
        double lowerSum = 0;

        int n = data.size();
        for (int i = 0; i < n; i++) {
            double yi = data.get(i).b;
            double xi = data.get(i).a;
            double kernVal = kernel.calcValue((xi - x));

            upperSum += kernVal*yi;
            lowerSum += kernVal;
        }

        return upperSum/lowerSum;
        //return firstCoef*upperSum;
    }

    public Function getFunc(){
        return new Function() {
            @Override
            public void regress(double[][] data) {
                //To change body of implemented methods use File | Settings | File Templates.
            }

            @Override
            public double calcValue(double... X) {
                return regressionValue(X[0]);
            }
        };
    }

    public double getMaxX() {
        return maxX;
    }

    public double getMinX() {
        return minX;
    }
}
