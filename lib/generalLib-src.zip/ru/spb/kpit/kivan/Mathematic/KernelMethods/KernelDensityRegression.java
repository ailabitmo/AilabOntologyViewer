package ru.spb.kpit.kivan.Mathematic.KernelMethods;

import ru.spb.kpit.kivan.Mathematic.Integration.NormalDistrib;
import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Function;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 29.08.12
 * Time: 9:20
 * To change this template use File | Settings | File Templates.
 */
public class KernelDensityRegression {

    final static double msq5 = Math.sqrt(5);
    final static double other = 3 / (4 * msq5);
    final static double last = 1 / 5;

    double h;
    List<Double> data;
    Function kernel = new Function() {

        public void regress(double[][] data) {
        }

        public double calcValue(double... X) {
            double x = X[0];
            /*
            if (x > -msq5 && x < msq5) return other * (1 - last * x * x);
            return 0;*/

            NormalDistrib nd = new NormalDistrib(0,1);
            return nd.evaluate(x);
        }
    };

    public KernelDensityRegression(double h, List<Double> data) {
        this.h = h;
        this.data = data;
    }

    //10 seconds
    private static long timeToCalc = 10 * 1000;

    public KernelDensityRegression(List<Double> data) {
        this.data = data;
        this.h = calcHUsingEntropyCrossValidation(timeToCalc);
        System.out.println(this.h);
    }

    /**
     * @param data
     * @param timeToCalcH - ����� � �������� �� ������ "h"
     */
    public KernelDensityRegression(List<Double> data, double timeToCalcH) {
        this.data = data;
        KernelDensityRegression.timeToCalc = (long) (timeToCalcH* 1000);
        this.h = calcHUsingEntropyCrossValidation(KernelDensityRegression.timeToCalc);
        System.out.println(this.h);
    }

    /**
     * ������ ���: ������� 1 ������ �������.
     * ������� ������� ��� �� ����� ���� ��������� �� ���������.
     *
     * @param timeToCalc ������������ ����� ������ ��������� ������.
     * @return
     */
    private double calcHUsingEntropyCrossValidation(long timeToCalc) {
        /*//FitnessFunction ff = new FitnessFunction() {

            public double evaluate(double[] position) {
                double currentH = position[0];
                double entropy = calcEntrpopyForCurrentH(currentH);
                //System.out.println(currentH + " -> E: " + entropy);
                return entropy;
            }
        };*/

        long first = System.currentTimeMillis();
        //ff.evaluate(new double[]{0});
        long second = System.currentTimeMillis();
        long perOne = second - first;
        if(perOne == 0) perOne = 1;
        long numOfIters = timeToCalc / perOne;
        if(numOfIters<=0) numOfIters=1;
        int numOfParticles = 1;
        int numOfIterations = 1;
        //����� ������� ���� �� 3 ��������
        if (numOfIters <= 20) numOfParticles = 3;
        else if (numOfIters <= 50) numOfParticles = 10;
        else numOfParticles = 25;

        numOfIterations = (int) numOfIters / numOfParticles;
        if(numOfIterations<=0) numOfIterations = 1;

        System.out.println("Part: "+numOfParticles+ " Iters: "+numOfIterations);

      /*  Swarm swarm = new Swarm(numOfParticles, new MyParticle(), ff);
        swarm.setInertia(0.95);
        swarm.setMaxPosition(3);
        swarm.setMinPosition(0);
        swarm.setMaxMinVelocity(0.01);

        //for (int i = 0; i < numOfIterations; i++) {
            swarm.evolve();
        }*/

        return 0;//swarm.getParticle(swarm.getBestParticleIndex()).getBestPosition()[0];
    }

    private double calcEntrpopyForCurrentH(Double currentH) {
        Double entropy = 0d;
        for (int i = 0; i < data.size(); i++) {
            double dd = data.get(i);
            entropy += Math.log(f_i(i, dd, currentH));
        }
        return entropy;
    }

    private double f_i(int i, double x, Double currentH) {
        double first = 1 / (currentH * (data.size() - 1));

        double second = 0d;
        for (int j = 0; j < data.size(); j++) {
            if (i != j) {
                second += kernel.calcValue((data.get(j) - x) / currentH);
            }
        }
        return first * second;

    }

    public double density(double x) {
        int n = data.size();
        double firstCoef = 1 / (n * h);
        double secondCoef = 0;
        for (int i = 0; i < n; i++) {
            double kernVal = kernel.calcValue((data.get(i) - x) / h);
            secondCoef += kernVal;
        }
        return firstCoef * secondCoef;
    }

}
