package ru.spb.kpit.kivan.Mathematic.LeastSquareMethod;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 09.07.2011
 * Time: 13:36:03
 * To change this template use File | Settings | File Templates.
 */
public class Equation {
    double[] x;
    double y;

    public double[] getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public Equation(double[] x, double y) {
        this.x = new double[x.length];
        System.arraycopy(x, 0, this.x, 0, x.length);
        this.y = y;
    }
        
}
