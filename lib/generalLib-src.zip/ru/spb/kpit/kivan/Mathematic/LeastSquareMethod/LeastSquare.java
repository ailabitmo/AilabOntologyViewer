package ru.spb.kpit.kivan.Mathematic.LeastSquareMethod;

import ru.spb.kpit.kivan.General.DataStructures.SimpleArrayWrapers.ArrArrDouble;
import static ru.spb.kpit.kivan.Mathematic.MatrixOperations.*;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 10.07.2011
 * Time: 20:51:02
 * To change this template use File | Settings | File Templates.
 */
public class LeastSquare {
    public static double[] calculate(double[][] A){
        double[][] At = transponare(A);
        double[][] AtxA = multiply(At, A);

        ArrArrDouble AXfict = new ArrArrDouble();
        ArrArrDouble AX = new ArrArrDouble();
        ArrArrDouble Bfict = new ArrArrDouble();
        ArrArrDouble B = new ArrArrDouble();

        splitByColumns(AtxA, AtxA[0].length-1, AXfict, Bfict);
        splitByRows(AXfict.arr, AXfict.arr.length-1, AX, new ArrArrDouble());
        splitByRows(Bfict.arr, Bfict.arr.length-1, B, new ArrArrDouble());

        double[] res = Gauss.gauss(AX.arr, multByNum(-1,B.linearize()));
        return res;
    }

}
