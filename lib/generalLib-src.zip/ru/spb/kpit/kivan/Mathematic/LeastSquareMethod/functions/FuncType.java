package ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions;

import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Poly.*;
import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Trigonometric.Sinx;

import java.lang.reflect.InvocationTargetException;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 10.07.2011
 * Time: 22:23:30
 * To change this template use File | Settings | File Templates.
 */
public enum FuncType {
    sinx(Sinx.class),
    poly1_lin(Poly1_linear.class),
    poly2(Poly2.class),
    poly3(Poly3.class),
    poly25(Poly25.class),
    poly50(Poly50.class),
    ;

    Class type;

    FuncType(Class linearClass) {
        type = linearClass;
    }

    public Function getFunc(){
        try {
            return (Function) type.getConstructors()[0].newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (IllegalAccessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (InvocationTargetException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }
}
