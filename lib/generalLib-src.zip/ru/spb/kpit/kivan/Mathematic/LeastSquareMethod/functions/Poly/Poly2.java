package ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Poly;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 11.07.2011
 * Time: 15:26:02
 * To change this template use File | Settings | File Templates.
 */
public class Poly2 extends Poly{
    protected int getModelLevel() {
        return 2;
    }
}
