package ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Poly;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 11.07.2011
 * Time: 15:20:05
 * To change this template use File | Settings | File Templates.
 */
public class Poly3 extends Poly{
    protected int getModelLevel() {
        return 3;
    }
}
