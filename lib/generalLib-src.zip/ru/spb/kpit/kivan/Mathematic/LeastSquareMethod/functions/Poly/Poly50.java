package ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Poly;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 11.07.2011
 * Time: 16:09:44
 * To change this template use File | Settings | File Templates.
 */
public class Poly50 extends Poly{
    protected int getModelLevel() {

        return 35;

    }
}
