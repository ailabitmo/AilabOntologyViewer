package ru.spb.kpit.kivan.Mathematic.LeastSquareMethod;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 10.07.2011
 * Time: 20:41:13
 * To change this template use File | Settings | File Templates.
 */
public interface DataProvider<P> {
    public boolean hasNextDataElement();
    public P getNextDataElement();
}
