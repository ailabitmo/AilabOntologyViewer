package ru.spb.kpit.kivan.Mathematic.LeastSquareMethod;

import ru.spb.kpit.kivan.General.DataStructures.SimpleArrayWrapers.ArrArrDouble;
import ru.spb.kpit.kivan.General.DataStructures.SimpleArrayWrapers.ArrDouble;
import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Function;
import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.FuncType;

import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 09.07.2011
 * Time: 17:32:17
 * To change this template use File | Settings | File Templates.
 */
public class EquationSystem {
    ArrayList<Equation> equations = new ArrayList<Equation>();

    public List<Equation> getEquations() {
        return equations;
    }

    public EquationSystem(List<Equation> equations) {
        this.equations = new ArrayList<Equation>(equations);
    }

    public EquationSystem(Equation ... equations) {
        this.equations = new ArrayList<Equation>(Arrays.asList(equations));
    }

    public EquationSystem(DataProvider dp) {
        while(dp.hasNextDataElement()){
            Equation next = (Equation) dp.getNextDataElement();
            equations.add(next);
        }
    }

    public void provideDataForGauss(ArrArrDouble X, ArrDouble Y){
        if(X == null || Y == null) return;
        X.arr = new double[equations.size()][equations.get(0).x.length];
        Y.arr = new double[equations.size()];
        for(int i=0; i<equations.size(); i++){
            for(int j=0; j<equations.get(i).x.length; j++){
                X.arr[i][j] = equations.get(i).x[j];
            }
            Y.arr[i] =  equations.get(i).y;  
        }
        return;
    }

    public void add(Equation eq){
        equations.add(eq);
    }

    public Function regressFunction(FuncType ftype){

        double[][] toRet = new double[equations.size()][equations.get(0).x.length+1];
        for(int i=0; i<equations.size(); i++){
            for(int j=0; j<equations.get(i).x.length; j++){
                toRet[i][j] = equations.get(i).x[j];
            }
            toRet[i][equations.get(i).x.length] = -1*equations.get(i).y;
        }

        Function f = ftype.getFunc();
        f.regress(toRet);
        return f;
    }

    public static void main(String[] args) {
        Equation eq1 = new Equation(new double[]{30.25, 5.5, 1}, 100);
        Equation eq2 = new Equation(new double[]{9, 3, 1}, 50);
        Equation eq3 = new Equation(new double[]{49, 7, 1}, 50);

        EquationSystem es = new EquationSystem(eq1,eq2,eq3);
        Function f = es.regressFunction(FuncType.poly50);
        int i = 0;
    }
}
