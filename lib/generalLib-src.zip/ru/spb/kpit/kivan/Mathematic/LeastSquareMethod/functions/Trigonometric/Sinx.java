package ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Trigonometric;

import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Funcsion;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 10.07.2011
 * Time: 23:13:11
 * To change this template use File | Settings | File Templates.
 */
public class Sinx extends Funcsion{
    protected int getModelLevel() {
        return 1;
    }

    protected double transformX(double X, int mlvl) {
        return Math.sin(X);
    }
}
