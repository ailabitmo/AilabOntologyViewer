package ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Poly;

import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Funcsion;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 11.07.2011
 * Time: 15:29:30
 * To change this template use File | Settings | File Templates.
 */
public abstract class Poly extends Funcsion {
    protected double transformX(double X, int mlvl) {
        return Math.pow(X, getModelLevel() - mlvl);
    }
}
