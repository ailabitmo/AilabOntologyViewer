package ru.spb.kpit.kivan.Mathematic.Angle;

public class A {
    public static Angle Rad(double radians) {
        return new Angle(radians, false);
    }

    public static AngleSector Rad(double radians1, double radians2) {
        return new AngleSector(new Angle(radians1, false), new Angle(radians2, false));
    }

    public static Angle Grad(double graduses) {
        return new Angle(graduses, true);
    }

    public static AngleSector Grad(double grad1, double grad2)
    {
        return new AngleSector(new Angle(grad1, true), new Angle(grad2, true));
    }

    public static Angle Zero() {
        return Grad(0);
    }
}
