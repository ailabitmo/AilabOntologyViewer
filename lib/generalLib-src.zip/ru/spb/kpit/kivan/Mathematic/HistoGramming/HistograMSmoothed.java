package ru.spb.kpit.kivan.Mathematic.HistoGramming;

import ru.spb.kpit.kivan.Mathematic.KernelMethods.KernelDensityRegression;
import ru.spb.kpit.kivan.Randomizer.Pair;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 02.09.12
 * Time: 13:56
 * To change this template use File | Settings | File Templates.
 */
public class HistograMSmoothed extends HistograMM {
    /**
     * @param cloneable
     * @param numOfSmoothingBoxes - ��� ����� ��������� ����� �����������
     */
    public HistograMSmoothed(List<Double> cloneable, int numOfSmoothingBoxes, double numOfSmoothing) {
        KernelDensityRegression kdr;
        if (numOfSmoothing > 0)
            kdr = new KernelDensityRegression(numOfSmoothing, cloneable);
        else
            kdr = new KernelDensityRegression(cloneable, 60);

        List<Double> ldd = new ArrayList<Double>();
        for (Double aDouble : cloneable) {
            ldd.add(aDouble);
        }
        Collections.sort(ldd);

        if (numOfSmoothingBoxes < 1) numOfSmoothingBoxes = 1;

        double dif = Math.abs(ldd.get(0) - ldd.get(ldd.size() - 1));
        double partSize = dif / numOfSmoothingBoxes;
        double curPart = Math.min(ldd.get(0), ldd.get(ldd.size() - 1)) + partSize;
        HistogramBox curList = new HistogramBox(Math.min(ldd.get(0), ldd.get(ldd.size() - 1)), curPart);
        curList.setBoxHeight((int) (1000 * kdr.density(curList.rightBound - partSize / 2)));

        for (int i = 1; i < numOfSmoothingBoxes; i++) {
            add(curList);
            curList = new HistogramBox(curPart, curPart + partSize);
            curList.setBoxHeight((int) (1000 * kdr.density(curList.rightBound - partSize / 2)));
            curPart += partSize;
        }
        add(curList);

        double maxValue = 0;
        for (HistogramBox box : boxes) {
            maxValue += box.boxHeight;
        }

        for (HistogramBox box : boxes) {
            box.relativeHeight = (double) box.boxHeight / maxValue;
        }
    }

    @Override
    public List<Pair<Double, Double>> getForGraph() {
        if (boxes.size() == 0) return new ArrayList<Pair<Double, Double>>();
        List<Pair<Double, Double>> toRet = new ArrayList<Pair<Double, Double>>();
        double dif = Math.abs(boxes.get(0).leftBound - boxes.get(boxes.size() - 1).rightBound);
        dif = dif / 1000; // 1000 �����
        /*double maxValue = (double) Collections.max(boxes,new Comparator<HistogramBox>() {
            public int compare(HistogramBox o1, HistogramBox o2) {
                return o1.boxHeight.compareTo(o2.boxHeight);
            }
        }).boxHeight;*/

        int i = 0;
        double oldHeight = 0d;
        for (HistogramBox box : boxes) {
            if (box.relativeHeight > oldHeight || box.relativeHeight < oldHeight) {
                oldHeight = box.relativeHeight;
                toRet.add(new Pair<Double, Double>((double) i, (double) (box.relativeHeight)));
            }
            i++;
        }

        /*double cur = boxes.get(0).leftBound;
        while (cur <= boxes.get(boxes.size() - 1).rightBound) {
            toRet.add(new Pair<Double, Double>(cur, (double) (getHistoValue(cur))));
            cur += dif;
        }*/
        return toRet;
    }
}
