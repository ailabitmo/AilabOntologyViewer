package ru.spb.kpit.kivan.Mathematic.HistoGramming;

import ru.spb.kpit.kivan.General.DataStructures.HM;
import ru.spb.kpit.kivan.Randomizer.Pair;
import ru.spb.kpit.kivan.Randomizer.SSRand;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
* Created with IntelliJ IDEA.
* User: Kivan
* Date: 14.07.12
* Time: 15:49
* To change this template use File | Settings | File Templates.
*/
public class HistograMM {
    List<HistogramBox> boxes = new ArrayList<HistogramBox>();

    protected HistograMM() {
    }

    public HistograMM(List<Double> cloneable, int avgPointsInBOx) {
        if(cloneable.size()==0) return;
        avgPointsInBOx = cloneable.size()/avgPointsInBOx;
        if(avgPointsInBOx<1)avgPointsInBOx = 1;
        List<Double> ldd = new ArrayList<Double>();
        for (Double aDouble : cloneable) {
            ldd.add(aDouble);
        }
        Collections.sort(ldd);

        double dif = Math.abs(ldd.get(0) - ldd.get(ldd.size() - 1));
        double partSize = dif / avgPointsInBOx;
        double curPart = Math.min(ldd.get(0), ldd.get(ldd.size() - 1)) + partSize;
        HistogramBox curList = new HistogramBox(Math.min(ldd.get(0), ldd.get(ldd.size() - 1)), curPart);
        for (int i = 0; i < ldd.size(); i++) {
            double aDouble = ldd.get(i);
            if (aDouble <= curPart || boxes.size()==avgPointsInBOx-1) {
                curList.add(aDouble);
            } else {
                add(curList.calcProperies());
                curList = new HistogramBox(curPart, curPart + partSize);
                curPart += partSize;
                i--;
            }
        }
        add(curList.calcProperies());

        double maxValue = 0;
        for (HistogramBox box : boxes) {
            maxValue+=box.boxHeight;
        }

        for (HistogramBox box : boxes) {
            box.relativeHeight=(double)box.boxHeight/maxValue;
        }
    }

    /**
     * ��� ����������� � ������, � lst ���� - �������� � ��� ���. ��������� ��������, ����� ��������� �� ������� �������������
     * @param cloneable
     * @param avgPointsInBOx
     */
    public HistograMM( int avgPointsInBOx, List<Pair<Double, Double>> cloneable) {
        if(cloneable.size()==0) return;
        avgPointsInBOx = cloneable.size()/avgPointsInBOx;
        if(avgPointsInBOx<1)avgPointsInBOx = 1;
        List<Pair<Double, Double>> ldd = new ArrayList<Pair<Double, Double>>();
        for (Pair<Double, Double> doubleDoublePair : cloneable) {
            ldd.add(doubleDoublePair);
        }
        Collections.sort(ldd, new Comparator<Pair<Double, Double>>() {
            public int compare(Pair<Double, Double> o1, Pair<Double, Double> o2) {
                return o1.a.compareTo(o2.a);
            }
        });

        double dif = Math.abs(ldd.get(0).a - ldd.get(ldd.size() - 1).a);
        double partSize = dif / avgPointsInBOx;
        double curPart = Math.min(ldd.get(0).a, ldd.get(ldd.size() - 1).a) + partSize;
        TimedHistogramBox curList = new TimedHistogramBox(Math.min(ldd.get(0).a, ldd.get(ldd.size() - 1).a), curPart);

        for (int i = 0; i < ldd.size(); i++) {
            double aDouble = ldd.get(i).a;
            if (aDouble <= curPart || boxes.size()==avgPointsInBOx-1) {
                curList.add(aDouble, ldd.get(i).b);
            } else {
                add(curList.calcProperies());
                curList = new TimedHistogramBox(curPart, curPart + partSize);
                curPart += partSize;
                i--;
            }
        }
        add(curList.calcProperies());

        double maxValue = 0;
        for (HistogramBox box : boxes) {
            maxValue+=box.boxHeight;
        }

        for (HistogramBox box : boxes) {
            box.relativeHeight=(double)box.boxHeight/maxValue;
        }

    }


    public double generateValue(){
        if(boxes.size()==0) return 0;
        HM obj_percent = new HM();
        for (HistogramBox box : boxes) {
            obj_percent.add(box, box.boxHeight);
        }
        HistogramBox hb = (HistogramBox) SSRand.N_thrdSf().roll_objectUserDefined(obj_percent);
        return hb.randValue();
    }

    protected void add(HistogramBox histogramBox) {
        boxes.add(histogramBox);
    }

    public Double getHistoValue(Double val) {
        for (HistogramBox box : boxes) {
            if (box.leftBound <= val && val <= box.rightBound && !box.relativeHeight.equals(Double.NaN)) return box.relativeHeight;
        }
        return 0d;
    }

    public List<Pair<Double, Double>> getForGraph() {
        if(boxes.size()==0) return new ArrayList<Pair<Double, Double>>();
        List<Pair<Double, Double>> toRet = new ArrayList<Pair<Double, Double>>();
        double dif = Math.abs(boxes.get(0).leftBound - boxes.get(boxes.size() - 1).rightBound);
        dif = dif / 1000; // 1000 �����
        /*double maxValue = (double) Collections.max(boxes,new Comparator<HistogramBox>() {
            public int compare(HistogramBox o1, HistogramBox o2) {
                return o1.boxHeight.compareTo(o2.boxHeight);
            }
        }).boxHeight;*/

        if(dif<0.0000000000000001d) return new ArrayList<Pair<Double, Double>>();

        double cur = boxes.get(0).leftBound;
        while (cur <= boxes.get(boxes.size() - 1).rightBound) {
            toRet.add(new Pair<Double, Double>(cur, (double) (getHistoValue(cur))));
            cur += dif;
        }
        return toRet;

    }

    public double integrateProbability(double left, double right){
        if(boxes.size()==0) return 0;
        int i=0;
        HistogramBox hb = boxes.get(i++);
        double toRet = 0d;
        //���� ����� �������
        while (hb.leftBound<left && i<boxes.size()) hb = boxes.get(i++);

        while (hb.rightBound<right && i<boxes.size()){
            toRet+=hb.relativeHeight;
            hb = boxes.get(i++);
        }

        return toRet;
    }

    public static class HistogramBox {
        double leftBound;
        double rightBound;
        List<Double> points = new ArrayList<Double>();
        protected Integer boxHeight = null;
        protected Double relativeHeight = null;

        public HistogramBox(double leftBound, double rightBound) {
            this.leftBound = leftBound;
            this.rightBound = rightBound;
        }

        public double randValue(){
            return SSRand.N_thrdSf().randomDouble(leftBound,rightBound);
        }

        public void add(double val) {
            points.add(val);
        }

        public HistogramBox calcProperies() {
            if (points.size() > 0) {
                boxHeight = points.size();
            } else {
                boxHeight = 0;
            }
            return this;
        }

        public void setBoxHeight(Integer boxHeight) {
            this.boxHeight = boxHeight;
        }
    }

    public static class TimedHistogramBox extends HistogramBox {
        List<Pair<Double, Double>> points2 = new ArrayList<Pair<Double, Double>>();

        public TimedHistogramBox(double leftBound, double rightBound) {
            super(leftBound, rightBound);
            this.leftBound = leftBound;
            this.rightBound = rightBound;
        }

        public void add(Double val, Double weight) {
            points2.add(new Pair<Double, Double>(val,weight));
        }

        public HistogramBox calcProperies() {
            if (points2.size() > 0) {
                double boxHeight = 0;
                for (Pair<Double, Double> point : points2) {
                    boxHeight+=point.b;
                }
                boxHeight = boxHeight*1000;
                this.boxHeight = (int) Math.round(boxHeight);
            } else {
                this.boxHeight = 0;
            }
            return this;
        }
    }
}
