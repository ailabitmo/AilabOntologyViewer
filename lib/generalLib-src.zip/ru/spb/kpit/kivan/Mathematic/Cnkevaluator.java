package ru.spb.kpit.kivan.Mathematic;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 12.07.2009
 * Time: 16:03:09
 * To change this template use File | Settings | File Templates.
 */
public class Cnkevaluator<N> {
    List<N> elements;
    Integer num;
    boolean processed = false;

    HashSet<Set<N>> setOfSets = new HashSet<Set<N>>();

    public Cnkevaluator(List<N> elements, Integer num) {
        this.elements = elements;
        this.num = num;
        if (!processed) {
            process();
            processed = !processed;
        }
    }

    private void recursiveGet(Integer numberLeft, Integer curNumber, Set<N> curSet) {
        if (numberLeft == 0) {
            setOfSets.add(curSet);
        } else {
            try {
                curSet.add(elements.get(curNumber));
                Integer size = elements.size();
                for (int i = curNumber + 1; i < size; i++) {
                    recursiveGet(numberLeft - 1, i, new HashSet<N>(curSet));
                }
                numberLeft -= 1;
                if (numberLeft == 0) {
                    setOfSets.add(curSet);
                }
            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }
    }

    private void process() {
        if (setOfSets.size() != 0) setOfSets = new HashSet<Set<N>>();
        Integer lastStarter = elements.size() - num;
        for (int i = 0; i <= lastStarter; i++) {
            recursiveGet(num, i, new HashSet<N>());
        }
    }

    public HashSet<Set<N>> getSetOfSets() {
        return setOfSets;
    }


    public String toString() {

        StringBuffer sb = new StringBuffer("");
        sb.append(num).append("-");
        sb.append(setOfSets.size()).append(":");
        for (Set<N> cur : setOfSets) {
            sb.append("(");
            for (N curEl : cur) {
                sb.append(curEl.toString()).append(" ");
            }
            sb.append(")");
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        /*Integer numOfElementsInList = 5;

        List<Integer> t = new ArrayList<Integer>(numOfElementsInList);
        for(int i = 1;i<=numOfElementsInList;i++){
            t.add(i);
        }

        for(int i = 0;i<numOfElementsInList;i++){
            Cnkevaluator<Integer> cnk = new Cnkevaluator<Integer>(t, i+1);
            System.out.println(cnk.toString());
        }*/

        ArrayList<Integer> elems = new ArrayList<Integer>();
        elems.add(1);
        elems.add(2);
        elems.add(3);
        elems.add(4);

        Cnkevaluator<Integer> cnk = new Cnkevaluator<Integer>(elems, 3);
        System.out.println(cnk.toString());
    }
}
