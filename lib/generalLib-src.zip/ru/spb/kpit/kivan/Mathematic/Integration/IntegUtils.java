package ru.spb.kpit.kivan.Mathematic.Integration;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 26.06.12
 * Time: 18:24
 * To change this template use File | Settings | File Templates.
 */

import ru.spb.kpit.kivan.Randomizer.Pair;

/**
 */

public class IntegUtils {
    /**
     * Returns the sum of f(x) from x=start to x=stop, where the
     * function f is defined by the evaluate method of the
     * Evaluatable object.
     */

    public static double sum(double start, double stop,
                             double stepSize,
                             Evaluatable evalObj) {
        double sum = 0.0, current = start;
        if (stepSize > 0)
            while (current <= stop) {
                sum += evalObj.evaluate(current);
                current += stepSize;
            }
        return (sum);
    }

    /**
     * Returns an approximation of the integral of f(x) from
     * start to stop, using the midpoint rule. The function f is
     * defined by the evaluate method of the Evaluatable object.
     */

    public static double integrate(double start, double stop,
                                   int numSteps,
                                   Evaluatable evalObj) {
        double stepSize = (stop - start) / (double) numSteps;
        start = start + stepSize / 2.0;
        return (stepSize * sum(start, stop, stepSize, evalObj));
    }

    public static double integrate(double start, double stop, Evaluatable evalObj) {
        return integrate(start, stop, 10000, evalObj);
    }

    public static double integrate(Pair<Double, Double> limits, Evaluatable evalObj) {
        return integrate(limits.a, limits.b, 10000, evalObj);

    }

    public static double integrate(Pair<Double, Double> limits, int numOfSteps, Evaluatable evalObj) {
        return integrate(limits.a, limits.b, numOfSteps, evalObj);
    }


}
