package ru.spb.kpit.kivan.Mathematic.Integration;

import ru.spb.kpit.kivan.Randomizer.Pair;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 30.06.12
 * Time: 16:33
 * To change this template use File | Settings | File Templates.
 */
public class NormalDistrib extends Evaluatable {

    double avg;
    double sko;

    public NormalDistrib(double avg, double sko) {
        this.sko = sko;
        this.avg = avg;
    }

    public double getAvg() {
        return avg;
    }

    public double getSko() {
        return sko;
    }

    public Double evaluate(double xVal) {
        double toRet = Math.exp(-Math.pow(xVal-avg,2)/(2*Math.pow(sko,2)));
        toRet = toRet/(sko*Math.sqrt(2*Math.PI));
        return toRet;
    }

    public Pair<Double,Double> getLimitsFor3SKO(){
        return new Pair<Double, Double>(avg-3*sko,avg+3*sko);
    }


    public String toString() {
        return  "avg=" + avg + "| sko=" + sko;
    }
}

