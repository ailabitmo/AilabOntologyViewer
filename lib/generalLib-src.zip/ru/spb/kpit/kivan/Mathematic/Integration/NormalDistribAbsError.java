package ru.spb.kpit.kivan.Mathematic.Integration;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 30.06.12
 * Time: 16:52
 * To change this template use File | Settings | File Templates.
 */
public class NormalDistribAbsError extends Evaluatable {
    NormalDistrib realDistrib;
    NormalDistrib modelDistrib;

    public NormalDistribAbsError(NormalDistrib realDistrib, NormalDistrib modelDistrib) {
        this.realDistrib = realDistrib;
        this.modelDistrib = modelDistrib;
    }


    public Double evaluate(double xVal) {
        double model = modelDistrib.evaluate(xVal);
        double real  = realDistrib.evaluate(xVal);
        if(model<real)return model;
        if(model>real) return real;
        return model;
    }
}
