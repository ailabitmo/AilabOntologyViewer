package ru.spb.kpit.kivan.Mathematic.Integration;

import ru.spb.kpit.kivan.Randomizer.Pair;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 30.06.12
 * Time: 16:30
 * To change this template use File | Settings | File Templates.
 */
public abstract class Evaluatable {
    public abstract Double evaluate(double xVal);

    public List<Pair<Double, Double>> getPointsForGraph(double from, double to, double pointNum){
        List<Pair<Double, Double>> values = new ArrayList<Pair<Double, Double>>();
        double delim = (to-from)/pointNum;
        while(from<to){
            Double val = evaluate(from);
            if(val!=null){
                values.add(new Pair<Double, Double>(from, val));
            }
            from = from+delim;
        }
        return values;
    }

    public List<Pair<Double, Double>> getPointsForGraph(double from, double to){
        return getPointsForGraph(from, to, 1000);
    }

}
