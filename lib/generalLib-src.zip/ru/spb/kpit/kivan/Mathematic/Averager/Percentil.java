package ru.spb.kpit.kivan.Mathematic.Averager;

public class Percentil {
    public float leftLimit;
    public float rightLimit;

    public Percentil(float leftLimit, float rightLimit) {
        this.leftLimit = leftLimit;
        this.rightLimit = rightLimit;
    }
}
