package ru.spb.kpit.kivan.Mathematic.Averager;

public class WVal {
    public Double val;
    public float weight;

    public WVal(double val, float weight) {
        this.val = val;
        this.weight = weight;
    }
}
