package ru.spb.kpit.kivan.Mathematic.Averager;

import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.functions.Function;

/**
 * IntelliJ IDEA. Best IDE in entire Universe.
 * CodeGod: Kivan
 * ContinuumBreak: 04.10.13
 * MomentOfSilence: 18:23
 */
public class RecurseLimiter implements Function {
    double coef;

    public RecurseLimiter(double coef) {
        this.coef = coef;
    }

    @Override
    public void regress(double[][] data) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public double calcValue(double... X) {
        double val = X[0];
        double mult = coef;
        for(int i = 0; i < val; i++) {
            mult*=coef;
        }
        return mult;
    }
}
