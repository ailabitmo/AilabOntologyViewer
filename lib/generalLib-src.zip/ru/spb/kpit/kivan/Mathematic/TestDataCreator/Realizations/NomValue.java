package ru.spb.kpit.kivan.Mathematic.TestDataCreator.Realizations;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Value;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 05.03.2011
 * Time: 11:07:46
 * To change this template use File | Settings | File Templates.
 */
public class NomValue implements Value<String> {

    String val;

    public NomValue(String val) {
        this.val = val;
    }

    public String getValue() {
        return val;
    }


    public String toString() {
        return val;
    }
}
