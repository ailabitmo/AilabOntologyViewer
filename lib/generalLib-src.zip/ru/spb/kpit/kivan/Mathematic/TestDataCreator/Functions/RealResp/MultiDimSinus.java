package ru.spb.kpit.kivan.Mathematic.TestDataCreator.Functions.RealResp;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.RealResponseFunction;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Value;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 27.05.2011
 * Time: 17:50:08
 * To change this template use File | Settings | File Templates.
 */
public class MultiDimSinus extends RealResponseFunction{
    public MultiDimSinus(float funcCoef) {
        super(funcCoef,100);
    }

    protected float output(Value... input) {
        float sum=0;
        for (Value<Float> predictor : input) {
            sum+=StrictMath.sin(predictor.getValue());
        }
        return sum;
    }
}
