package ru.spb.kpit.kivan.Mathematic.TestDataCreator;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Function;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Border;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Value;

import java.io.IOException;
import java.io.File;
import java.io.FileWriter;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 08.03.2011
 * Time: 23:28:29
 * To change this template use File | Settings | File Templates.
 */
public class OrderedGenerator extends Generator {
    public OrderedGenerator(String file, Function functor, float noizeCoef, int numOfPointsToGenerate, boolean gaussDistribution, Border... bordersForDimensions) {
        super(file, functor, noizeCoef, numOfPointsToGenerate, gaussDistribution, bordersForDimensions);
    }

    public void generate() throws IOException {
        File f = new File(file);
        //if (!f.getParentFile().exists()) throw new FileNotFoundException("Parent not found for " + file);

        FileWriter fw = null;
        try {
            fw = new FileWriter(f);
            StringBuilder row = new StringBuilder("");
            //Zagolovok
            for (Border bordersForDimension : bordersForDimensions) {
                fw.append(bordersForDimension.getDimensionName()).append(", ");
            }
            fw.append("F(X) \r\n");

            //To4ki
            for (int i = 0; i < numOfPointsToGenerate; i++) {
                Value[] X = new Value[bordersForDimensions.size()];
                for (int i1 = 0; i1 < bordersForDimensions.size(); i1++) {
                    X[i1] = bordersForDimensions.get(i1).getOrderedValueFromBorder(i);
                    fw.append(X[i1].toString()).append(", ");
                }
                fw.append(functor.output(noizeCoef, X).toString());
                fw.append("\r\n");
            }
        } finally {
            if (fw != null) fw.close();
        }
    }
}
