package ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.Realizations.RealValue;

import ru.spb.kpit.kivan.Randomizer.SSRand;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 05.03.2011
 * Time: 11:32:24
 * To change this template use File | Settings | File Templates.
 */
public abstract class RealResponseFunction implements Function<Float>{

    float funcCoef;
    int maxParams;

    protected RealResponseFunction(float funcCoef, int maxParams) {
        this.funcCoef = funcCoef;
        this.maxParams = maxParams;
    }

    protected abstract float output(Value... input);

    public Value<Float> output(float noizeCoef, Value... input) {
        try {
            if ( input.length ==0) throw new Exception("Wrong parameters size (must be > 0): "+input.length);
            return new RealValue(SSRand.thrdSf().randomGaussian(noizeCoef) + funcCoef*output(input));
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;      
    }
}
