package ru.spb.kpit.kivan.Mathematic.TestDataCreator.Realizations;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Value;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.JustBorder;

import ru.spb.kpit.kivan.Randomizer.SSRand;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 05.03.2011
 * Time: 11:18:40
 * To change this template use File | Settings | File Templates.
 */
public class RealBorder extends JustBorder {
    int min;
    int max;

    int numOfPoints;

    public RealBorder(String name, int min, int max, int numOfPoints) {
        super(name);
        this.min = min;
        this.max = max;
        this.numOfPoints = numOfPoints;
    }

    public Value getRandomValueFromBorder(boolean gaussDistribution) {
        if (gaussDistribution)
            return new RealValue(min + SSRand.thrdSf().randomGaussian(max));
        else
            return new RealValue(SSRand.thrdSf().randomFloat(min, max));
    }

    public Value getOrderedValueFromBorder(int numOfPoint){
        return new RealValue(min+(float)(max-min)*numOfPoint/numOfPoints);
    }
}
