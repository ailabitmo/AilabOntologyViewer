package ru.spb.kpit.kivan.Mathematic.TestDataCreator.Functions.RealResp;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.RealResponseFunction;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Value;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 07.03.2011
 * Time: 21:33:46
 * To change this template use File | Settings | File Templates.
 */
public class Linear extends RealResponseFunction {

    float a;
    float b;

    public Linear(float funcCoef, float a, float b) {
        super(funcCoef, 1);
        this.a = a;
        this.b = b;
    }

    protected float output(Value... input) {
        return a*(Float)input[0].getValue()+b;
    }
}
