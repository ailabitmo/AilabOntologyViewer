package ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 05.03.2011
 * Time: 10:40:55
 * To change this template use File | Settings | File Templates.
 */
public interface Border {
    String getDimensionName();
    Value getRandomValueFromBorder(boolean gaussDistribution);
    public Value getOrderedValueFromBorder(int numOfPoint);
}
