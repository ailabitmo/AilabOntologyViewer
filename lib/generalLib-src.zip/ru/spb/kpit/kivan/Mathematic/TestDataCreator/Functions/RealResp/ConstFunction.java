package ru.spb.kpit.kivan.Mathematic.TestDataCreator.Functions.RealResp;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.RealResponseFunction;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Value;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 05.03.2011
 * Time: 12:50:39
 * To change this template use File | Settings | File Templates.
 */
public class ConstFunction extends RealResponseFunction {
    int val;

    public ConstFunction(float funcCoef, int val) {
        super(funcCoef, 0);
        this.val = val;
    }

    protected float output(Value... input) {
        return val;
    }
}
