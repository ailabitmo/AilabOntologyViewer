package ru.spb.kpit.kivan.Mathematic.TestDataCreator.Functions.NomResp;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.NominalResponseFunction;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Value;
import ru.spb.kpit.kivan.Randomizer.Pair;
import ru.spb.kpit.kivan.Randomizer.SSRand;
import ru.spb.kpit.kivan.General.DataStructures.HM;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 05.06.2011
 * Time: 13:29:33
 * To change this template use File | Settings | File Templates.
 */
public class ThreeClassesStrange extends NominalResponseFunction{

    public ThreeClassesStrange() {
        super(2, "raz", "dva", "tri");
    }

    protected String out(float noizeCoef, Value... input) {
        Value<Float> inp = input[0];
        float val = inp.getValue();
        if(val>=0 && val<3){
            return (String) SSRand.thrdSf().roll_objectUserDefined(new HM(
                    new Pair("raz",1), new Pair("dva",2), new Pair("tri",3)
            ));
        } else if(val>=3 && val<7) {
            return (String) SSRand.thrdSf().roll_objectUserDefined(new HM(
                    new Pair("raz",3), new Pair("dva",1), new Pair("tri",0)
            ));
        } else if(val>=7){
            return (String) SSRand.thrdSf().roll_objectUserDefined(new HM(
                    new Pair("raz",1), new Pair("dva",1), new Pair("tri",1)
            ));
        }
        return "";
    }
}
