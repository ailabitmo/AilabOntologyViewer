package ru.spb.kpit.kivan.Mathematic.TestDataCreator;



import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Function;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Border;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.Realizations.RealBorder;

import java.util.ArrayList;
import java.util.Arrays;
import java.io.IOException;


/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 05.03.2011
 * Time: 10:35:21
 * To change this template use File | Settings | File Templates.
 */
public abstract class Generator {
    String file;
    Function functor;
    float noizeCoef;
    int numOfPointsToGenerate;
    boolean gaussDistribution;
    ArrayList<Border> bordersForDimensions;

    public Generator(String file, Function functor, float noizeCoef, int numOfPointsToGenerate, boolean gaussDistribution, Border... bordersForDimensions) {
        this.file = file;
        this.functor = functor;
        this.gaussDistribution = gaussDistribution;
        this.noizeCoef = noizeCoef;
        this.bordersForDimensions = new ArrayList<Border>(Arrays.asList(bordersForDimensions));
        this.numOfPointsToGenerate = numOfPointsToGenerate;
    }

    public abstract void generate() throws IOException;

    public static class Cur {
        public static boolean ordered = true;

        public static Generator current(String file, Function functor, float noize, int numOfPoints, boolean gaussDistribution, RealBorder... realBorders) {
            if (!ordered)
                return new RandomGenerator(file, functor, noize, numOfPoints, gaussDistribution, realBorders);
            else
                return new OrderedGenerator(file, functor, noize, numOfPoints, gaussDistribution, realBorders);

        }
    }
}
