package ru.spb.kpit.kivan.Mathematic.TestDataCreator.Functions.RealResp;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.RealResponseFunction;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Value;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 26.06.2011
 * Time: 0:15:39
 * To change this template use File | Settings | File Templates.
 */
public class MyCoolFunction extends RealResponseFunction {
    float xMaximum;
    public MyCoolFunction(float funcCoef, float xMaximum) {
        super(funcCoef, 1);
        this.xMaximum = xMaximum;
    }

    protected float output(Value... input) {
        Float x = (Float)input[0].getValue();
        float xMaximumDiv2 = xMaximum/2;
        return (float) (-1/(1-Math.exp(2)) * Math.exp(x/xMaximumDiv2) + 1/(1-Math.exp(2)));
        //return (float) ( 1- Math.exp(-x/(xMaximum/3)));
    }
}
