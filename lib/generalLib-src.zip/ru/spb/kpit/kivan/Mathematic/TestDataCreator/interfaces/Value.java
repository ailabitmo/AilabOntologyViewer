package ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 03.03.2011
 * Time: 16:51:53
 * To change this template use File | Settings | File Templates.
 */
public interface Value<P> {
    public String toString();
    public P getValue();
}
