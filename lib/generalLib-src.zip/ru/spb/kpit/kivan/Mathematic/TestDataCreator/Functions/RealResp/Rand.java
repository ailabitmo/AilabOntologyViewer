package ru.spb.kpit.kivan.Mathematic.TestDataCreator.Functions.RealResp;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.RealResponseFunction;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Value;

import ru.spb.kpit.kivan.Randomizer.SSRand;


/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 18.03.2011
 * Time: 23:40:40
 * To change this template use File | Settings | File Templates.
 */
public class Rand extends RealResponseFunction {
    public Rand(float funcCoef) {
        super(funcCoef, 1);
    }

    protected float output(Value... input) {
        float x = (Float) input[0].getValue();
        return (float) (SSRand.thrdSf().randomFloat(x,x+(float) Math.pow(SSRand.thrdSf().randomFloat(0,x),2)));
    }
}
