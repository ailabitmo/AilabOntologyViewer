package ru.spb.kpit.kivan.Mathematic.TestDataCreator.Realizations;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Value;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 05.03.2011
 * Time: 11:07:53
 * To change this template use File | Settings | File Templates.
 */
public class RealValue implements Value<Float> {

    float f;

    public RealValue(float f) {
        this.f = f;
    }

    public Float getValue() {
        return f;        
    }


    public String toString() {
        return String.valueOf(f);
    }
}
