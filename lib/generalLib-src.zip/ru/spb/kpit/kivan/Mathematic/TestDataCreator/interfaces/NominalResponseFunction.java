package ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.Realizations.NomValue;


/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 05.06.2011
 * Time: 0:52:21
 * To change this template use File | Settings | File Templates.
 */
public abstract class NominalResponseFunction implements Function<String>{
    int maxParams;
    String[] outAnInt;

    protected NominalResponseFunction( int maxParams, String... outputs ) {
        this.maxParams = maxParams;
        outAnInt = outputs;
    }

    protected abstract String out( float noizeCoef, Value... input );

    public Value<String> output(float noizeCoef, Value... input) {
        try {
            if ( input.length ==0) throw new Exception("Wrong parameters size (must be > 0): "+input.length);
            return new NomValue(out(noizeCoef, input));
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }
}
