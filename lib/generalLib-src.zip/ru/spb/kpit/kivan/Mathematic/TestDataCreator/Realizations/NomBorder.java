package ru.spb.kpit.kivan.Mathematic.TestDataCreator.Realizations;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Value;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.JustBorder;

import ru.spb.kpit.kivan.Randomizer.SSRand;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 05.03.2011
 * Time: 11:11:23
 * To change this template use File | Settings | File Templates.
 */
public class NomBorder extends JustBorder {

    String[] values;

    public NomBorder(String dimName, String ... values) {
        super(dimName);
        this.values = values;
    }

    public Value getRandomValueFromBorder(boolean gaussDistribution) {
        return new NomValue((String) SSRand.thrdSf().randElFromMas(values));
    }

    public Value getOrderedValueFromBorder(int numOfPoint) {
        return new NomValue((String) SSRand.thrdSf().randElFromMas(values));
    }
}
