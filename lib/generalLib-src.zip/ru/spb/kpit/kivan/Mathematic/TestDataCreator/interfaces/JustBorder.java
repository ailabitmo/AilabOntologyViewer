package ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 05.03.2011
 * Time: 11:16:46
 * To change this template use File | Settings | File Templates.
 */
public abstract class JustBorder implements Border{
    String name;

    protected JustBorder(String name) {
        this.name = name;
    }

    public String getDimensionName() {
        return name;
    }
}
