package ru.spb.kpit.kivan.Mathematic.TestDataCreator.Functions.RealResp;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.RealResponseFunction;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Value;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.Realizations.RealValue;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 05.03.2011
 * Time: 11:36:09
 * To change this template use File | Settings | File Templates.
 */
public class SinusDim1 extends RealResponseFunction {
    public SinusDim1(float funcCoef) {
        super(funcCoef,1);
    }

    protected float output(Value... input) {
        RealValue predictor = (RealValue) input[0];
        return (float) StrictMath.sin((double) predictor.getValue());
    }
}
