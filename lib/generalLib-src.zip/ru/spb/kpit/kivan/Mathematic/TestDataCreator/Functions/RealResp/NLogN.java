package ru.spb.kpit.kivan.Mathematic.TestDataCreator.Functions.RealResp;

import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.RealResponseFunction;
import ru.spb.kpit.kivan.Mathematic.TestDataCreator.interfaces.Value;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 10.03.2011
 * Time: 16:16:15
 * To change this template use File | Settings | File Templates.
 */
public class NLogN extends RealResponseFunction{
    public NLogN(float funcCoef) {
        super(funcCoef, 1);
    }

    protected float output(Value... input) {
        Float x = (Float)input[0].getValue();
        return (float) (x*Math.log(x));
        //return (float) (-1/(1-Math.exp(20/10)) * Math.exp(x/10) + 1/(1-Math.exp(20/10)));
    }
}
