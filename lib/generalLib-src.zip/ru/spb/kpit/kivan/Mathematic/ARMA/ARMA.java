package ru.spb.kpit.kivan.Mathematic.ARMA;

import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.EquationSystem;
import ru.spb.kpit.kivan.Mathematic.LeastSquareMethod.Equation;
import ru.spb.kpit.kivan.General.DataStructures.ListWithLimit;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 11.07.2011
 * Time: 17:08:48
 * To change this template use File | Settings | File Templates.
 */
public class ARMA {

    public static EquationSystem returnDifferenceSystemForLag(int lag, EquationSystem initEQ) {
        ListWithLimit<Double> history = new ListWithLimit<Double>(lag);
        EquationSystem toRet = new EquationSystem();
        for (Equation x_y : initEQ.getEquations()) {
            Double oldVar = history.add(x_y.getY());
            if (oldVar != null) {
                toRet.getEquations().add(new Equation(x_y.getX(), x_y.getY()- oldVar));
            } else {
                //toRet.getEquations().add(new Equation(x_y.getX(),0));
            }
        }
        return toRet;
    }

    public static EquationSystem createAR_RSwithP(int p, EquationSystem initEQ) {
        ListWithLimit<Double> history = new ListWithLimit<Double>(p);
        EquationSystem toRet = new EquationSystem();
        for (Equation x_y : initEQ.getEquations()) {
            Double oldVar = history.add(x_y.getY());
            if (oldVar != null) {
                double[] arr = new double[p];
                arr[0]=oldVar;
                for(int i=1; i<p; i++){
                    arr[i] = history.get(i-1);
                }
                toRet.getEquations().add(new Equation(arr, x_y.getY()));
            } else {
                //toRet.getEquations().add(new Equation(x_y.getX(),0));
            }
        }
        return toRet;
    }
}
