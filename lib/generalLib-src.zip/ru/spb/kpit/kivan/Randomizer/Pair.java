package ru.spb.kpit.kivan.Randomizer;

import ru.spb.kpit.kivan.General.Strings.StringUtils;

import java.util.Collection;

public class Pair<A, B> {
    public A a;
    public B b;

    public Pair(A a, B b) {
        this.a = a;
        this.b = b;
    }


    public Object clone() {
        Pair<A,B> toRet = new Pair<A,B>(a,b);
        return toRet;
    }


    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Pair pair = (Pair) o;

        if (a != null ? !a.equals(pair.a) : pair.a != null) return false;
        if (b != null ? !b.equals(pair.b) : pair.b != null) return false;

        return true;
    }


    public int hashCode() {
        int result = a != null ? a.hashCode() : 0;
        result = 31 * result + (b != null ? b.hashCode() : 0);
        return result;
    }


    public String toString() {
        return "[" + ((a instanceof Collection)? "["+StringUtils.gStrFrColEls(((Collection)a),",")+"]":a) + ";" + ((b instanceof Collection)? "["+StringUtils.gStrFrColEls(((Collection)b),",")+"]":b) +"]";
    }
}