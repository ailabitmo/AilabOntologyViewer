package ru.spb.kpit.kivan.Randomizer;

import ru.spb.kpit.kivan.General.DataStructures.HM;

import java.util.*;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 31.08.13
 * Time: 21:48
 * To change this template use File | Settings | File Templates.
 */
public class SyncRandomizer implements Randomizer{
    ReentrantLock lock = new ReentrantLock();
    PlainRandomizer randomizer;

    public SyncRandomizer(long seed) {
        randomizer = new PlainRandomizer(seed);
    }

    public SyncRandomizer() {
        randomizer = new PlainRandomizer();
    }

    @Override
    public int randomInt(int min, int max) {
        lock.lock();
        int toRet;
        try {
            toRet = randomizer.randomInt(min, max);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public float randomFloat(float min, float max) {
        lock.lock();
        float toRet;
        try {
            toRet = randomizer.randomFloat(min, max);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public double randomDouble(double min, double max) {
        lock.lock();
        double toRet;
        try {
            toRet = randomizer.randomDouble(min, max);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public float randomGaussian(float SKO) {
        lock.lock();
        float toRet;
        try {
            toRet = randomizer.randomGaussian(SKO);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public float randomGaussian(float avg, float SKO) {
        lock.lock();
        float toRet;
        try {
            toRet = randomizer.randomGaussian(avg, SKO);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public double randomGaussian(double avg, double SKO) {
        lock.lock();
        double toRet;
        try {
            toRet = randomizer.randomGaussian(avg, SKO);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public float randomPositiveGaussian(float SKO) {
        lock.lock();
        float toRet;
        try {
            toRet = randomizer.randomPositiveGaussian(SKO);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public float randomPositiveGaussian(float avg, float SKO) {
        lock.lock();
        float toRet;
        try {
            toRet = randomizer.randomPositiveGaussian(avg, SKO);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public boolean randomBool() {
        lock.lock();
        boolean toRet;
        try {
            toRet = randomizer.randomBool();
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public char randomChar(CharType type) {
        lock.lock();
        char toRet;
        try {
            toRet = randomizer.randomChar(type);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public char randomChar() {
        lock.lock();
        char toRet;
        try {
            toRet = randomizer.randomChar();
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public Date randomDate() {
        lock.lock();
        Date toRet;
        try {
            toRet = randomizer.randomDate();
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public Object randElFromList(List ls) {
        lock.lock();
        Object toRet;
        try {
            toRet = randomizer.randElFromList(ls);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public Object randElFromCollection(Collection cs) {
        lock.lock();
        Object toRet;
        try {
            toRet = randomizer.randElFromCollection(cs);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public Set randElsFromCollection(Collection cs, int numToRand) {
        lock.lock();
        Set toRet;
        try {
            toRet = randomizer.randElsFromCollection(cs, numToRand);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public Object randElFromMas(Object[] mas) {
        lock.lock();
        Object toRet;
        try {
            toRet = randomizer.randElFromMas(mas);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public String randomString() {
        lock.lock();
        String toRet;
        try {
            toRet = randomizer.randomString();
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public String randomString(StringType st) {
        lock.lock();
        String toRet;
        try {
            toRet = randomizer.randomString(st);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public String randomString(int minSize, int maxSize, StringType type) {
        lock.lock();
        String toRet;
        try {
            toRet = randomizer.randomString(minSize, maxSize, type);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public String randomString(int minSize, int maxSize) {
        lock.lock();
        String toRet;
        try {
            toRet = randomizer.randomString(minSize, maxSize);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public Boolean roll_percent(int percent) {
        lock.lock();
        Boolean toRet;
        try {
            toRet = randomizer.roll_percent(percent);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public Boolean roll_userDefined(int percent, int maxValue) {
        lock.lock();
        Boolean toRet;
        try {
            toRet = randomizer.roll_userDefined(percent, maxValue);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public Object roll_objectUserDefined(HashMap objectsAndPercent) {
        lock.lock();
        Object toRet;
        try {
            toRet = randomizer.roll_objectUserDefined(objectsAndPercent);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public HM<Object, Float> randomizeFloatsForObjects(Collection objects_inp, float startNum) {
        lock.lock();
        HM<Object, Float> toRet;
        try {
            toRet = randomizer.randomizeFloatsForObjects(objects_inp, startNum);
        } finally {
            lock.unlock();
        }
        return toRet;
    }

    @Override
    public void setSeed(int i) {
        lock.lock();
        try {
            randomizer.setSeed(i);
        } finally {
            lock.unlock();
        }
    }
}
