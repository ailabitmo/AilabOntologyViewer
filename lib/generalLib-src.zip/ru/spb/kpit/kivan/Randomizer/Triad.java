package ru.spb.kpit.kivan.Randomizer;

import ru.spb.kpit.kivan.General.Strings.StringUtils;

import java.util.Collection;

/**
 * User: Kivan
 * Date: 04.07.2010
 * Time: 21:57:16
 */
public class Triad <A,B,C> {
    public A a;
    public B b;
    public C c;

    public Triad(A a, B b, C c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }


    public String toString() {
        return "[" + ((a instanceof Collection)? "["+ StringUtils.gStrFrColEls(((Collection) a), ",")+"]":a) + ";" + ((b instanceof Collection)? "["+StringUtils.gStrFrColEls(((Collection)b),",")+"]":b)+ ";" + ((c instanceof Collection)? "["+StringUtils.gStrFrColEls(((Collection)c),",")+"]":c) +"]";
    }
}
