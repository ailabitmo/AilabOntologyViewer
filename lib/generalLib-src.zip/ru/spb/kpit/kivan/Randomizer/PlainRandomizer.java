package ru.spb.kpit.kivan.Randomizer;

import ru.spb.kpit.kivan.General.DataStructures.HM;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 07.01.2010
 * Time: 22:39:54
 * To change this template use File | Settings | File Templates.
 */

public class PlainRandomizer implements Randomizer {
    Random randomizer;

    public PlainRandomizer(long seed) {
        randomizer = new Random(seed);
    }

    public PlainRandomizer() {
        randomizer = new Random();
    }


    //random Integer in a range (including last!!!)
    @Override
    public int randomInt(int min, int max) {
        if(min==max)return min;
        return (min < max) ? (min + randomizer.nextInt((max + 1) - min)) : -1;
    }

    //random Float in a range (including last!!!)
    @Override
    public float randomFloat(float min, float max) {
        if(min==max)return min;
        return (min < max) ? (max - min) * randomizer.nextFloat() + min : -1;
    }

    //random Float in a range (including last!!!)
    @Override
    public double randomDouble(double min, double max) {
        if(min==max)return min;
        return (min < max) ? (max - min) * randomizer.nextDouble() + min : -1;
    }

    //Gaussian with coefficient
    @Override
    public float randomGaussian(float SKO) {
        return (float) randomizer.nextGaussian() * SKO;
    }

    @Override
    public float randomGaussian(float avg, float SKO) {
        return avg+ (float) randomizer.nextGaussian() * SKO;
    }

    @Override
    public double randomGaussian(double avg, double SKO) {
        return avg+ (double) randomizer.nextGaussian() * SKO;
    }

    //Gaussian with coefficient
    @Override
    public float randomPositiveGaussian(float SKO) {
        return (float) Math.abs(randomizer.nextGaussian()) * SKO;
    }

    //Gaussian with coefficient
    @Override
    public float randomPositiveGaussian(float avg, float SKO) {
        return avg + (float) Math.abs(randomizer.nextGaussian()) * SKO;
    }

    //Random boolean
    @Override
    public boolean randomBool() {
        return randomizer.nextBoolean();
    }

    @Override
    public char randomChar(CharType type) {
        Character[] chars = type.getChars();
        return chars[randomInt(0, chars.length - 1)];
    }

    @Override
    public char randomChar() {
        return randomChar(CharType.both);
    }

    //Random Date
    @Override
    public Date randomDate() {
        return new Date(
                randomInt(50, 150),
                randomInt(0, 11),
                randomInt(1, 28),
                randomInt(0, 23),
                randomInt(1, 59),
                randomInt(1, 59)
        );
    }


    @Override
    public Object randElFromList(List ls) {
        int index = randomInt(0, ls.size() - 1);
        return (index >= 0) ? ls.get(index) : null;
    }

    //Rand el from collection
    @Override
    public Object randElFromCollection(Collection cs) {
        List ls = new ArrayList(cs);
        int index = randomInt(0, ls.size() - 1);
        return (index >= 0) ? ls.get(index) : null;
    }

    //Rand els from collection
    @Override
    public Set randElsFromCollection(Collection cs, int numToRand) {
        if (numToRand >= cs.size())
            return new HashSet(cs);

        ArrayList copyOfInput = new ArrayList(cs);
        Set toRet = new HashSet();

        while (numToRand > 0) {
            int index = randomInt(0, copyOfInput.size() - 1);
            toRet.add(copyOfInput.get(index));
            copyOfInput.remove(index);
            numToRand--;
        }

        return toRet;
    }

    //random ElementFromArray
    @Override
    public Object randElFromMas(Object[] mas) {
        int index = randomInt(0, mas.length - 1);
        return (index >= 0) ? mas[index] : null;
    }


    @Override
    public String randomString() {
        int minSize = 1+randomInt(0, 9);
        int maxSize = minSize + randomInt(0, 10);
        StringType st = (StringType) randElFromMas(StringType.values());
        return randomString(minSize, maxSize, st);
    }

    @Override
    public String randomString(StringType st) {
        int minSize = 1+randomInt(1, 9);
        int maxSize = minSize + randomInt(0, 10);
        return randomString(minSize, maxSize, st);
    }

    @Override
    public String randomString(int minSize, int maxSize, StringType type) {
        StringBuffer temp = new StringBuffer("");
        if (minSize <= maxSize) {
            int realSize = randomInt(minSize, maxSize);
            if (type == StringType.bigStart) {
                temp.append(randomChar(CharType.big));
                for (int i = 0; i < realSize - 1; i++) {
                    temp.append(randomChar(CharType.little));
                }
            } else {
                for (int i = 0; i <= realSize - 1; i++) {
                    temp.append(
                            (type == StringType.big) ? randomChar(CharType.big) :
                                    (type == StringType.little) ? randomChar(CharType.little) :
                                            (type == StringType.both) ? randomChar(CharType.both) : ""
                    );
                }
            }

            return temp.toString();
        } else {
            return null;
        }
    }

    @Override
    public String randomString(int minSize, int maxSize) {
        StringType type = (StringType) randElFromMas(StringType.values());
        return randomString(minSize, maxSize, type);
    }

    //Random chance from 100%
    @Override
    public Boolean roll_percent(int percent) {
        if (percent < 0 || percent > 100) return null;
        else {
            int roll = randomInt(1, 100);
            return roll <= percent;
        }
    }

    //Random chance from user definement
    @Override
    public Boolean roll_userDefined(int percent, int maxValue) {
        if (percent < 0 || percent > maxValue) return null;
        else {
            int roll = randomInt(1, maxValue);
            return roll <= percent;
        }
    }

    //RaNDOM object from user map with veroyatn sopostavlennie im
    //HashMap<Object, Integer> objectsAndPercent
    //one of probs must be > 0
    @Override
    public Object roll_objectUserDefined(HashMap objectsAndPercent) {
        //������������ �������� �� �������� �����������
        int maxValue = 0;
        //���� � ������������ � ��������� �� ���
        HashMap<Pair, Object> mapWithPromezhutok = new HashMap<Pair, Object>();

        int numOfZeroProbs = 0;

        for (Object obj : objectsAndPercent.keySet()) {
            Integer relProba = (Integer) objectsAndPercent.get(obj);
            if ((Integer) relProba == 0) numOfZeroProbs++;
            else {
                mapWithPromezhutok.put(new Pair(maxValue + 1, maxValue + relProba), obj);
                maxValue += relProba;
            }
        }

        if (numOfZeroProbs == objectsAndPercent.size())
            return objectsAndPercent.keySet().toArray()[randomInt(0, objectsAndPercent.size() - 1)];

        int roll = randomInt(1, maxValue);
        for (Pair p : mapWithPromezhutok.keySet()) {
            if (roll >= (Integer) p.a && roll <= (Integer) p.b) return mapWithPromezhutok.get(p);
        }
        return null;
    }


    // ������������� ����� ����� ���������� ���������. ������� �� ��������� - �� ���� ������������� �� �����������,
    // � �� ������ ���� ��� ����� �����!!! �����, ����� ��������� ���� 70. �������� ��� 10 ���������. � ����� ������ ������������.
    // ������� ������ ���� ������
    // ��.���������=70  ���������� ���������    :      2         3         4          5         6      7       8         9       10
    private final int[][] MxMnForPercentRandom = {{64, 36}, {51, 31}, {45, 24}, {44, 20}, {43, 15}, {42, 8}, {44, 7}, {45, 5}, {45, 4}};

    @Override
    public HM<Object, Float> randomizeFloatsForObjects(Collection objects_inp, float startNum) {
        HM<Object, Float> toRet = new HM<Object, Float>();
        Collection objects = new ArrayList(objects_inp);
        if (objects.size() == 1) {
            toRet.put(randElFromCollection(objects), startNum);
            return toRet;
        }
        //������� ������ �������� ���� �� ���������.
        Integer maxPercentForAttributeGen = 45;
        //������� ������ �������� ���� �� ���������.
        Integer minPercentForAttributeGen = 1;
        if (objects_inp.size() < 11) {
            maxPercentForAttributeGen = MxMnForPercentRandom[objects.size() - 2][0];
            minPercentForAttributeGen = MxMnForPercentRandom[objects.size() - 2][1];
        }

        //�����, ������� ����� ����� �����
        float startPercent = startNum;

        while (objects.size() > 0) {
            Object randObj = randElFromCollection(objects);
            if (objects.size() == 1) {
                toRet.put(randObj, startPercent);
                break;
            }
            Float randomnedPercent = randomFloat
                    (startPercent * minPercentForAttributeGen / 100, startPercent * maxPercentForAttributeGen / 100);

            toRet.put(randObj, randomnedPercent);
            startPercent = startPercent - randomnedPercent;

            objects.remove(randObj);
        }
        return toRet;
    }

    @Override
    public void setSeed(int i) {
        randomizer = new Random(i);
    }


    public void main(String[] args) {
        HashMap hm = new HashMap();
        hm.put("75 000 000", 1);
        hm.put("0", 0);
        hm.put("1", 1);
        hm.put("2", 1);


        HashMap<String, Integer> results = new HashMap<String, Integer>();
        results.put("75 000 000", 0);
        results.put("0", 0);
        results.put("1", 0);
        results.put("2", 0);

        for (int i = 0; i < 1000000; i++) {
            String result = (String) roll_objectUserDefined(hm);
            results.put(result, results.get(result) + 1);
        }

        roll_objectUserDefined(hm);

        /*HashMap hm = new HashMap();
        hm.put("75 000 000", 75);
        hm.put("20 000 000", 20);
        hm.put(" 5 000 000", 5);

        HashMap<String, Integer> results = new HashMap<String, Integer>();
        results.put("75 000 000",0);
        results.put("20 000 000",0);
        results.put(" 5 000 000",0);

        for (int i = 0; i < 100; i++) {
            String result = (String) roll_objectUserDefined(hm);
            results.put(result, results.get(result)+1);
        }

        roll_objectUserDefined(hm);*/


        /*ArrayList a = new ArrayList();

        a.add("1");
        a.add("2");
        a.add("3");
        a.add("4");
        a.add("5");
        a.add("6");


        float num = 1000;
        float times = 1000;
        float median = num / a.size();

        float globDisperse = 0;
        for (int i = 0; i < times; i++) {
            HashMap hm = randomizeFloatsForObjects(a, num);
            float disperse = 0;
            for (Object o : hm.keySet()) {
                float oo = (Float) hm.get(o);
                disperse += Math.abs(oo - median);
            }
            disperse = disperse / a.size();
            System.out.println("hm = " + hm + " " + (int) disperse);
            globDisperse += disperse;
        }
        System.out.println("globDisperse = " + globDisperse / times);*/

        //������� ���������
        /*
        ArrayList a = new ArrayList();

        a.add("1");
        a.add("2");
        a.add("3");
        a.add("4");
        a.add("5");
        a.add("6");
        a.add("7");
        a.add("8");
        a.add("9");
        a.add("10");


        float num = 1000;
        float times = 1000;
        float median = num / a.size();

        HM<Pair<Integer, Integer>, Float> MnMxDisp = new HM<Pair<Integer, Integer>, Float>();

        for (int mn = 1; mn <= 99; mn++) {
            System.out.println("mn = " + mn);
            for (int mx = 1; mx <= 99; mx++) {
                float globDisperse = 0;
                for (int i = 0; i < times; i++) {
                    HashMap hm = randomizeFloatsForObjects(a, num, mx, mn);
                    float disperse = 0;
                    for (Object o : hm.keySet()) {
                        float oo = (Float) hm.get(o);
                        disperse += Math.abs(oo - median);
                    }
                    disperse = disperse / a.size();
                    globDisperse += disperse;
                }
                MnMxDisp.put(new Pair<Integer, Integer>(mn, mx), globDisperse / times);
            }
        }


        System.out.print("   ");
        for (int i = 1; i <= 99; i++) {
            if (i >= 10) System.out.print("  " + i);
            else System.out.print("   " + i);
        }
        System.out.println("");
        for (int mn = 1; mn <= 99; mn++) {
            if (mn >= 10) System.out.print(mn + "  ");
            else System.out.print(mn + "   ");
            for (int mx = 1; mx <= 99; mx++) {
                String out = "";
                float res = MnMxDisp.get(new Pair<Integer, Integer>(mn, mx));
                if (res > num - 1) out = " max";
                else if (res < 10) out = " min";
                else if (res >= 10 && res < 100) out = "  " + (int) res;
                else if (res >= 100 && res < 1000) out = " " + (int) res;
                System.out.print(out);


            }
            System.out.println("");
        }

      */
        /*ArrayList a = new ArrayList();
       a.add("1");
       a.add("2");
       a.add("3");
       a.add("4");
       a.add("5");

       System.out.println(randElsFromCollection(a, 3));*/

        /*float f = 0;
        int n = 10000;
        for(int i = 0 ;i<n;i++){
            f=f+randomFloat(1.5f,3.5f);
        }

        System.out.println((float)f/n);*/
        /*HashMap sm = new HashMap();
        sm.put("first",0);
        sm.put("second",20);
        sm.put("third",70);


        HashMap res = new HashMap();
        res.put("first",0);
        res.put("second",0);
        res.put("third",0);

        for (int i = 0; i < 9000000; i++) {
            String roll = (String) roll_objectUserDefined(sm);
            res.put(roll,(Integer)res.get(roll)+1);
        }

        System.out.println(res.get("first"));
        System.out.println(res.get("second"));
        System.out.println(res.get("third"));*/

        /*HashMap<String, Integer> sm = new HashMap<String, Integer>();
        sm.put("a",0);
        sm.put("b",0);
        sm.put("c",0);
        sm.put("d",0);
        sm.put("e",0);
        sm.put("w",0);
        sm.put("h",0);
        sm.put("werw",0);
        for (int i = 0; i < 1000000; i++) {
            String el = (String) randElFromList(Arrays.asList(sm.keySet().toArray()));
            sm.put(el, sm.get(el)+1);
        }*/


    }
}

