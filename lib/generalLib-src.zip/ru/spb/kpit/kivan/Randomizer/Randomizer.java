package ru.spb.kpit.kivan.Randomizer;

import ru.spb.kpit.kivan.General.DataStructures.HM;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: Kivan
 * Date: 31.08.13
 * Time: 22:47
 * To change this template use File | Settings | File Templates.
 */
public interface Randomizer {
    //random Integer in a range (including last!!!)
    int randomInt(int min, int max);

    //random Float in a range (including last!!!)
    float randomFloat(float min, float max);

    //random Float in a range (including last!!!)
    double randomDouble(double min, double max);

    //Gaussian with coefficient
    float randomGaussian(float SKO);

    float randomGaussian(float avg, float SKO);

    double randomGaussian(double avg, double SKO);

    //Gaussian with coefficient
    float randomPositiveGaussian(float SKO);

    //Gaussian with coefficient
    float randomPositiveGaussian(float avg, float SKO);

    //Random boolean
    boolean randomBool();

    char randomChar(CharType type);

    char randomChar();

    //Random Date
    Date randomDate();

    Object randElFromList(List ls);

    //Rand el from collection
    Object randElFromCollection(Collection cs);

    //Rand els from collection
    Set randElsFromCollection(Collection cs, int numToRand);

    //random ElementFromArray
    Object randElFromMas(Object[] mas);

    String randomString();

    String randomString(StringType st);

    String randomString(int minSize, int maxSize, StringType type);

    String randomString(int minSize, int maxSize);

    //Random chance from 100%
    Boolean roll_percent(int percent);

    //Random chance from user definement
    Boolean roll_userDefined(int percent, int maxValue);

    //RaNDOM object from user map with veroyatn sopostavlennie im
    //HashMap<Object, Integer> objectsAndPercent
    //one of probs must be > 0
    Object roll_objectUserDefined(HashMap objectsAndPercent);

    HM<Object, Float> randomizeFloatsForObjects(Collection objects_inp, float startNum);

    void setSeed(int i);

    //!!!Random char!!!
    public enum CharType {
        both(65, 90, 97, 122), big(65, 90), little(97, 122);
        Character[] chars;

        public Character[] getChars() {
            return chars;
        }

        CharType(int... startEndPairs) {
            ArrayList<Character> charsz = new ArrayList<Character>();
            for (int i = 0; i < startEndPairs.length; i = i + 2) {
                for (int j = 0; j <= startEndPairs[i + 1] - startEndPairs[i]; j++)
                    charsz.add((char) (startEndPairs[i] + j));
            }
            chars = new Character[charsz.size()];
            charsz.toArray(chars);
        }
    }

    //random Strings
    public enum StringType {
        both, big, little, bigStart
    }
}
