package ru.spb.kpit.kivan.Randomizer;

/**
 * Created by IntelliJ IDEA.
 * User: Kivan
 * Date: 17.04.2011
 * Time: 13:58:02
 * To change this template use File | Settings | File Templates.
 */
public class SSRand {
    static Randomizer sync_rand;
    static Randomizer notsync_rand;

    static {
        sync_rand = new SyncRandomizer();
        notsync_rand = new PlainRandomizer();
    }

    /**
     * Thread safe static instance of randomizer
     * @return
     */
    public static Randomizer thrdSf() {
        return sync_rand;
    }

    /**
     * Not thread safe static instance of randomizer
     * @return
     */
    public static Randomizer N_thrdSf() {
        return notsync_rand;
    }
}
